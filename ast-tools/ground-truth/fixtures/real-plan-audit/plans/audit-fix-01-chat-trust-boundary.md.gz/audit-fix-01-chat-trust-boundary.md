# Fix Prompt: Chat Trust Boundary + Cleanup

## Context
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- Source audit: ~/audits/26-03-04-13-41--user-frontend--complete-audit.md
- Cleanup file: ~/plans/backlog-cleanup.md (append to it)

Read ~/github/user-frontend/CLAUDE.md before starting.

## Fixes

### Fix 1: Guard idToken non-null assertion (P1 #1)
`useChatApi.ts:32` -- `idToken!` non-null assertion silently sends `undefined` as an HTTP header when idToken is nullish. This is a trust boundary violation.

Add a guard: throw or return early if `idToken` is undefined. Do NOT silently proceed with an undefined auth header.

This fix changes observable behavior (error handling). Write a failing test BEFORE applying the fix. Confirm it fails (red), apply the fix, confirm it passes (green). Use /build-react-test or /build-module-test as appropriate.

### Fix 2: Wrap JSON.parse in try/catch (P1 #2)
`useChatApi.ts:14` -- `JSON.parse(data)` in Zod preprocess without try/catch. A `SyntaxError` here bypasses the ApiError handler entirely.

Wrap the `JSON.parse` call in try/catch. On SyntaxError, throw a well-formed error that the existing error handler can catch, or return a Zod-compatible failure value.

This fix changes observable behavior. Write a failing test BEFORE applying the fix. Confirm it fails (red), apply the fix, confirm it passes (green).

### Fix 3: Delete dead mockedMessages export (P2 #4)
`chat/constants.ts:39` -- `mockedMessages` is exported but has zero consumers.

Delete the export. If the value itself is also unused, delete it entirely.

No test needed (dead code deletion).

### Fix 4: Move Message type to dedicated types file (P2 #5)
`Chat.tsx:8-12` -- `Message` type is exported from a component file and imported by a hook and constants file.

Create `chat/types.ts` and move `Message` there. Update all import sites.

No test needed (structural move).

### Fix 5: Remove double cast in ChatContainer spec (P3 #65)
`ChatContainer.spec.tsx:25` -- `as unknown as` double cast in test.

Replace with `satisfies` or a typed mock factory. If the mock shape genuinely does not match the type, fix the mock to match.

No test needed (test file change).

### Fix 6: Consider named constant for message role (P3 #66)
`Chat.tsx:9` -- Bare string union `'question' | 'answer'` for message role.

Consider replacing with an `as const` object (`MESSAGE_ROLE`). Low priority -- skip if the union is only used in the type definition.

No test needed (type-level change).

### Fix 7: Fix ineffective as const on introSections (P3 #67)
`constants.ts:37` -- `as const` on `introSections` is ineffective because the `Section[]` type annotation widens first.

Either remove the `as const` (since the annotation already determines the type) or remove the `Section[]` annotation and let `as const` infer a narrow type. Pick whichever preserves current behavior.

No test needed (type-level change).

### Fix 8: Rename utils.tsx or extract component (P3 #68)
`utils.tsx` -- Returns JSX from a utility `.tsx` file. This is a naming convention issue.

If the function returns JSX, it is a component -- rename to reflect that (e.g., `ChatMessageContent.tsx`), or keep it in utils and ensure it does not return JSX (extract the JSX into a proper component). Low priority.

No test needed (rename/restructure).

## Commit Strategy
One commit for Fixes 1-2 (P1 trust boundary fixes with tests). A second commit for Fixes 3-8 (cleanup). Two commits total.

## Verification

Run ALL of the following in `~/github/user-frontend` and paste the output:

```bash
pnpm tsc --noEmit
pnpm test --run
pnpm build
npx eslint . --max-warnings 0
```

Prompt-specific checks:

```bash
# idToken! should be gone
grep -rn 'idToken!' src/ui/page_blocks/dashboard/chat/

# JSON.parse should be wrapped in try/catch
grep -A2 'JSON\.parse' src/ui/page_blocks/dashboard/chat/useChatApi.ts

# mockedMessages export should be gone
grep -rn 'mockedMessages' src/ui/page_blocks/dashboard/chat/constants.ts

# Message type should live in types.ts, not Chat.tsx
grep -rn "export.*type Message" src/ui/page_blocks/dashboard/chat/
```

## Reconciliation

When all fixes are applied and all verification passes, output this block exactly:

```
=== RECONCILIATION: Audit Fix 01 (Chat Trust Boundary) ===
HEAD: <sha>
Commits: <count> (<sha>..<sha>)
tsc: <0 errors | N errors>
Tests: <N specs, M passed, K todo>
Build: <clean | failed>
ESLint: <clean | N errors, M warnings>

Prompt-Specific:
  idToken! grep: <0 hits | N hits>
  JSON.parse try/catch: <present | missing>
  mockedMessages export: <deleted | still present>
  Message type location: <chat/types.ts | other>

Cleanup Items Added: <N items>
Subsequent Prompts Modified: <none | list>
Deviations: <none | list>
Work Left Undone: <none | list>
=== END RECONCILIATION ===
```

Also update `~/plans/backlog-cleanup.md`: mark findings #1, #2, #4, #5, #65-#68 as DONE.
