# AST Tools for Audit/Refactor Skills

> Complexity: D6 S4 Z7 = 5.7
> Nearest: UF Phase 3: Provider Stripping (5.7), DDAU Exception Elimination (6.0)
> Integration scope: none (tooling scripts, no Playwright tests involved)

## Goal

Build 6 TypeScript AST analysis tools in `scripts/AST/` that the audit
and refactor skills can invoke via Bash. Each tool takes a file path (or
directory), parses it with the TypeScript compiler API via ts-morph, and
outputs structured JSON to stdout. The skills gain deterministic,
context-efficient analysis that replaces dozens of sequential Grep/Read
calls.

## Why

Every audit/refactor skill starts with an analysis phase that burns
context and produces inconsistent results:

- **Context cost.** Building the dependency picture for a 30-file feature
  takes 10-30 Grep calls and 10+ file reads before any work begins.
- **False positives.** Grep for `as any` catches comments and strings.
  Grep for `useEffect` catches imports and definitions. Multi-line
  patterns (chained ternaries, useEffect bodies) are invisible to regex.
- **Inconsistency.** Two invocations of the same skill on the same file
  can classify hooks or effects differently because the agent is doing
  heuristic text analysis.

AST tools fix all three: structured JSON output is small, precise, and
deterministic.

## Skill file locations (IMPORTANT)

Skills exist in TWO places. Agents that modify skills must update both.

| Location | Role | Git repo |
|----------|------|----------|
| `~/github/user-frontend/.claude/skills/` | **Source.** Edit skills here. | Part of `user-frontend` repo, branch `sd/ast-tools` |
| `~/.claude/skills/` | **Sink.** Claude Code reads skills from here at runtime. | Separate repo: `shawn-dumas/claude-code-skills` (GitHub) |

After editing skills in the source, copy the changed files to the sink,
then commit and push the sink repo separately. P07 includes this step.

## Technology choice

**ts-morph** (devDependency). Wraps the TypeScript compiler API with a
cleaner traversal interface. Handles tsconfig loading, path alias
resolution, and type checking. The project already has `typescript@5.9.3`
and `tsx@4.21.0` for script execution.

## Tools (in dependency order)

| # | Tool | Serves | Depends on |
|---|------|--------|-----------|
| 0 | Foundation (shared utils, types, test harness) | all | -- |
| 1 | `ast-imports` | 17/17 skills | foundation |
| 2 | `ast-react-inventory` | 10/17 skills | foundation, ast-imports (for hook classification) |
| 3 | `ast-jsx-analysis` | 5/17 skills | foundation |
| 4 | `ast-type-safety` | 5/17 skills | foundation |
| 5 | `ast-test-analysis` | 5/17 skills | foundation, ast-imports (for mock target resolution) |
| 6 | `ast-complexity` | 3/17 skills | foundation |
| 7 | Skill integration | 17/17 skills | all tools |

## Prompt sequence

| # | Prompt | Description | Depends on |
|---|--------|-------------|-----------|
| P00 | Foundation | Install ts-morph, create directory structure, shared types, tsconfig-aware project loader, test harness, runner script | -- |
| P01 | ast-imports | Import/export dependency graph, path alias resolution, barrel chain walking, circular dep detection, dead export detection | P00 |
| P02 | ast-react-inventory | Component enumeration, hook call inventory (classified), useEffect body analysis, Props interface extraction | P00, P01 |
| P03 | ast-jsx-analysis | JSX template complexity: chained ternaries, complex guards, inline transforms, IIFEs, multi-statement handlers, return statement metrics | P00 |
| P04 | ast-type-safety | Type assertion finder: as any, double casts, non-null assertions, explicit any annotations, trust boundary casts, catch(error: any) | P00 |
| P05 | ast-test-analysis | Test file analysis: mock target classification, assertion type classification, cleanup analysis, strategy detection, data sourcing | P00, P01 |
| P06 | ast-complexity | Per-function cyclomatic complexity, nesting depth, line counts | P00 |
| P07 | Skill integration | Update 16 skill files to reference AST tools, add usage examples, add Bash to allowed-tools where needed | P00-P06 |

## Verification commands

After every prompt:

```bash
git log --oneline -10
npx tsc --noEmit -p scripts/AST/tsconfig.json
# Tool-specific: run the tool against a known file and verify output
npx tsx scripts/AST/<tool>.ts <test-file> | jq .
# Run tool tests
npx vitest run --config scripts/AST/vitest.config.mts --reporter=verbose
# Verify root project unaffected
pnpm tsc --noEmit
```

## File structure (target)

```
scripts/AST/
  tsconfig.json         # Extends root tsconfig, includes scripts/AST/**/*
  vitest.config.mts     # Separate vitest config for AST tool tests
  types.ts              # Shared output types + config constants (MAY_REMAIN_HOOKS, etc.)
  project.ts            # tsconfig-aware ts-morph Project loader + findConsumerFiles
  cli.ts                # Shared CLI argument parsing + JSON output
  ast-imports.ts        # Tool 1
  ast-react-inventory.ts # Tool 2
  ast-jsx-analysis.ts   # Tool 3
  ast-type-safety.ts    # Tool 4
  ast-test-analysis.ts  # Tool 5
  ast-complexity.ts     # Tool 6
  __tests__/
    ast-imports.spec.ts
    ast-react-inventory.spec.ts
    ast-jsx-analysis.spec.ts
    ast-type-safety.spec.ts
    ast-test-analysis.spec.ts
    ast-complexity.spec.ts
    fixtures/            # Small .ts/.tsx files for deterministic test input
      simple-component.tsx
      component-with-effects.tsx
      component-with-jsx-complexity.tsx
      module-with-types.ts
      test-file.spec.ts
      barrel-reexport.ts
      circular-a.ts
      circular-b.ts
```

## Execution conventions

Every tool:
- Is invoked via `npx tsx scripts/AST/<tool>.ts <path> [options]`
- Outputs JSON to stdout (parseable by the agent)
- Exits 0 on success, 1 on error (with error message to stderr)
- Accepts `--pretty` for human-readable output (default: compact JSON)
- Accepts `--help` for usage
- Loads the project tsconfig once and caches the ts-morph Project instance

## Completion criteria

1. All 6 tools pass `npx tsc --noEmit -p scripts/AST/tsconfig.json`
2. All 6 tools have tests that pass via `npx vitest run --config scripts/AST/vitest.config.mts`
3. Each tool produces correct JSON when run against real project files
4. All 16 modified skill files reference the relevant AST tools (refactor-playwright-test unchanged)
5. Skills with `allowed-tools: Read, Grep, Glob` gain `Bash` where needed
6. Root `pnpm tsc --noEmit` and `pnpm build` still pass

## Status

| # | Prompt | Status |
|---|--------|--------|
| P00 | Foundation | complete |
| P01 | ast-imports | complete |
| P02 | ast-react-inventory | complete |
| P03 | ast-jsx-analysis | complete |
| P04 | ast-type-safety | complete |
| P05 | ast-test-analysis | complete |
| P06 | ast-complexity | complete |
| P07 | Skill integration | complete |
