# Phase 7: Test Suite -- Detail Plan

> Repo: `~/github/user-frontend`, Branch: `sd/productionize`, HEAD: `80a34701`
> Created: 2026-03-01. Updated: 2026-03-03 (Sessions 7-9 deferred to post-Phase 8).
> Addendum: 2026-03-01 -- Audit gap items added: Session 4 pre-work (3 bugs, 2 infra fixes, test infra fixes, 3 DDAU trivials), fetchApi tests in Session 6, 7 specific rewrite targets in Session 7. See `~/plans/uf-audit-gap-addendum.md`.
> Baseline (post-Phase-8 upgrades): 2281 tests pass, 0 skipped, 2 todo, 180 spec files, 0 tsc errors, 0 ESLint warnings, 26 containers (26/26 tested), 24 useEffects, 14/14 convergence. Statement coverage: 57.2%.
> Note: Test/spec counts dropped from Session 6 baseline (2350/187) due to Phase 8 upgrades (Vitest 3->4, React 18->19, Next.js 14->15, nuqs migration rewrites). No coverage regression -- delta is from upgraded test infrastructure and nuqs-migrated filter specs.
> Build: PASSES (blocker resolved Session 2).
> Master plan: `~/plans/user-frontend-ddau-roadmap.md`

---

## 0. Build Blocker: RESOLVED (Session 2)

**Original diagnosis** (Session 1): Attributed to echarts-for-react accessing `window`
at import time via the workstream-analysis barrel.

**Actual root cause** (Session 2): `getEventProperties` in `src/shared/lib/posthog.ts`
accesses `window.location.pathname` and `localStorage.getItem` without typeof-window
guards. These run during SSG prerendering when DashboardLayout's render-time analytics
tracking (Phase 6, Session 4 ref-based pattern) calls `sendPosthogEvent` during render.

**Fix applied** (3 commits):
1. `4ffe43e4` -- Barrel cleanup: removed 4 dead exports from workstream-analysis barrel (G7)
2. `a0c15519` -- Guard window/localStorage in posthog.ts; dynamic-import SystemAnalysis
   in WorkstreamDetails (ssr: false); bypass charts barrel in ProductivityByDateContainer
3. Verified: `pnpm build` passes, `pnpm test --run` 1893 pass

**Deviation from plan**: The echarts barrel cleanup was beneficial but not the root cause.
The dynamic import was applied at WorkstreamDetails (importing SystemAnalysis) rather
than SystemAnalysis (importing PieChart/WorkstreamGanttChart) because PieChart is generic
and `next/dynamic` erases generic type parameters.

---

## 1. Inventory

### 1A. Current Test State

| Metric | Value |
|--------|-------|
| Total spec files | 209 |
| Passing spec files | 156 |
| Skipped spec files | 53 (all service hook it.todo stubs) |
| Passing tests | 1893 |
| Skipped tests | 3 |
| Todo tests | 71 |
| Total test lines | 28,322 |

#### Spec files by layer

| Layer | Spec files | Notes |
|-------|-----------|-------|
| page_blocks | 26 | 15 utils, 4 filter integration, 3 component, 4 misc |
| components/8flow | 24 | Table (3), charts (6), modals (2), forms (1), misc (12) |
| services | 60 | 8 mapper specs pass, **52 are stub-only (it.todo)** |
| providers | 12 | auth (6), insights (5), teams (1) |
| shared/hooks | 14 | Good coverage for existing specs |
| shared/utils | 47 | Best-covered layer |
| shared/ui | 23 | 23 of 41 .tsx files covered |
| src/tests | 3 | Legacy integration tests (insights-dashboard x2, testE2EUtils) |

#### 5 largest spec files

| File | Lines |
|------|-------|
| TableFilter.spec.tsx | 838 |
| mapSystemsOverview.spec.ts | 818 |
| Table.spec.tsx | 818 |
| mapUserStats.spec.ts | 774 |
| queryParams.spec.ts | 703 |

### 1B. Coverage Gaps

#### Production files with NO corresponding spec

| Layer | Files with spec | Files without spec | Coverage |
|-------|----------------|-------------------|----------|
| page_blocks (.tsx) | 5 | 128 | 3.8% |
| components/8flow (.tsx) | 10 | 48 | 17.2% |
| services (hooks + mappers) | 67 (8 real + 59 stub wrappers) | 9 mappers + 5 key files | ~86% by file, ~13% by real tests |
| providers | 12 | - | Good (utils/hooks covered) |
| shared/hooks | 14 | 7 meaningful | 67% |
| shared/utils | 46 | 9 | 84% |
| shared/ui | 23 | 18 | 56% |

#### All 26 containers -- ZERO have specs

```
dashboard/chat/ChatContainer.tsx
dashboard/operational-hours/TeamProductivityContainer.tsx
dashboard/operational-status/RealtimeActivityContainer.tsx
dashboard/operational-status/RealtimeFilters/RealtimeFiltersContainer.tsx
dashboard/opportunities/MicroworkflowDetailsTable/MicroworkflowDetailsContainer.tsx
dashboard/opportunities/MicroworkflowsByUserTable/MicroworkflowsByUserTableContainer.tsx
dashboard/opportunities/MicroworkflowsContainer.tsx
dashboard/opportunities/OpportunityFilters/OpportunitiesFiltersContainer.tsx
dashboard/system-latency/SystemLatencyContainer.tsx
dashboard/systems/SystemsContainer.tsx
dashboard/team/ProductivityByDateContainer.tsx
dashboard/team/ProductivityContainer.tsx
dashboard/ui/InsightsFilters/InsightsFiltersContainer.tsx
dashboard/usage/favoriteUsage/FavoriteUsageContainer.tsx
dashboard/usage/relayUsage/RelayUsageContainer.tsx
dashboard/workstream-analysis/analyzer/ActivityTimelineTableContainer.tsx
dashboard/workstream-analysis/analyzer/WorkstreamsAnalyzerContainer.tsx
dashboard/workstream-analysis/filters/WorkstreamsFiltersContainer.tsx
dashboard/workstream-analysis/WorkstreamAnalysisContainer.tsx
settings/Account/AccountContainer.tsx
settings/BPO/BPOContainer.tsx
settings/Project/ProjectContainer.tsx
settings/Urls/ClassificationUrlsContainer.tsx
teams/TeamDetailContainer.tsx
teams/TeamsListContainer.tsx
users/UsersContainer.tsx
```

#### 52 service hook stub specs (it.todo only, 0 passing tests)

All query/mutation hook specs in `src/ui/services/hooks/` are stub files containing
only `it.todo(...)` placeholders. Generated during Phase 2 hook extraction, never
implemented. Example:

```ts
// useRemoveTeamsMutation.spec.tsx
import { describe, it } from 'vitest';
describe('useRemoveTeamsMutation', () => {
  it.todo('removes teams and invalidates related queries');
  it.todo('calls options.onSuccess when provided');
});
```

These 52 stubs account for all 53 "skipped" spec files (53rd is
`handleClickGlossary.spec.ts` which has 1 skipped test for a different reason).

#### 25 column hooks -- ZERO have specs

All `use*TableColumns` hooks in page_blocks. These define TanStack Table column
configurations. Low bug risk individually.

#### 9 mapper functions without specs

```
mapAvgLatencyByHost     mapMicroworkflows       mapOperationalHours
mapRealtimeStats        mapTimeByHost           mapTopUsedHosts
mapTtmForDays           mapWorkstreams          mapWorkstreamsTimingInfo
```

8 mapper functions DO have specs (and pass): mapActivitiesByUser, mapActivityTimeline,
mapSystemPages, mapSystemsOverview, mapUserStats, mapUserOccurrences,
mapClassificationUrlItems, mapUsers.

#### Shared hooks without specs (7 meaningful)

```
useClickAway        useContainerSize     useCountdown
useCustomQueryClient useEscapeKey         useFilterCollapse
usePagination
```

(useHydrated, usePosthogClient, useWebExtension are thin wrappers -- low test value.)

#### Shared utils without specs (9)

```
color/extendColorsSet/constants.ts    string/camelCaseToNormal.ts
string/getCSVFilename.ts              string/snakeCaseToNormal.ts
string/stripHtml.ts                   common/isJsonEqual.ts
user/mapUserRoleName.ts               user/removeCookies.ts
user/roleChecks.ts
```

### 1C. Test Quality Audit

#### Stale mock patterns

| Pattern | Count | Violation |
|---------|-------|-----------|
| `vi.mock('@/services/...')` in leaf specs | 4 | P2: mocking at wrong boundary |
| `vi.mock('@/providers/...')` | 8 | P2/P7: may be stale after provider stripping |
| `vi.mock('@/page_blocks/...')` | 5 | P3: mocking internal components |
| `as any` casts in specs | 69 | P6: type-unsafe mocks |
| `getMockedQuery(...)` usage | 9 | P5/P6: shared mock factory, not fixture builders |
| MockedProviders wrapper | 15 | Acceptable (integration strategy wrapper) |
| MockedInsightsProvider wrapper | 12 | Acceptable (context override) |
| `useTeamsListQuery` mocked in filter specs | 4 | Correct pattern (boundary mock per commit 7cc4a818) |
| Shared `mockedTeams` from teamsContext/mocks | 4 | P5: shared mock constants instead of fixture builders |

#### Assertion pattern ratio

| Pattern | Count | Notes |
|---------|-------|-------|
| `getByTestId` / `queryByTestId` | 370 | P8 violation: implementation-detail selectors |
| `getByRole` / `getByText` / `findByRole` / `findByText` | 56 | P8 compliant: user-facing selectors |
| Ratio (testId : role/text) | 6.6 : 1 | Heavy testId reliance |

### 1D. Testing Philosophy Alignment

Estimated violation rates from sampled specs (InsightsFilters, OpportunitiesFilters,
RealtimeFilters, WorkstreamsFilters, Table, TableFilter, EditUserModal, MetadataPopupContent):

| # | Principle | Est. violation rate | Notes |
|---|-----------|-------------------|-------|
| P1 | Public API Only | ~5% | Mostly good |
| P2 | Boundary Mocking | ~20% | 4 service hook mocks at wrong level, 8 provider mocks |
| P3 | System Isolation | ~10% | 5 specs mock internal components |
| P4 | Strict Strategies | ~15% | Some mixed unit/integration |
| P5 | Data Ownership | ~30% | mockedTeams, shared constants |
| P6 | Type-Safe Mocks | ~35% | 69 `as any`, `as ReturnType<...>` casts |
| P7 | Refactor Sync | ~25% | Stale shapes from pre-DDAU era |
| P8 | User Outcomes | ~60% | 370 testId vs 56 role/text assertions |
| P9 | Determinism | ~5% | Good (vi.setSystemTime, beforeEach clear) |
| P10 | Total Cleanup | ~5% | Good (vitest.setup.ts handles afterEach) |

### 1E. Roadmap Items Assessment

| # | Item | Status | Notes |
|---|------|--------|-------|
| 7.1 | Port testing philosophy doc | **DONE** | Already in CLAUDE.md "Testing Philosophy" section |
| 7.2 | Audit all existing spec files | TODO | Core work -- Session 2 |
| 7.3 | Delete tests scoring 4/10 or below | TODO | Based on Session 2 audit |
| 7.4 | Rewrite surviving tests | TODO | Sessions 9-10 |
| 7.5 | Build new tests for coverage gaps | TODO | Sessions 3-8, 11-12 |
| 7.6 | Port E2E infrastructure from NGA | **DEFER to Phase 8** | UF already has 15 E2E specs + Playwright config |
| 7.7 | Update UF's existing E2E specs | **DEFER to Phase 8** | Depends on 7.6; low priority vs unit coverage |
| 7.8 | Port screenshot-tripwire.spec.ts | **DEFER to Phase 8** | Trivial once 7.6 done |
| 7.9 | Update e2e/constants.ts | **DEFER to Phase 8** | Depends on browser bug bash |

Rationale for deferring E2E (7.6-7.9): UF already has a working E2E setup with 15 specs.
The E2E infrastructure port from NGA adds value but is independent of the unit test work.
Phase 8 includes browser bug bashing (8.7-8.8) which naturally pairs with E2E updates.
Unit test coverage (7.2-7.5) is the higher-priority gap.

### 1F. Fixture System Readiness

15 domain fixture files exist:

```
auth             bpo-projects      company          events
microworkflows   operational-hours  productivity     realtime
relay            spans             systems          teams
url-classification   users         workstream-data
```

Coverage assessment:

| Container domain | Fixture exists? | Notes |
|-----------------|----------------|-------|
| dashboard/team (Productivity*) | productivity.fixture | Yes |
| dashboard/systems | systems.fixture | Yes |
| dashboard/opportunities | microworkflows.fixture | Yes |
| dashboard/operational-hours | operational-hours.fixture | Yes |
| dashboard/operational-status | realtime.fixture | Yes |
| dashboard/usage (Favorite/Relay) | relay.fixture | Yes |
| dashboard/system-latency | systems.fixture (partial) | May need extension for latency-specific data |
| dashboard/workstream-analysis | workstream-data.fixture | Yes |
| dashboard/chat | -- | **MISSING**: need chat response fixture |
| settings/Account | auth.fixture | Yes |
| settings/BPO | bpo-projects.fixture | Yes |
| settings/Project | bpo-projects.fixture | Yes |
| settings/Urls | url-classification.fixture | Yes |
| teams | teams.fixture | Yes |
| users | users.fixture | Yes |

**Gap**: chat domain has no fixture builder. Use `/build-fixture` to create
`chat.fixture.ts` before building ChatContainer spec.

### 1G. Test Infrastructure

| Component | Status | Notes |
|-----------|--------|-------|
| vitest.setup.ts | Working | fetchMock, localStorage polyfill, provider mocks, afterEach cleanup |
| vitest-fetch-mock | Working | Global fetchMock available in all specs |
| @testing-library/react | Working | render, screen, waitFor, userEvent |
| MockedProviders | Working | Wraps auth + posthog + teams + insights context |
| MockedInsightsProvider | Working | Context override for insights state |
| getFetchMock() | Working | Typed accessor for global fetchMock |
| getMockedQuery/Mutation | Working but legacy | Returns fake UseQueryResult objects. Migrate to fixture builders. |
| src/fixtures/ | Working | 19 files, full domain coverage except chat |
| posthog-mock.ts | Working | Auto-mocks sendPosthogEvent globally |
| nextRouterMocks.ts | Working | Auto-mocks next/router globally |

---

## 2. Triage Rules

### Score thresholds (from /audit-react-test)

| Score | Action | Tool |
|-------|--------|------|
| 7-10/10 | **Keep** -- minor fixes only | Hand edit |
| 5-6/10 | **Rewrite** -- salvageable but needs major rework | `/refactor-react-test` |
| 0-4/10 | **Delete** -- beyond repair, rebuild from scratch | Delete, then `/build-react-test` |

### Pre-triage decisions (no audit needed)

| Category | Count | Decision | Rationale |
|----------|-------|----------|-----------|
| Service hook stubs (it.todo only) | 52 | **Delete** | Zero passing tests. Replace with real specs in Sessions 6-7. |
| Legacy src/tests/ specs | 3 | **Assess** | May be covered by new container tests. Audit in Session 2. |

---

## 3. Priority Order

1. **Container tests** (26 containers, 0 coverage) -- these ARE the DDAU boundary.
   If these tests pass, the architecture is validated. Highest value per test.

2. **Mapper function specs** (9 uncovered + verify 8 existing) -- pure functions
   with transformation logic. Easy to test, high confidence gain.

3. **Service hook specs** (52 stubs to implement) -- validate correct query keys,
   request body construction, response mapping, and invalidation patterns.

4. **Existing spec quality fixes** (based on Session 2 audit) -- fix stale mocks,
   replace `as any`, migrate from testId to role/text, replace shared mock
   constants with fixture builders.

5. **High-value page_blocks** (forms, complex tables, filter UIs) -- components
   with significant rendering logic or user interaction patterns.

6. **Shared hooks and components** -- fill remaining coverage gaps in shared/hooks
   and shared/ui.

7. **Column hooks and simple presentational** -- lowest priority. Column hooks are
   configuration, not logic. Simple presentational components are tested implicitly
   via container integration tests.

---

## 4. Session Plan

### Scoping philosophy: risk-based, not coverage-percentage

The original plan targeted 60% statement coverage uniformly. Revised approach:
identify the 20% of files that cover 80% of the risk, and test those well.

**What carries risk**:
- Containers (DDAU boundary -- if these break, data doesn't reach the UI)
- Service hooks with complex mappers (data transformation logic)
- Filter integration flows (user-facing form validation + state persistence)
- Mutation hooks with cache invalidation (stale data bugs)

**What does NOT carry risk**:
- Trivial query wrappers (fetchApi + single return, no mapper)
- Column hook definitions (static configuration)
- Pure presentational leaves (tested implicitly via container integration)
- Barrel files, constants, type definitions

This reduces the session count from 12 to 8-9 while covering the same risk surface.

### Stub cleanup expectations

The 52 service hook stubs will be deleted in Session 2. This drops the spec file
count from 209 to ~157 and removes 71 `it.todo` entries from the test output.
The test count (1893 passing) is unaffected because stubs contribute zero passing
tests. After Session 2, the numbers will accurately reflect real coverage.

Stubs are replaced with real specs only for hooks that have risk (complex mappers,
multi-step invalidation, conditional params). Trivial wrappers (single fetchApi call,
no mapper, no invalidation logic) do NOT get individual specs -- they are validated
via container integration tests.

### Session 2: Build Fix + Audit + Triage -- COMPLETE (2026-03-01)

HEAD: `4c06e01d`. 4 commits.

**Completed**:
1. Fixed build blocker (posthog window access, not echarts as originally diagnosed)
2. Deleted 52 service hook stub specs (spec files: 209 -> 157, tests unchanged at 1893)
3. Assessed 3 legacy specs in src/tests/ (kept all 3 -- unique mapper coverage)
4. Audited 82 spec files across all layers (26 page_blocks, 24 components, 12 providers, 8 mappers, 3 legacy, 10 shared spot-check, minus 1 overlap)
5. Produced triage table at `tmp-audits/phase-7-triage.md`

**Triage results**:
| Decision | Count |
|----------|-------|
| Keep (7-10) | 53 |
| Rewrite (5-6) | 23 |
| Delete (0-4) | 6 |
| Not audited | 74 (shared layer, deferred) |

**Deviations from plan**:
- Build blocker was posthog.ts, not echarts. Dynamic import placed at WorkstreamDetails level.
- Legacy specs (src/tests/) kept rather than deleted -- they provide unique mapper coverage.
  The 2 legacy mapper specs scored 3 (Delete threshold) on audit; their mappers need
  co-located specs built in Sessions 3-6 before these legacy files can be safely removed.
- handleClickGlossary.spec.ts skip confirmed stale; file scores 2, marked for deletion.
- calculatePeriodEnds.spec.ts 2 skipped tests confirmed stale (wrong expected values).

### Sessions 3-5: Build Container Tests (26 containers)

Container tests are integration tests. Each one:
- Renders the container inside MockedProviders (+ MockedInsightsProvider where needed)
- Mocks service hooks via `vi.mock('@/services/hooks/...')`
- Verifies data flows correctly to child components via props
- Tests user interactions that trigger callbacks (filter submit, selection, navigation)

**Session 3: Dashboard containers -- filters + team + systems + latency (6) -- COMPLETE (2026-03-01)**

HEAD: `51000a35`. 8 commits (1 deletion + 6 container specs + 1 ESLint fix).

**Pre-work**: Deleted 6 spec files scoring 0-4 on Session 2 triage (34 tests removed).
Post-deletion baseline: 151 spec files, 1859 tests.

**Container tests built**:

| Container | Tests | Key coverage |
|-----------|-------|-------------|
| InsightsFiltersContainer | 21 | Form submission, filter fields by type, posthog, localStorage, hours switch, dedup |
| ProductivityContainer | 9 | Query params, loading/empty, selection maintenance, variant rendering |
| ProductivityByDateContainer | 12 | Dual query orchestration, table/chart threading, row click |
| TeamProductivityContainer | 13 | Query params, tab rendering/switching, loading/empty/placeholder, intervalDays mapping |
| SystemsContainer | 13 | 3-level drill-down, 5 query hooks, loading states |
| SystemLatencyContainer | 13 | 3 queries, host/user drill-down, loading/empty |

**Totals**: 6 specs, 81 new tests. Post-session: 157 spec files, 1940 tests passing, 2 skipped.

**ESLint fix**: `expect.any(Boolean)` returns `any`, triggering `no-unsafe-assignment` warning.
Fixed with `as unknown` cast. Same pattern needed in SystemsContainer for `expect.any(String)`.
One duplicate import (`no-duplicate-imports`) also fixed in SystemsContainer.

**Deviations**:
- ProductivityContainer complexity was LOW (not High as listed). Only 40 lines, 9 tests sufficient.
- One extra commit for ESLint warning fix (could not be caught before commit due to formatter interaction).

**Pattern established for remaining containers**:
1. Mock service hooks via `vi.mock('@/services/hooks/queries/<domain>')`
2. Override global insightsContext mock to preserve real query-param utilities via `importOriginal`
3. Wrap in `MockedProviders` + `MockedInsightsProvider`
4. Assert on rendered output + hook call arguments
5. Use `getMockedQuery` with explicit type casts (no `as any`)
6. Use fixture builders for domain data

**Session 4 Pre-work (from 2026-03-01 codebase audit -- do before writing more tests):**

| Item | What | Why |
|------|------|-----|
| Bug: isUser guard | `src/shared/types/users.ts:43` -- change `=== 'string'` to `=== 'number'` | Silently rejects all valid users. 1-line fix. |
| Bug: Chat isAnimating | `src/ui/page_blocks/dashboard/chat/Chat.tsx` -- add try/finally to reset isAnimating on error | Input permanently disabled after failed API call. |
| Bug: session modal timer | `src/ui/providers/context/auth/hooks/useSessionModal.ts:40` -- move setTimeout to useEffect with cleanup | Fires after unmount. |
| Infra: fetchApi empty catch | `src/shared/lib/fetchApi/fetchApi.ts:69-73` -- remove empty catch or surface error | Silent null return for non-JSON 200s, affects 52 hooks. |
| Infra: mock-token fallback | `src/shared/lib/fetchApi/useFetchApi.ts:12-17` -- gate on NEXT_PUBLIC_LOCAL | Masks auth failures in production. |
| Test infra: getMockedQuery generic | Add `<T>` type parameter to getMockedQuery | Eliminates 7+ `as ReturnType<>` casts across container specs. |
| Test infra: ESLint warning | Fix `expect.any(Boolean)` in ProductivityByDateContainer.spec.tsx:197 | Single warning blocking `--max-warnings 0`. |
| Test infra: cleanup | Replace `vi.clearAllMocks()` with `vi.restoreAllMocks()` in ~15 afterEach blocks | clearAllMocks does not restore original implementations. |
| Test infra: duplicate spec | Delete `InsightsFilters.spec.tsx` (old, in `__tests__/`) | Superseded by InsightsFiltersContainer.spec.tsx. |
| DDAU trivial | AccessDenied.tsx (add `onLogOut` prop), EditAssignmentModal.tsx (add `isAdmin` prop), SidebarLink.tsx (add `isActive` prop) | 3 non-exception violations found by audit, ~5 min each. |

**Session 4: Pre-work + Dashboard containers -- ops + opportunities + usage (8) -- COMPLETE (2026-03-01)**

HEAD: `24fa03e7`. 12 commits (4 pre-work + 8 container specs).

**Pre-work completed** (4 commits):
1. `87153ce4` -- Bug fixes: isUser guard (string->number), Chat try/finally, useSessionModal timer cleanup
2. `4161d81f` -- Infrastructure: fetchApi content-type check (removed empty catch), useFetchApi local-only mock-token
3. `72d99b41` -- Test infra: getMockedQuery generic `<TData>`, deleted superseded InsightsFilters spec (14 tests)
4. `817c52c6` -- DDAU conversions: AccessDenied (onLogOut prop), EditAssignmentModal (isAdmin prop), SidebarLink (isActive prop)

**Pre-work deviations**:
- `vi.clearAllMocks` -> `vi.restoreAllMocks` migration DEFERRED. Broke 55 tests because many specs use `vi.spyOn()` at describe/beforeAll level and expect implementations to persist across tests. Requires per-file spy pattern audit (separate session or Session 7 rewrite scope).
- ESLint warning in ProductivityByDateContainer.spec.tsx:197 was already fixed (had `as unknown` cast).
- CLAUDE.md did not contain AccessDenied/EditAssignmentModal/SidebarLink exceptions to remove.

**Container tests built**:

| Container | Tests | Key coverage |
|-----------|-------|-------------|
| RealtimeActivityContainer | 10 | Query params, loading, data rendering, placeholder, empty row filter, timer countdown |
| RealtimeFiltersContainer | 18 | Form rendering, submit with posthog/localStorage/setFilters, toggle, restoration, countdown |
| MicroworkflowsContainer | 10 | Query params (team/workstream), loading, KPI rendering, placeholder, feature flag |
| MicroworkflowDetailsContainer | 13 | Query params, loading, source/target systems, workstream text, analyzer link/callback |
| MicroworkflowsByUserTableContainer | 14 | Query params, loading, table data, row click, selected user summary, change user |
| OpportunitiesFiltersContainer | 23 | Both variants, form submit, posthog, localStorage, setFilters, dedup, button states |
| FavoriteUsageContainer | 8 | 3-query param derivation, disabled states, tab/KPI rendering, loading |
| RelayUsageContainer | 9 | 3-query param derivation, disabled states, tab/KPI rendering, loading, empty data |

**Totals**: 8 specs, 105 new tests. Post-session: 164 spec files, 2031 tests passing, 2 skipped.
14/26 containers now have specs. 12 remain.

**Session 5: Dashboard remaining + non-dashboard containers (12) -- COMPLETE (2026-03-01)**

HEAD: `9238b655`. 12 commits (12 container specs). isAnimating bug fix was already committed as `7b1f6c03` before this session started.

**Pre-work**:
- W-1 (isAnimating fix): Already committed at `7b1f6c03`. setIsAnimating(false) added to finally block.
- W0 (chat fixture): SKIPPED. Message type is only 3 fields (text, type, error?) -- inline test data suffices. Deviation noted.

**Container tests built**:

| Container | Tests | Key coverage |
|-----------|-------|-------------|
| WorkstreamAnalysisContainer | 25 | 4 query mocks, tab interaction, refetch-on-same-selection, data threading, chart color fallback |
| WorkstreamsAnalyzerContainer | 20 | Auto-select single result (render-time source tracking), selection/deselection, row click, placeholder state |
| ActivityTimelineTableContainer | 8 | Query params, loading states, column headers, empty/undefined data fallback |
| WorkstreamsFiltersContainer | 30 | Dual variant (analysis/analyzer), form submission, posthog, localStorage, isJsonEqual dedup, user filtering |
| ChatContainer | 5 | Feature flag guard (loader/redirect/render), useChatApi mock |
| AccountContainer | 6 | userInfo passthrough, role mapping (admin/team owner/member), null userInfo fallback |
| BPOContainer | 21 | 3 mutation hooks, search filtering, CRUD modals, toast on success, pending states |
| ProjectContainer | 22 | 3 mutation hooks (structurally identical to BPO), search, CRUD, toast, pending |
| ClassificationUrlsContainer | 13 | Router teamId extraction, org vs team level, search, edit modal, query params |
| TeamDetailContainer | 15 | Router query parsing, team not found, edit modal with posthog, update mutation |
| TeamsListContainer | 15 | Cross-domain cache invalidation, search, remove mutation with toast, AddTeamForm integration |
| UsersContainer | 27 | FlyoutProvider, 3 service hooks, feature flag column, search, self-removal flow, auth roles |

**Totals**: 12 specs, 207 new tests. Post-session: 176 spec files, 2238 tests passing, 2 skipped.
26/26 containers now have specs. Container test phase COMPLETE.

**Deviations**:
- Chat fixture skipped (inline data used for 3-field Message type).
- getMockedMutation not used in any spec. Skills built custom mutation mock patterns (mockImplementation to capture onSuccess callbacks) which gives better control for side-effect testing.
- ActivityTimelineTableContainer mocked by WorkstreamsAnalyzerContainer spec (justified: nested container with own service hook boundary).

**Estimate**: 3 sessions (Sessions 3-5). Actual: 3 sessions.

**Post-Session-5 Audit-Fix Pass (2026-03-01)**

HEAD: `7ccdcab8`. 2 commits (`9f34ca25` by Session 5 agent, `7ccdcab8` by orchestrating agent).

Addressed container test audit findings (3 agents audited all 26 specs, found ~130 violations):

| Commit | What | Impact |
|--------|------|--------|
| `9f34ca25` | getMockedQuery return type centralized (`as unknown as () => UseQueryResult<TData, Error>`), `isPreviousData` removed (TQ v4 remnant), `TEST_FROZEN_NOW` constant, 15 cast removals across specs | P6: ~38 casts eliminated at source |
| `7ccdcab8` | `buildMutationMock` extracted from 4 specs to shared test-utils, `afterAll(vi.useRealTimers)` added to 3 filter specs, UsersContainer 2 weak `.toBeDefined()` assertions replaced with `it.todo`, remaining cast removals (9 sites) | P6: dedup, P9: timer cleanup, P8: honest todos |

**Remaining from audit (deferred to Session 7 rewrites):**
- `vi.clearAllMocks` -> `vi.restoreAllMocks` (broke 55 tests, needs per-file spy audit)
- UsersContainer P2 violations (mocks useAuthState/usePosthogContext at module level -- requires MockedProviders auth/posthog override support, infrastructure change)
- 2 `it.todo` tests (cache invalidation + self-removal callbacks not triggerable through rendered UI)
- testId-to-role/text migration (~40 files, gradual)

Post-fix baseline: 2236 tests pass, 2 skipped, 2 todo, 176 spec files.

### Session 6: Infrastructure Tests + Mapper Specs -- COMPLETE (2026-03-01)

HEAD: `9e2660f6`. 12 commits (1 fix + 2 infrastructure + 9 mapper specs).

**Scope revision**: Mutation hooks with complex invalidation CUT from this session.
Container tests already exercise mutation hooks via module-level mocks. Individual
mutation hook specs add confidence but not meaningful coverage. Focus on fetchApi +
mappers only.

**Pre-work**:
- `d60e7542` -- Un-skipped 2 calculatePeriodEnds tests. Old assertions applied -1 day
  offset that production code does not apply for Date[] inputs. Corrected expected values
  to match actual `formatDateWithOffset` -> `formatToUtcString` pipeline.

**Infrastructure tests built**:

| File | Tests | Key coverage |
|------|-------|-------------|
| fetchApi.spec.ts | 18 | HTTPMethod exports, ApiError constructor, isApiError guard, JSON success + schema validation, schema mismatch (ZodError), non-ok response (ApiError), 404 fallback, non-JSON content-type, network error, custom headers, method/body forwarding |
| useFetchApi.spec.ts | 10 | Authenticated token injection, local mode mock-token, getIdToken failure, unauthenticated user (null), header merging, config passthrough. Used real AuthStateContext provider instead of mocking useAuthState. |

**Mapper tests built**:

| File | Tests | Key coverage |
|------|-------|-------------|
| mapRealtimeStats.spec.ts | 6 | Field mapping, null optionals, multiple users, empty input, Date.now() determinism, spread passthrough |
| mapAvgLatencyByHost.spec.ts | 14 | String-to-number conversion, median_trend calc (5 edge cases including div-by-zero -Infinity bug), null/empty input |
| mapWorkstreamsTimingInfo.spec.ts | 16 | Events stripping, uid-to-email resolution, unresolved uid filtering, children mapping, empty users |
| mapMicroworkflows.spec.ts | 6 | opportunityScore extraction, null score, summary passthrough, empty data, mixed items |
| mapTopUsedHosts.spec.ts | 10 | parseFloat conversion, null preservation, null input guard, NaN for non-numeric strings |
| mapWorkstreams.spec.ts | 10 | durationToNumber, dayjs date formatting, empty last_seen, zero/large durations |
| mapTtmForDays.spec.ts | 5 | Record-to-array with date key injection, empty record, field spread |
| mapTimeByHost.spec.ts | 9 | load_time Number() conversion, null/undefined fallback, NaN edge case |
| mapOperationalHours.spec.ts | 8 | Percentage x100 across byBpo/byProject/byTeams/combined, null preservation, falsy zero (0 treated as null by ternary), immutability |

**Totals**: 11 new spec files, 1 modified. 112 new tests. Post-session: 187 spec files, 2350 tests passing, 0 skipped, 2 todo. Statement coverage: 57.2% (up from 56.53%).

**Deviations**:
- Mutation hooks CUT (container tests already validate them via module-level mocks).
- Coverage increase was 0.67pp (56.53% -> 57.2%), less than hoped. fetchApi coverage
  did not cascade to service hooks because vitest-fetch-mock intercepts at the boundary
  -- service hooks are still counted as uncovered unless their own paths are exercised.
- mapWorkstreamsTimingInfo: the plan mentioned `parseJson` trust boundary gap with
  `as Record<string, string>` casts. The actual production code does not have `parseJson`
  calls in this mapper. The audit finding may refer to the query hook wrapper, not the
  mapper. No malformed-JSON test needed for this file.
- mapAvgLatencyByHost: median_trend `|| 0` fallback does not catch `-Infinity` when
  last_period is "0" (pre-existing production bug, documented in test).
- mapOperationalHours: `productivePercentile` and `occupancy` use truthy ternary
  (`item.occupancy ? ... : null`), so `0` values are treated as null. Pre-existing
  behavior, documented in test.

**Production bugs documented by tests** (not introduced, pre-existing):
1. mapAvgLatencyByHost: `-Infinity` when last_period is "0" and this_period is non-zero
2. mapOperationalHours: zero-valued percentiles silently become null

### Session 7: Rewrite Existing Specs -- DEFERRED (post-Phase 8)

Based on Session 2 triage. Deferred 2026-03-03: Phase 8 upgrades (React 19, Next.js 15,
Vitest 4, nuqs migration) changed the spec landscape. Several rewrite targets were
already touched by upgrade migrations. Re-triage needed before proceeding.

**Filter integration specs (4 high-value specs)**:
InsightsFilters, OpportunitiesFilters, RealtimeFilters, WorkstreamsFilters.
- Replace `getMockedQuery + mockedTeams` with fixture builders
- Replace `as ReturnType<typeof useTeamsListQuery>` casts with proper typing
- Migrate testId assertions to role/text where possible

**Component specs with worst quality scores**:
Based on Session 2 triage + 2026-03-01 audit. Specific rewrite targets:

| File | Score | Audit Source | Top Issues |
|------|-------|-------------|-----------|
| RequireLoginMaybe.spec.tsx | 3/10 | react-test (components) | Mocks own hook, conflicting strategy, shared mutable data, no cleanup |
| TenantLogin.spec.tsx | 4/10 | react-test (components) | Mocks auth provider, shared mutable data, testId assertions |
| useFeatureFlagPageGuard.spec.ts | 4/10 | react-test (shared) | 10 `as any` casts, file-level eslint-disable |
| useFeatureFlags.spec.ts | 4/10 | react-test (shared) | 9 violations, file-level disables, double casts |
| Combobox.spec.tsx | 5/10 | react-test (shared) | Mocks own utility, shared mutable data |
| calculatePeriodEnds.spec.ts | -- | Session 2 triage | 2 skipped tests with wrong expected values (date-range assertions apply -1 day offset that production code does not). Un-skip and fix assertions, or delete if redundant with passing tests. These are the only 2 skipped tests in the entire suite. |
| validateDateRange.spec.ts | 4/10 | module-test | Mocks pure sibling (getDaysDiff), asserts call counts |
| reactQueryIntegration.spec.ts | 4/10 | module-test | Mocks 2 sibling modules instead of window.NREUM |
| Table.spec.tsx (838L) | -- | Session 2 triage | Assess if stale |
| TableFilter.spec.tsx (838L) | -- | Session 2 triage | Assess if stale |

Plus any additional specs with `as any` casts or internal component mocking.

**Carry-forward test items** (from Session 5/6, must be addressed in Session 7 or later):
- `UsersContainer.spec.tsx`: 2 `it.todo` stubs for (1) cache invalidation callback
  on user addition and (2) self-removal callback (toast + router.push). These
  cannot be triggered through the rendered UI with mocked child hooks. Fix options:
  (a) deeper integration test rendering Users.tsx children with real hooks, or
  (b) unit test the callback functions extracted from the container.
- Presentational filter specs (`InsightsFilters.spec`, `OpportunitiesFilters.spec`,
  `WorkstreamsFilters.spec`): still use hardcoded date `2025-06-21T18:30:10.891Z`
  instead of `TEST_FROZEN_NOW`. 22 date assertions to update.
- `vi.clearAllMocks` -> `vi.restoreAllMocks` migration: DEFERRED (broke 55 tests).
  Needs per-file spy pattern restructuring.

**Tool**: `/refactor-react-test`.

**Estimate**: 1 session.

### Session 8: High-Value Coverage Gaps -- DEFERRED (post-Phase 8)

**Forms** (react-hook-form exception components with real validation logic):
AddTeamForm, AddUserForm, EditURLsForm

**Complex shared components** (significant rendering logic):
LoginForm, CSVButton, Table (if rewrite needed from Session 7)

**Shared hooks without specs** (ones with actual logic):
useClickAway, useEscapeKey, usePagination, useCountdown

**Shared utils without specs** (ones with transformation logic):
roleChecks, mapUserRoleName, isJsonEqual, stripHtml

Skip: column hooks, icon components, pure presentational leaves, trivial utils.

**Tool**: `/build-react-test` for components/hooks, `/build-module-test` for utils.

**Estimate**: 1 session.

### Session 9: Coverage Audit + Targeted Fill -- DEFERRED (post-Phase 8)

1. Run `pnpm test --coverage` and analyze statement/branch coverage
2. Identify critical paths still below target
3. Fill targeted gaps (highest-risk uncovered paths only)
4. Run `/audit-react-test` on a random sample of 10 new specs to verify quality
5. Final test count and convergence audit
6. Update master roadmap with Phase 7 completion status

**Exit criteria check**:
- [ ] 0 failing tests
- [ ] `pnpm build` passes
- [ ] All new/rewritten tests score 7+/10 on audit
- [ ] No stale service hook stubs remaining
- [ ] All 26 containers have specs
- [ ] Fixture builders used (not inline mocks) in all new specs
- [ ] Coverage meaningfully improved (exact target set after Session 2 triage)

**Estimate**: 1 session.

---

## 5. Lessons from Phase 4 (from roadmap)

These three lessons must be applied throughout Phase 7:

### Service hook mocking

Container specs that test components calling service hooks directly MUST use
`vi.mock('@/services/hooks/queries/<domain>')` at the module level. Passing hook
mocks through `MockedProviders` `contextsOverrides` is dead code -- the context
types silently discard unknown keys. This caused 18 silent test failures in filter
specs during Phase 4 (commit `7cc4a818`).

### Prop completeness

tsc catches missing required props, but optional props with defaults can silently
receive `undefined` when a container forgets to pass them. Container specs should
include at least one assertion per optional prop to catch this.

### Fixture migration

Replace `getMockedQuery({ data: mockedTeams })` inline mock shapes with fixture
builders (`build()` / `buildMany()` from `src/fixtures/`). This ensures mock data
matches production Zod schemas and catches shape drift between phases.

---

## 6. Exit Criteria

| Criterion | Target |
|-----------|--------|
| Failing tests | 0 |
| `pnpm build` | Passes (ECharts SSG fix) |
| Container spec coverage | 26/26 |
| Service hook stubs | 0 remaining (deleted in Session 2) |
| New/rewritten spec scores | 7+/10 on `/audit-react-test` |
| `as any` in new specs | 0 |
| Fixture builder usage | All new specs use `build()`/`buildMany()` |
| Coverage | Meaningful improvement (exact target set after Session 2 triage) |
| E2E status | Deferred to Phase 8 (existing 15 E2E specs untouched) |

**On the 60% target**: The original roadmap set 60% statement coverage. This may
or may not be the right number. Session 2 will run `pnpm test --coverage` to get
the actual baseline, and Session 9 will measure the final state. The real goal is:
all architectural boundaries (containers, service hooks with logic, filter flows)
are tested. If that lands at 45% or 55%, that is fine. Chasing a round number by
testing trivial presentational components is not worth the sessions.

---

## 7. Scope Boundaries

### In scope (Phase 7)

- All unit test work (7.2-7.5)
- Container integration tests (26 containers)
- Service hook specs (query + mutation)
- Mapper function specs
- Existing spec quality fixes
- Coverage gap fills for page_blocks, shared hooks, shared utils, shared UI
- Fixture system extension (chat domain)

### Out of scope (deferred to Phase 8)

- E2E infrastructure port from NGA (7.6)
- E2E spec updates (7.7)
- Screenshot tripwire (7.8)
- E2E constants update (7.9)
- Column hook specs (low value -- 25 files, configuration not logic)
- Icon component specs (zero value)
- Page file specs (thin wrappers, 28 files, tested via container specs)
- Storybook story specs

### Items that do NOT need specs

- `index.ts` barrel files (re-exports only)
- `constants.ts` files (static data)
- `types.ts` / `*.schema.ts` files (type definitions, tested via consumer specs)
- `keys/*.ts` (query key constants, tested via service hook specs)
- `removeRelatedInsights.ts` (mutation utility, tested via mutation hook spec)

---

## 8. Estimated Session Count

| Session | Focus | Status |
|---------|-------|--------|
| 2 | Build fix + audit + triage | COMPLETE (2026-03-01) |
| 3 | Container tests: team + systems + latency (6) | COMPLETE (2026-03-01) |
| 4 | Container tests: ops + opportunities + usage (8) | COMPLETE (2026-03-01) |
| 5 | Container tests: WS analysis + non-dashboard (12) | COMPLETE (2026-03-01) |
| 6 | Infrastructure tests + mapper specs | COMPLETE (2026-03-01) |
| 7 | Rewrite low-scoring existing specs | DEFERRED (post-Phase 8) |
| 8 | High-value coverage gaps | DEFERRED (post-Phase 8) |
| 9 | Coverage audit + targeted fill | DEFERRED (post-Phase 8) |

**Completed: 5 sessions** (Sessions 2-6). **Deferred: 3 sessions** (Sessions 7-9).

Sessions 7-9 deferred 2026-03-03. Phase 8 upgrades (React 19, Next.js 15, Vitest 4,
ESLint 10, ECharts 6, Storybook 10, Tailwind 4, nuqs filter migration) changed the
spec landscape significantly. Several Session 7 rewrite targets were already modified
by upgrade migrations. Re-triage against updated specs needed before proceeding.

The core risk surface is covered: 26/26 containers tested, all 17 mappers tested,
fetchApi + useFetchApi tested. Sessions 7-9 target quality improvement and coverage
breadth, not architectural boundary coverage.

---

## 9. Skill Protocol

All test work uses `.claude/skills/`. Do not write or rewrite tests manually.

- `/audit-react-test` on every spec file first (Session 2 drives all decisions)
- `/refactor-react-test` for specs scoring 5-6/10 (Sessions 9-10)
- `/build-react-test` for coverage gaps and deleted specs (Sessions 3-8, 11-12)
- `/audit-module-test` + `/refactor-module-test` for non-React test files
- `/build-module-test` for pure functions (mappers, utils)
- **Audit-before-write**: run the matching audit skill before running any build skill

---

## 10. Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| ECharts dynamic import breaks chart rendering | Low | Medium | Test in dev server before committing |
| Container tests expose bugs in container logic | Medium | Low | Fix bugs as found, commit separately |
| MockedProviders incompatible with container pattern | Medium | Medium | Build new test wrapper if needed |
| Session 2 audit reveals most specs need deletion | Medium | Medium | More builds needed but fewer rewrites |
| Fixture builders missing data shapes | Low | Medium | Extend fixtures on-demand via `/build-fixture` |
| Risk-based scoping misses important gaps | Low | Medium | Session 9 coverage audit catches remaining gaps |

---

## 11. Known Test Breakage Patterns

From NGA DDAU refactor. Same architectural changes were made to UF, so expect the
same categories. Watch for these rather than debugging blind.

1. **Deleted provider mocks**: Tests reference MockedXxxProvider wrappers for
   providers stripped in Phase 3. Fix: remove wrapper, test with direct props.
2. **Changed hook return shapes**: `useXxxContext().someQuery` became `useSomeQuery()`
   after Phase 2. Old mocks return wrong shape.
3. **Renamed fields**: `isRequesting` became `isFetching` (TanStack Query naming).
4. **Toast migration**: react-hot-toast became sonner. Tests mocking toast break.
5. **Vite alias gaps**: New directories (`@/fixtures`, `@/services`) need entries
   in vitest.config.mts. Missing aliases cause cryptic module-not-found errors.
6. **Copy-paste test bugs**: Some specs cloned from other components were never
   updated. Describe block names wrong component. Pre-existing bugs surfaced by refactor.
