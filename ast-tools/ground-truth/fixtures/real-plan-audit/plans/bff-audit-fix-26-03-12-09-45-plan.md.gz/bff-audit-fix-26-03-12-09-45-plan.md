# BFF Audit Fix Plan

> Created: 2026-03-13
> Track: BFF
> Branch: sd/productionize
> Source audit: ~/audits/26-03-12-09-45--user-frontend--complete-audit.md
> Status: COMPLETE
> Updated: 2026-03-13 -- Prompts rewritten with API handler design
> philosophies, tool hierarchy, skill usage (/audit-api-handler,
> /refactor-api-handler, /refactor-module-test), co-located extraction
> targets, and AST verification (ast-complexity + ast-type-safety).
> Integration scope: per-prompt
> Cleanup file: ~/plans/bff-audit-fix-26-03-12-09-45-cleanup.md

## Overview

Audit 9 BFF track: 3 G4 FAIL API handlers (CC=14-22), 2 G6 WARN data-api handlers, inline schemas, response construction, mock drift, and 2 server test P8 violations. 2 fix prompts organized by concern level.

## Dependencies

- bff-P01 (architecture/high) must complete before bff-P02 (architecture/medium) -- bff-P01 extracts handler logic in `src/pages/api/users/`. bff-P02 also touches data-api handlers in the same parent directory. Run bff-P01 first to avoid conflicts.

### Cross-track dependencies

- bff-P01 extracts pure functions from handlers. If any extracted function changes a shared type in `src/shared/types/`, FE prompts that consume that type should run after. This is unlikely since the extractions are internal restructuring, not API shape changes.
- No other cross-track dependencies

## Prompt Sequence

| #       | File                                                    | Category     | Concern | Fixes | Est. Commits |
| ------- | ------------------------------------------------------- | ------------ | ------- | ----- | ------------ |
| bff-P01 | bff-audit-fix-26-03-12-09-45-P01-architecture-high.md   | Architecture | High    | 5     | 5            |
| bff-P02 | bff-audit-fix-26-03-12-09-45-P02-architecture-medium.md | Architecture | Medium  | 6     | 5            |

## Verification Commands

```bash
pnpm tsc --noEmit
pnpm build
pnpm test --run
pnpm test:integration
npx eslint . --max-warnings 0
```

## Verification Checklist

| #       | Agent Ran PW?  | Orchestrator Ran PW? | Results Match?                              | PASS/FAIL |
| ------- | -------------- | -------------------- | ------------------------------------------- | --------- |
| bff-P01 | Yes (204p/11f) | Yes (204p/4f)        | Partial (count mismatch, substance matches) | PASS      |
| bff-P02 | Yes (204p/4f)  | Yes (204p/4f)        | Yes                                         | PASS      |

## Progress

| #       | Status | HEAD     | Notes                                                                                             |
| ------- | ------ | -------- | ------------------------------------------------------------------------------------------------- |
| bff-P01 | PASS   | b62fe279 | 6 commits, CC reductions confirmed, integration count mismatch (11 vs 4) but 0 user-mgmt failures |
| bff-P02 | PASS   | 63a06485 | 5 commits, CC reductions confirmed, integration 204p/4f matches independent run                   |
