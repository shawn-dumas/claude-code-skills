# Backlog: AST Tools Cleanup

> Created: 2026-03-12
> Completed: 2026-03-12
> Integration scope: none
> Branch: sd/productionize
> Complexity: D4 S3 Z4 = 3.7
> Nearest: JSDoc Domain Types (3.3), Orphan Backlog (4.3)

Cleanup of the AST tool suite in `scripts/AST/` based on the G1-G10 and
P1-P10 audit performed 2026-03-12. All items are internal tooling -- no
production UI, no API routes, no integration test scope.

## Items

| #   | Item                                                                                                                    | Type             | Files | Effort  | Prompt | Status |
| --- | ----------------------------------------------------------------------------------------------------------------------- | ---------------- | ----- | ------- | ------ | ------ |
| B1  | Extract `truncateText` to `shared.ts`, remove 8 inline copies                                                           | structural dedup | 9     | low     | 01     | done   |
| B2  | Extract `getContainingFunctionName` to `shared.ts`, consolidate 5 variants                                              | structural dedup | 6     | medium  | 01     | done   |
| B3  | Remove dead exports: `CliArgs`, `resetProject`, `KNOWN_FLAG_NAMES`                                                      | dead code        | 3     | low     | 01     | done   |
| B4  | Un-export 7 `analyze*Directory` fns (keep as private, called by `main()`)                                               | dead code        | 8     | low     | 01     | done   |
| B5  | Delete dead loop at `ast-react-inventory.ts:815-822`                                                                    | dead code        | 1     | trivial | 01     | done   |
| B6  | Add logging or narrow catches in `project.ts:61`, `ast-imports.ts:422,487,513,568`, `ast-test-analysis.ts:249,852`      | bug fix          | 3     | low     | 02     | done   |
| B7  | Decompose `findViolationsInReturn` (CC=40) in `ast-jsx-analysis.ts`                                                     | complexity       | 1     | medium  | 03     | done   |
| B8  | Decompose `detectDeadExports` (CC=30) in `ast-imports.ts`                                                               | complexity       | 1     | medium  | 03     | done   |
| B9  | Decompose `findAccesses` (CC=30) in `ast-storage-access.ts`                                                             | complexity       | 1     | medium  | 03     | done   |
| B10 | Decompose `findUsages` (CC=29) in `ast-feature-flags.ts`                                                                | complexity       | 1     | medium  | 03     | done   |
| B11 | Decompose `findViolations` (CC=27) in `ast-type-safety.ts`                                                              | complexity       | 1     | medium  | 04     | done   |
| B12 | Decompose `findFunctions` (CC=27) + `computeComplexity` (CC=18) in `ast-complexity.ts`                                  | complexity       | 1     | medium  | 04     | done   |
| B13 | Decompose `detectComponents` (CC=32) + `classifyHook` (CC=24) + `extractUseEffects` (CC=20) in `ast-react-inventory.ts` | complexity       | 1     | large   | 04     | done   |
| B14 | Unify `detectComponents` -- reconcile private copy in `ast-react-inventory.ts` with `shared.ts` version                 | structural dedup | 2     | medium  | 04     | done   |
| B15 | Type `details` field in `ast-data-layer.ts` -- replace `Record<string, string>` with typed interface                    | types            | 2     | low     | 02     | done   |
| B16 | Move shared `const result` into `it` blocks in 7 test files                                                             | test improvement | 7     | low     | 05     | done   |
| B17 | Add `analyze*Directory` tests for 6 untested directory functions                                                        | test improvement | 6     | medium  | 05     | done   |

## Dependency Graph

```
Prompt 01 (extract shared helpers, remove dead exports/code)
     |
     v
Prompt 02 (fix silent catches, type details field)
     |
     v
Prompt 03 (decompose high-CC functions: jsx, imports, storage, flags)
     |
     v
Prompt 04 (decompose high-CC functions: type-safety, complexity, react-inventory + unify detectComponents)
     |
     v
Prompt 05 (test improvements: P5 fix, directory fn coverage)
     |
     v
Prompt 06 (final validation)
```

**Ordering rationale:**

- Prompt 01 extracts shared helpers. All later prompts that decompose
  functions will import from `shared.ts`, so this must come first.
- Prompt 02 fixes catch blocks and types. Independent of 01 conceptually,
  but sequenced after because B4 un-exports `analyze*Directory` in 01 and
  B17 in 05 needs to know the final export surface.
- Prompts 03-04 split the complexity decomposition into two batches
  (4 files each) to keep each prompt under 15 changes.
- Prompt 04 includes B14 (unify detectComponents) because the
  decomposition of `ast-react-inventory.ts` is the right time to
  reconcile with `shared.ts`.
- Prompt 05 fixes tests after all production code is stable.
- Prompt 06 validates everything.

## Prompt Sequence

| #   | Prompt                                                    | Items              | Prerequisite | Status |
| --- | --------------------------------------------------------- | ------------------ | ------------ | ------ |
| 1   | Extract shared helpers + dead code                        | B1, B2, B3, B4, B5 | none         | done   |
| 2   | Silent catches + type details                             | B6, B15            | Prompt 1     | done   |
| 3   | Complexity decomposition batch 1                          | B7, B8, B9, B10    | Prompt 2     | done   |
| 4   | Complexity decomposition batch 2 + unify detectComponents | B11, B12, B13, B14 | Prompt 3     | done   |
| 5   | Test improvements                                         | B16, B17           | Prompt 4     | done   |
| 6   | Final validation                                          | --                 | Prompt 5     | done   |

## Final State

> HEAD: 7c2c4e67
> Tests: 13 files, 249 passed
> tsc: 0 errors
> Build: clean
> ESLint: 5 pre-existing errors (useFeatureFlags.spec.ts, unrelated), 0 warnings
> Max CC in targeted functions: all <= 10
> Max CC in pre-existing (out-of-scope) functions: 24 (classifyCallExpression in ast-side-effects.ts)
> Remaining cleanup items: see ast-tools-cleanup-cleanup.md (all non-blocking, future pass)
>
> Note on B4: The 7 `analyze*Directory` functions were un-exported in Prompt 01
> then re-exported in Prompt 05 to enable directory function test coverage.
> They are exported for test consumption, not part of the programmatic API
> used by skills (which import `analyze*` single-file functions).
