# Feature: AST Tool Enhancements + Refactor Intention Matcher

> Port ast-test-parity techniques to all AST tools and build a post-refactor intention matching system
> Complexity: D7 S5 Z7 = 6.3 (originally D8 S8 Z8 = 8.0, re-scored against calibrated anchors)
> Duration: F4 C6 = 24h (12-48h) -- actual: F3 C1 = 2.4h
> Nearest: NGA: Unify Data Layer (6.7), DDAU Exception Elimination (6.0)
> Integration scope: none
> Status: Complete. Archived 2026-03-14.

## Context

The ast-test-parity tool (built 2026-03-13/14) introduced several novel
techniques that no other AST tool uses: factory pattern detection,
cross-file assertion resolution, multi-signal intent matching, boundary
confidence bands, quantitative scoring, and git branch reading. This plan
ports those techniques to all applicable tools and then uses them as the
foundation for a new refactor intention matcher -- a tool that verifies
behavioral preservation after code refactors by comparing AST signals
before and after the rewrite.

### Why the intention matcher matters

The PoC pipeline produces working but poorly structured code. Refactor
skills reshape it into DDAU-compliant, testable, maintainable code. The
intention matcher is structural proof that the reshaping preserved the
behavior the PM showed the CEO. Current verification (tsc + tests + build)
catches type errors and test regressions but cannot detect silently dropped
side effects, removed hook calls, or changed rendering contracts.

### Design principles

1. **HEAD-vs-dirty comparison.** Always compare `git show HEAD:<path>`
   against the working tree. No cross-branch comparison.
2. **1-to-N file splits.** Refactors frequently split one file into
   many. Every intention from the "before" set must appear somewhere in
   the "after" set.
3. **Skill-provided file lists.** The refactor skill knows which files it
   created/modified. It passes `{ before: string[], after: string[] }` to
   the matcher. No heuristic file discovery.
4. **Audit context for intentional removal.** The audit told the skill
   which violations to fix. Removing a side effect that was flagged as a
   violation is INTENTIONALLY_REMOVED. Removing one that was not flagged
   is ACCIDENTALLY_DROPPED.
5. **Conservative bias.** When uncertain, flag as ACCIDENTALLY_DROPPED.
   False positives (flagging something that was intentionally removed) are
   cheaper than false negatives (missing something that was accidentally
   dropped). Target the same 3:1+ FP:FN ratio as the parity tool.
6. **Union of all signals.** The matcher runs all observation tools on
   both versions and compares the full signal inventory, not a curated
   subset. Signal weights are configurable per observation kind.
7. **Fixture-tuned weights via generalized calibration.** Initial
   weights are heuristic. A `/calibrate-ast-interpreter` skill measures
   accuracy against accumulated fixtures and tunes weights. The skill
   accepts `--tool intent` or `--tool parity`, running the same 10-step
   workflow for any interpreter with configurable weights. The same
   system is used for initial tuning (on synthetic fixtures) and ongoing
   recalibration (as feedback fixtures accumulate from refactor and test
   porting work). Accuracy is measured per tool, with separate tracking
   by fixture source (synthetic, feedback, git-history).

   **Why the parity tool needs continuous calibration:** QE is shipping
   new e2e tests at ~2x/week cadence (14 test commits Nov 2025 - Mar
   2026, 8 in Feb alone). Each needs porting. The parity tool runs on
   every port. Its hand-tuned 0.4/2.0 thresholds will drift as QE's
   test patterns evolve. The feedback loop catches this drift.

## Design

### New shared infrastructure

| File | Purpose |
|------|---------|
| `scripts/AST/types.ts` (additions) | `AnyObservation` union type, `IntentSignal` types, `IntentReport` |
| `scripts/AST/shared.ts` (additions) | `resolveCallName()`, `resolveTemplateLiteral()`, `computeBoundaryConfidence()` |
| `scripts/AST/tool-registry.ts` | Tool name -> analyze function map, `runAllObservers(sourceFile)` |
| `scripts/AST/git-source.ts` | `gitShowFile()`, `gitListFiles()` extracted from ast-test-parity |

### New tools

| File | Type | Purpose |
|------|------|---------|
| `scripts/AST/ast-refactor-intent.ts` | Observation tool | Reads HEAD + dirty, runs all observers, produces paired signal inventory |
| `scripts/AST/ast-interpret-refactor-intent.ts` | Interpreter | Matches signals, classifies as PRESERVED/INTENTIONALLY_REMOVED/ACCIDENTALLY_DROPPED/ADDED |

### New skill

| Skill | Purpose |
|-------|---------|
| `/calibrate-ast-interpreter` | Generalized calibration skill for any interpreter with fixture-tuned weights. Accepts `--tool intent` or `--tool parity`. Measures accuracy against accumulated fixtures, tunes weights/thresholds, updates config. Used for both initial calibration and ongoing recalibration as feedback fixtures accumulate. |

### Ground truth infrastructure

| Directory | Purpose |
|-----------|---------|
| `scripts/AST/ground-truth/` | Fixture pairs for accuracy measurement and weight calibration |
| `scripts/AST/ground-truth/fixtures/synth-intent-*` | Synthetic fixtures for intention matcher (designed refactor scenarios) |
| `scripts/AST/ground-truth/fixtures/synth-parity-*` | Synthetic fixtures for parity tool (designed test migration scenarios) |
| `scripts/AST/ground-truth/fixtures/feedback-*` | Feedback fixtures (captured when either interpreter misclassifies during real work) |
| `scripts/AST/ground-truth/fixtures/git-*` | Git-history fixtures (extracted from past refactor/migration commits) |

### Modified tools (enhancements)

| File | Enhancement |
|------|-------------|
| `ast-test-analysis.ts` | Factory pattern detection + expansion for Vitest test blocks |
| `ast-test-analysis.ts` | Helper delegation tracking (observation-level) |
| `ast-interpret-test-quality.ts` | Cross-file assertion resolution via helper index |
| `ast-data-layer.ts` | Template literal resolution for query key factories |
| `ast-interpret-dead-code.ts` | Boundary confidence bands |
| `ast-interpret-effects.ts` | Boundary confidence bands |
| `ast-interpret-hooks.ts` | Boundary confidence bands |
| `ast-interpret-ownership.ts` | Boundary confidence bands |
| `ast-interpret-template.ts` | Boundary confidence bands |
| `ast-interpret-test-quality.ts` | Boundary confidence bands |
| `ast-config.ts` | New `intentMatcher` section (signal weights, thresholds) |

### New test fixtures (negative fixtures for tools that lack them)

| File | Tool |
|------|------|
| `__tests__/fixtures/complexity-negative.ts` | ast-complexity |
| `__tests__/fixtures/imports-negative.ts` | ast-imports |
| `__tests__/fixtures/interpret-hooks-negative.tsx` | ast-interpret-hooks |
| `__tests__/fixtures/interpret-ownership-negative.tsx` | ast-interpret-ownership |

### Modified skills (intention matcher integration)

| Skill | Change |
|-------|--------|
| `refactor-react-component/SKILL.md` | Add intention matcher post-step in Step 5 |
| `refactor-react-hook/SKILL.md` | Add intention matcher post-step in Step 6 |
| `refactor-react-service-hook/SKILL.md` | Add intention matcher post-step in Step 5 |
| `refactor-react-provider/SKILL.md` | Add intention matcher post-step in Step 5 |
| `refactor-react-route/SKILL.md` | Add intention matcher post-step in Step 5 |
| `refactor-module/SKILL.md` | Add intention matcher post-step between Step 5 and Step 6 |
| `refactor-api-handler/SKILL.md` | Add intention matcher post-step in Step 5 |

### Modified skills (parity tool feedback loop)

| Skill | Change |
|-------|--------|
| `refactor-playwright-test/SKILL.md` | Add parity feedback fixture creation on misclassification |
| `build-playwright-test/SKILL.md` | Add parity comparison as post-generation validation |

### Skills NOT modified

| Skill | Reason |
|-------|--------|
| `refactor-react-test` | Test refactors intentionally change behavior; intention matcher would false-positive |
| `refactor-module-test` | Same reason |

## Implementation Phases

| # | Phase | Prompt | What | Depends on | Status |
|---|-------|--------|------|-----------|--------|
| 1 | Foundation | ast-enhance-01-foundation | Shared utilities, types, tool registry, git-source extraction | none | pending |
| 2 | Test analysis | ast-enhance-02-test-analysis | Factory detection + helper delegation in ast-test-analysis | Phase 1 | pending |
| 3 | Test quality | ast-enhance-03-test-quality | Cross-file assertion resolution in ast-interpret-test-quality | Phase 2 | pending |
| 4 | Data layer + negative fixtures | ast-enhance-04-data-layer-negatives | Template literal resolution in ast-data-layer, negative fixtures for 4 tools | Phase 1 | pending |
| 5 | Interpreter scoring | ast-enhance-05-interpreter-scoring | Boundary confidence bands in all 6 interpreters + accuracy infrastructure | Phase 1 | pending |
| 6 | Intent observation | ast-enhance-06-intent-observation | ast-refactor-intent.ts -- the observation tool | Phase 1 | pending |
| 7 | Intent interpretation | ast-enhance-07-intent-interpretation | ast-interpret-refactor-intent.ts -- the interpreter | Phase 6 | pending |
| 8 | Calibration system | ast-enhance-08-ground-truth | Build synthetic fixtures (intent + parity), build /calibrate-ast-interpreter skill, run initial calibration for both tools | Phase 7 | pending |
| 9 | Skill integration | ast-enhance-09-skill-integration | Formalize file lists, add intent matcher to 7 refactor skills, add parity feedback to 2 playwright skills | Phase 7 | pending |
| 10 | Validation | ast-enhance-10-validation | End-to-end dry run on a real refactor, fix gaps | Phase 8, 9 | pending |

### Dependency graph

```
Phase 1 (foundation)
  |
  +---> Phase 2 (test analysis) ---> Phase 3 (test quality)
  |
  +---> Phase 4 (data layer + negatives)
  |
  +---> Phase 5 (interpreter scoring)
  |
  +---> Phase 6 (intent observation) ---> Phase 7 (intent interpretation)
                                              |
                                              +---> Phase 8 (calibration system)
                                              |
                                              +---> Phase 9 (skill integration)
                                              |
                                              +---> Phase 10 (validation)
```

Phases 2, 4, 5, and 6 are independent after Phase 1 but execute
sequentially per orchestration protocol (no parallel prompts).

## Verification

After all phases complete:

1. All 678 existing AST tests pass (677 passing + 1 pre-existing
   ast-config.spec.ts failure not caused by this work)
2. All new tests pass (estimated 40-60 new tests across all prompts)
3. `pnpm tsc --noEmit` clean
4. `pnpm build` clean
5. `npx eslint . --max-warnings 0` clean
6. Intention matcher produces correct classifications on synthetic
   fixtures (accuracy >= 70% after calibration)
7. Parity tool produces correct classifications on synthetic fixtures
   (accuracy >= 70% after calibration)
8. `/calibrate-ast-interpreter` skill exists with `--tool intent` and
   `--tool parity` support, validated via initial calibration of both
9. Every refactor skill SKILL.md includes the intention matcher step
   with false-positive fixture creation feedback loop
10. refactor-playwright-test and build-playwright-test include the
    parity tool feedback loop
11. Skills synced to standalone repo
