# Orphan Backlog

> Created: 2026-03-08
> Completed: 2026-03-09
> Branch: sd/productionize
> Status: COMPLETE
> Final HEAD: 54876edd
> Integration scope: none
> Dependency: playwright-hardening must complete first (O4 deferred to avoid file conflict)

Resolve orphaned cleanup items accumulated across 7 completed orchestrations
(backlog, BFF lift-and-shift, coverage-75, qa-test-migration, post-audit,
test-expansion, integration-cleanup, consistency-remediation, playwright-remediation).

## Triage Summary

Scanned 6 active plan files, 6 cleanup files, and 150 archived files.
Found 205 unchecked items across all sources.

| Category | Count | Disposition |
|----------|-------|-------------|
| Moot (files deleted, already fixed, or not actually broken) | 12 | Closed |
| Covered by in-flight hardening | 6 | Excluded |
| Deferred (hardening file conflict) | 1 | O4 -- fix after hardening |
| Actionable orphans | 9 | This plan |

### Moot Items (closed)

| Item | Source | Why moot |
|------|--------|----------|
| `[...endpoint].ts` catch-all mock handler | backlog-cleanup | Deleted in BFF migration |
| `urls_registry.ts` rename | bff-cleanup | Already renamed in consistency remediation |
| Combobox/Listbox/Select test helper exports | backlog-cleanup | Actually export testIds (production constants), not test helpers |
| `reactQueryIntegration.ts:36` deprecated onError | backlog-cleanup | Uses correct cache-level API (TanStack Query v5), not deprecated |
| `docs/bff.md` stale references (server-only, catch-all) | bff-cleanup | Both already updated |
| `useChatApi.ts` needs spec | backlog-cleanup | Already has spec at new path |
| `posthog-mock.ts` LoginType duplication | backlog-cleanup | Not duplicated -- dynamic import + re-export |
| `Select.tsx:18` mutable array prop | backlog-cleanup | Already uses `readonly` |
| `useUsersTableColumns.tsx` reused test IDs | backlog-cleanup | Actually uses 3 distinct IDs |
| Old `useChatApi.ts` at page_blocks path | bff-cleanup | Missing, refactored away |
| Various BFF prompt deviations (non-null assertion, eslint, etc.) | bff-cleanup | Documenting decisions, not requesting changes |
| Various integration-cleanup deviations | integration-cleanup | Documenting decisions, not requesting changes |

### Deferred Items

| Item | Source | Why deferred |
|------|--------|--------------|
| O4: Barrel bypass imports in OpportunitiesFiltersContainer.tsx | backlog-cleanup | File touched by in-flight hardening H7 (nuqs race fix). Fix after hardening lands. |
| formatDuration.ts label cosmetic (`sec`/`min` vs `s`/`m`) | qa-migration-cleanup | Product decision, not a code issue |
| Sidebar role-gating test gap | test-expansion-cleanup | Requires product input on expected behavior |
| components.spec.ts test.skip (tab refresh) | integration-cleanup | Blocked by Firebase emulator session persistence limitation |
| export.spec.ts test.skip (system latency export) | integration-cleanup | Export button may have been removed from this tab |
| Sidebar/SidebarLink/SignedInPageShell function coverage | coverage-75-cleanup | Headless UI internals, low value |
| usePosthogClient.ts module-level code | coverage-75-cleanup | Untestable without env stubbing before import |
| 8 domain fixtures without dedicated specs | coverage-75-cleanup | Low priority, partial coverage from scenario.spec |
| Schema files at 0% stmt coverage | coverage-75-cleanup | Exercised transitively, low standalone value |
| nextRouterMocks.ts refactor to use builder functions | post-audit-cleanup | Low priority consistency improvement |

## Risk Assessment (2026-03-08)

Pre-execution coverage audit revealed:

- **O1** scope is larger than estimated (~15 files, not ~8). Six
  production files use `dateRange: []` as a vestigial placeholder; two
  use `.filter()` returning `Date[]`; three Zod schemas change runtime
  validation behavior. Two of three validation schemas had no specs.
  Validation specs added pre-execution to establish a green baseline.
- **O2** is not a production bug. The `'unknown'`/`'unclassified'`
  mismatch is an intentional two-domain architecture with explicit
  bridge logic. Reframed to documentation + test coverage.
- **O7** is moot. BPO already has `updated: 'BPO updated successfully'`
  in its toast config. File also moved from `bpoSettings/` to `BPO/`
  during consistency normalization.
- **O8** is moot. All three target spec files already use centralized
  fixture builders. `buildHostsData`, `buildProductivityDayStatsData`,
  and `buildFilteredMetrics` all exist and are exported.
- **O9** is moot. Zero instances of `as unknown as ReturnType` remain
  in the 5 target files. Cleaned up during mutation normalization
  (`e7b60920`) and invalidateQueries sequencing (`b369bd98`).

## Items

| # | Item | Type | Files | Prompt | Status |
|---|------|------|-------|--------|--------|
| O1 | `filterFormStates.ts` dateRange `Date[]` -> `[Date, Date]` tuple | type-safety | ~15 | 02 | done |
| O2 | Document `ClassificationUrlsBlock` category two-domain architecture | documentation | ~3 | 02 | done |
| O3 | `Table.types.ts` columnId type lie -- remove from public API | dead-code | ~3 | 02 | done |
| O5 | `calculatePeriodEnds.ts` timezone assumption documentation | documentation | ~1 | 01 | done |
| O6 | Verify act() warnings gone (FavoriteUsage, RelayUsage specs) | verification | ~2 | 01 | done |
| O7 | ~~Verify BPO toast present~~ | ~~verification~~ | -- | -- | moot |
| O8 | ~~Productivity fixture builders + spec migration~~ | ~~test-infra~~ | -- | -- | moot |
| O9 | ~~15 double casts in 5 test files~~ | ~~test-quality~~ | -- | -- | moot |
| O10 | `Message` type duplication (chat types.ts vs useChatApi.ts) | dedup | ~2 | 01 | done |

## Dependency Graph

```
00 (tree cleanup -- prerequisite)
    |
    v
01 (quick verifications + small fixes)
    |
    v
02 (type safety fixes -- highest risk, cascading)
    |
    v
04 (final validation)
```

All content prompts (01-03) are independent of each other, but sequenced
for clean verification. Prompt 02 is highest risk (dateRange cascade) so
it runs after the easy wins in 01 establish a clean baseline.

## Prompt Sequence

| # | Prompt | Items | Prereq | Mode | Status |
|---|--------|-------|--------|------|--------|
| 00 | Tree cleanup | -- | none | Manual | pending |
| 01 | Quick verifications + small fixes | O5, O6, O10 | 00 | Auto | pending |
| 02 | Type safety + documentation | O1, O2, O3 | 01 | Manual | pending |
| 03 | ~~Test quality (double casts)~~ | ~~O9~~ | -- | -- | eliminated |
| 04 | Final validation | -- | 02 | Auto | pending |

### Mode Rationale

- **00 Manual**: User handles WIP commit cleanup (stash/commit/amend).
- **01 Auto**: Small, mechanical tasks. Verify act() warnings, add a
  comment, deduplicate a type.
- **02 Manual**: dateRange tuple cascades into ~15 files including 6
  `dateRange: []` sites, 2 `.filter()` sites, 3 Zod schemas, and new
  pre-execution validation specs. O2 requires reading the two-domain
  architecture to write an accurate comment. columnId removal needs
  careful API migration check -- existing comments in TableBody.tsx
  reference "two columnId consumers" but no external callers remain.
- **03 Eliminated**: O9 (double casts) resolved during prior commits.
- **04 Auto**: Read-only validation run.

## Verification Commands

Standard checks after every prompt:

```bash
git log --oneline -10
pnpm tsc --noEmit
pnpm test --run 2>&1 | tail -5
pnpm build 2>&1 | tail -5
npx eslint . --max-warnings 0 2>&1 | tail -3
```

## Verification Checklist

| # | tsc | Tests | Build | ESLint | PASS/FAIL |
|---|-----|-------|-------|--------|-----------|
| 00 | 0 errors | 316/3399 | clean | clean | PASS |
| 01 | 0 errors | 316/3399 | clean | clean | PASS |
| 02 | 0 errors | 316/3398 | clean | clean | PASS |
| 03 | -- | -- | -- | -- | ELIMINATED |
| 04 | 0 errors | 316/3398 | clean | clean | PASS |
