# FE Audit Fix Plan

> Created: 2026-03-13
> Track: FE
> Branch: sd/productionize
> Source audit: ~/audits/26-03-12-09-45--user-frontend--complete-audit.md
> Status: COMPLETE
> Integration scope: none
> Cleanup file: ~/plans/fe-audit-fix-26-03-12-09-45-cleanup.md
> Completed: 2026-03-13

## Scorecard

| Metric                    | Value                                                      |
| ------------------------- | ---------------------------------------------------------- |
| Prompts planned           | 7                                                          |
| Prompts passed            | 7 (100%)                                                   |
| Prompts failed            | 0                                                          |
| Prompts re-dispatched     | 1 (fe-P03: context exhaustion, reset and re-run)           |
| Total commits             | 19                                                         |
| Fixes planned             | 43                                                         |
| Fixes applied             | 42 (Fix 5 of fe-P06 already present)                       |
| Cleanup items accumulated | 4                                                          |
| Cleanup items actionable  | 1 (fixed inline by orchestrator)                           |
| Cleanup items deferred    | 3 (blocked on DDAU refactoring)                            |
| Test files before         | 319                                                        |
| Test files after          | 323 (+7 new, -3 deleted hooks)                             |
| Test count before         | 3425                                                       |
| Test count after          | 3444 (+19 net)                                             |
| tsc errors                | 0 throughout                                               |
| ESLint warnings           | 0 throughout                                               |
| Build failures            | 0 (1 stale-cache false alarm, resolved with clean rebuild) |

## Summary by category

**Test Gap (fe-P01, fe-P05, fe-P07):** 6 DELETE-candidate specs rewritten from scratch, 8 existing specs fixed (callback-existence replaced with visible-outcome assertions, internal mocks removed, Date.now spies replaced with useFakeTimers), 7 new spec files created covering column hooks, getTeamsItems, EditAssignmentModal, and RHF wrappers. 3 existing 8flow specs cleaned up by removing internal component mocks.

**Architecture (fe-P03, fe-P06):** 3 containers reduced from CC 27-34 to CC 9-13. 2 column hooks reduced from CC 13-29 to CC 3-5. JSX flattened in 2 components. useTypewriter hook extracted. useFeatureFlags IIFE eliminated. useClickAway predicates extracted. mapActivityTimeline switch replaced with lookup map. tableStorage error swallowing fixed with boolean return. FC type annotation removed.

**Bug (fe-P02):** calculatePeriodEnds now throws on invalid dates (G10). Parameter type narrowed from Date[] to [Date, Date]. tar vulnerability resolved via pnpm override.

**Dead Code (fe-P04):** 3 dead hook directories deleted (useCountdown, useFilterCollapse, useHydrated). clearSortingState deleted (zero callers). 2 dead exports unexported.

## Incidents

**fe-P03 context exhaustion:** First dispatch froze at 08:07:56 after 48 tool calls and 6.5 minutes. Agent was mid-Fix-3 debugging a null/undefined type mismatch in ProductivityByDateContainer. Partial work left uncommitted (3 modified files, 4 new files, 1 tsc error). Forensic analysis via session DB confirmed stall point. Reset with `git checkout -- . && git clean -fd` and re-dispatched with per-fix commits and explicit context-saving instructions. Second attempt completed all 5 fixes in 5 commits.

## Dependencies

- fe-P04 (dead code) should run before fe-P05 (test gap/medium) -- fe-P04 deletes hooks in same directory as fe-P05 test fixes
- fe-P01 (test gap/high) should run before fe-P07 (test gap/low) -- both touch 8flow tests
- All other prompts are independent within their tier

### Cross-track dependencies

- bff-P01 must complete before fe-P03 if any extracted BFF pure functions change shared type signatures (unlikely but possible)
- No other cross-track dependencies

## Prompt Sequence

| #      | File                                                   | Category     | Concern | Fixes | Est. Commits |
| ------ | ------------------------------------------------------ | ------------ | ------- | ----- | ------------ |
| fe-P01 | fe-audit-fix-26-03-12-09-45-P01-testgap-high.md        | Test Gap     | High    | 6     | 3            |
| fe-P02 | fe-audit-fix-26-03-12-09-45-P02-bug-medium.md          | Bug          | Medium  | 2     | 2            |
| fe-P03 | fe-audit-fix-26-03-12-09-45-P03-architecture-medium.md | Architecture | Medium  | 5     | 4            |
| fe-P04 | fe-audit-fix-26-03-12-09-45-P04-deadcode-medium.md     | Dead Code    | Medium  | 6     | 1            |
| fe-P05 | fe-audit-fix-26-03-12-09-45-P05-testgap-medium.md      | Test Gap     | Medium  | 8     | 3            |
| fe-P06 | fe-audit-fix-26-03-12-09-45-P06-architecture-low.md    | Architecture | Low     | 10    | 4            |
| fe-P07 | fe-audit-fix-26-03-12-09-45-P07-testgap-low.md         | Test Gap     | Low     | 6     | 4            |

## Verification Checklist

Integration scope: none. No Playwright tests required.

| #      | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
| ------ | ------------- | -------------------- | -------------- | --------- |
| fe-P01 | n/a           | n/a                  | n/a            | PASS      |
| fe-P02 | n/a           | n/a                  | n/a            | PASS      |
| fe-P03 | n/a           | n/a                  | n/a            | PASS      |
| fe-P04 | n/a           | n/a                  | n/a            | PASS      |
| fe-P05 | n/a           | n/a                  | n/a            | PASS      |
| fe-P06 | n/a           | n/a                  | n/a            | PASS      |
| fe-P07 | n/a           | n/a                  | n/a            | PASS      |

## Progress

| #      | Status    | HEAD     | Notes                                                                                                                                       |
| ------ | --------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| fe-P01 | completed | 6ff1149e | PASS. 3 commits. 6 spec files deleted and rewritten. 3 cleanup items added. Deviation: Fixes 4-5 used build-react-test (correct for hooks). |
| fe-P02 | completed | 8c39db63 | PASS. 2 commits. calculatePeriodEnds: tuple type + NaN guard. tar override added for firebase-tools chain.                                  |
| fe-P03 | completed | ecca89c6 | PASS. 5 commits. 3 containers refactored (CC 34->9, 32->13, 27->9), 2 column hooks refactored (CC 13->5, 8->3). 0 cleanup items.            |
| fe-P04 | completed | c39b210b | PASS. 1 commit. 3 hook dirs deleted, 3 symbols unexported (clearSortingState deleted entirely -- zero callers).                             |
| fe-P05 | completed | 5d96edf4 | PASS. 3 commits. 8 test files fixed. 1 cleanup item. Deviations: sonner boundary mock, Fix 8 had no Date.now spy.                           |
| fe-P06 | completed | 63cc29b7 | PASS. 3 commits. 10 fixes (9 applied, Fix 5 already present). JSX flattened, hooks extracted, lookup map, boolean return.                   |
| fe-P07 | completed | 533be7e9 | PASS. 2 commits. 7 new spec files (39 new tests), 3 existing specs fixed. 0 cleanup items.                                                  |
