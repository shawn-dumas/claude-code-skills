# Backlog Cleanup

## Prompt 1: Dead Code + Infrastructure Sweep
- [ ] `src/shared/ui/Combobox/index.ts`: barrel exports test helpers (comboboxTestHelpers, mockedItems) from testUtils.ts -- test helpers should not be in production barrel
- [ ] `src/shared/ui/Listbox/index.ts`: barrel exports test helpers (mockedOptions, listboxHelpers) from testUtils.ts -- test helpers should not be in production barrel
- [ ] `src/shared/ui/Select/index.ts`: barrel exports test helpers (selectHelpers, mockedSelectItems) from testUtils.ts -- test helpers should not be in production barrel
- [ ] `src/shared/utils/newrelic/reactQueryIntegration.ts:36`: onError callback in getNewRelicQueryOptions is deprecated in TanStack Query v5 (no longer called) -- dead code inside live function

## Prompt 3: Users Feature Fixes
- [ ] `src/ui/page_blocks/users/UsersTable/useUsersTableColumns.tsx:60,66,72`: `SpecificTeamIds.USER_EMAIL_IN_USERS_TABLE` test ID is reused for `name` and `role` columns -- should have distinct test IDs per column

## Prompt 4: Mock Handler Bug Fix + Cleanup
- [ ] `src/pages/api/mock/[...endpoint].ts:219-226`: `users/tenant/getByEmail` response is an untyped inline object -- add `satisfies` annotation when TenantSchema exists
- [ ] `src/pages/api/mock/[...endpoint].ts:230-240`: `users/user-info` response is an untyped inline object -- add `satisfies` annotation when UserInfoSchema exists

## Prompt 5: Cross-Cutting Type Safety Fixes
- [x] `src/shared/utils/tableStorage.ts:37`: still requires `as unknown as TablesStates` double cast because the schema is intentionally permissive (z.record of z.unknown) -- tighten the schema to match TablesStates shape if incremental writes can be made schema-aware (RESOLVED in audit-fix-07)

## Prompt 6: Chat useChatApi Migration
- [ ] `src/ui/services/hooks/mutations/chat/useChatApi/useChatApi.ts`: needs a spec file (useChatApi.spec.ts) -- old spec deleted because it tested the pre-migration API surface; new spec should use fetchMock + QueryClientProvider wrapper per build-react-service-hook skill
- [ ] `src/ui/page_blocks/dashboard/chat/types.ts`: Message type is structurally duplicated in ChatMessage at services/hooks/mutations/chat/useChatApi.ts -- consider moving to @/shared/types/chat.ts if cross-domain usage grows

## Prompt 7: Shared Utils Arch Fixes
- [ ] `src/shared/utils/calculatePeriodEnds/calculatePeriodEnds.ts`: `calculatePeriodEndsByDates` passes through `formatDateWithOffset` which subtracts `getTimezoneOffset()` -- this is fragile when the input Date was already UTC-constructed (e.g. from dayjs.utc().toDate()). Consider accepting an explicit timezone offset or documenting the assumption.
- [ ] `src/shared/test-utils/posthog-mock.ts:52-56`: `LoginType` mock duplicates the values from `@/shared/types/auth.ts` -- should reference the source instead of hardcoding

## Prompt 8: Shared Types Branded Types + Deduplication
- [ ] `src/shared/types/filterFormStates.ts`: `dateRange: Date[]` should be narrowed to `[Date, Date]` tuple in FormattedFormState, FormattedWorkstreamsFormState, and FormattedOpportunitiesFormState -- deferred because it cascades into validation schemas (z.array -> z.tuple), getDefaultFiltersDateRange return type, and test files that pass empty arrays for validation testing
- [ ] `src/shared/types/filterFormStates.ts`: `teams: (string | number)[]` in form state types is not branded to TeamId -- intentionally left unbranded because these are intermediate UI form values from select components, not trust boundary values; branding happens at query param construction
- [ ] `src/shared/types/systems.schema.ts:136`: `ActivitiesByUserItemSchema.uid` uses bare `z.string()` without `.transform(UserId)` -- should apply UserId transform for schema-level branding consistency

## Prompt 10: Component Generic APIs
- [ ] `src/ui/page_blocks/settings/Urls/ClassificationUrlsBlock.tsx:41,130`: `onRowSelect` prop expects `ClassificationUrlItem` but Table data is `MappedClassificationUrlItem[]` -- the types have incompatible `category` unions (`"unknown"` vs `"unclassified"`). Align the prop type chain to accept `MappedClassificationUrlItem` or introduce a common base type
- [ ] `src/ui/components/8flow/Table/Table.types.ts:35`: `columnId` feature creates a runtime type lie -- `onClickRow` is typed `(value: Data) => void` but when `columnId` is set, the actual value is `Data[keyof Data]`. Consider removing `columnId` from the public API since production usage was migrated away in this prompt (only Table.spec.tsx still uses it)

## Prompt 11: Providers + Feature Cleanup
- [ ] `src/ui/page_blocks/dashboard/opportunities/OpportunityFilters/OpportunitiesFiltersContainer.tsx:13`: imports `getTeamsItems` from `@/providers/context/teamsContext/utils` bypassing barrel -- should import from `@/providers/context/teamsContext`
- [ ] `src/ui/page_blocks/dashboard/ui/InsightsFilters/utils/form/form.spec.ts:12`: imports `getTeamsItems` from `@/providers/context/teamsContext/utils` bypassing barrel -- should import from `@/providers/context/teamsContext`
- [ ] `src/ui/components/8flow/Select/Select.tsx:18`: `items` prop typed as mutable array `SelectItemShape<T>[]` -- should accept `readonly SelectItemShape<T>[]` to allow `as const` array literals without type widening

## Prompt 12: Test Cleanup
- [ ] `src/ui/page_blocks/teams/AddTeamFormContainer.spec.tsx`, `TeamsListContainer.spec.tsx`, `TeamDetailContainer.spec.tsx`, `UsersContainer.spec.tsx`, `EditUserModal.spec.tsx`: 15 remaining `as unknown as ReturnType<typeof ...>` double casts for mutation hooks and useRouter -- create analogous helpers (buildMutationMock already exists in react-query.ts but is not used by all specs; useRouter casts could use a helper)
