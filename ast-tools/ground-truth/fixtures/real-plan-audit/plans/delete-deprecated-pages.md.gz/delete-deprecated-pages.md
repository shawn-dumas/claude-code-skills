# Migration: Delete Deprecated Pages (workstreams + system-latency)

> Remove two deprecated insight pages (`/insights/workstreams` and
> `/insights/system-latency`) and all exclusively-owned code: page files,
> component trees, service hooks, mock routes, integration tests,
> fixtures, feature flags, navigation entries, URL registry, PostHog
> events, filter types, query keys, and documentation references.
>
> Created: 2026-03-16
> Completed: 2026-03-16
> Branch: sd/productionize
> Complexity: D2 S7 Z5 = 4.7
> Duration: F4 C1 = 3.5h (1.75-7h)
> Actual: 1.25h (14:33-15:49 PDT), 5 commits, ~120 files
> Nearest: PM Recs (4.7), BFF Audit Fix v2 (4.7)
> Integration scope: per-prompt (prompts 01-02 touch integration/ files)
> Pre-flight: CERTIFIED 2026-03-16 by pre-flight-plan-audit
> Pre-flight findings: 0 blockers, 0 warnings (3 false positives from AST tool dismissed)
> Status: Complete

## Current State

Two deprecated pages are still in the codebase:

- `/insights/workstreams` -- replaced by `/insights/workstream-analysis`
- `/insights/system-latency` -- deprecated entirely

```bash
# Page files that should not exist after migration
ls src/pages/insights/workstreams.tsx src/pages/insights/system-latency.tsx
# Current count: 2
```

## Target State

Both pages and all exclusively-owned code are deleted. No references
remain in navigation, URL registry, feature flags, filter types, query
keys, integration tests, or documentation.

```bash
# After migration:
ls src/pages/insights/workstreams.tsx src/pages/insights/system-latency.tsx 2>&1
# Target: both "No such file or directory"

rg 'workstreamAnalyzer|ENABLE_ANALYZER|insightsWorkstreamsUrl|WORKSTREAMS.*Workstreams' src/ --type ts --type tsx -l
# Target: 0 hits

rg 'systemLatency|ENABLE_SYSTEM_LATENCY|insightsSystemLatencyUrl|SYSTEM_LATENCY' src/ --type ts --type tsx -l
# Target: 0 hits
```

## Inventory

### Workstreams page -- files to DELETE (23 files)

| # | File | Domain | Prompt |
|---|------|--------|--------|
| 1 | src/pages/insights/workstreams.tsx | page | 01 |
| 2-16 | src/ui/page_blocks/dashboard/workstream-analysis/analyzer/ (15 files) | components | 01 |
| 17-22 | src/ui/services/hooks/queries/insights/useAnalyzerWorkstreamsQuery/ (3) + useActivityTimelineQuery/ (3) | hooks | 01 |
| 23-24 | src/pages/api/mock/users/data-api/analyzer/ (2 files) | mock routes | 01 |
| 25 | integration/tests/analyzer.spec.ts | integration | 01 |
| 26 | integration/fixtures/analyzer.ts | integration | 01 |

### System-latency page -- files to DELETE (24 files)

| # | File | Domain | Prompt |
|---|------|--------|--------|
| 1 | src/pages/insights/system-latency.tsx | page | 02 |
| 2-8 | src/ui/page_blocks/dashboard/system-latency/ (7 files) | components | 02 |
| 9-23 | src/ui/services/hooks/queries/insights/useTopUsedQuery/ (5) + useAvgLatencyByHostQuery/ (5) + useTimeByHostQuery/ (5) | hooks | 02 |
| 24-26 | src/pages/api/mock/users/data-api/system-latency/ (3 files) | mock routes | 02 |
| 27 | src/shared/utils/insightsQueryParams/systemLatency.ts | query params | 02 |
| 28 | integration/tests/system-latency.spec.ts | integration | 02 |
| 29 | integration/fixtures/system-latency.ts | integration | 02 |

### Shared infrastructure -- files to EDIT (~40 files across both)

| # | File | What to remove | Prompt |
|---|------|----------------|--------|
| 1 | src/shared/constants/dashboard.ts | WORKSTREAMS + SYSTEM_LATENCY entries | 03 |
| 2 | src/shared/types/insightsFilters.ts | workstreamAnalyzer + systemLatency fields | 03 |
| 3 | src/shared/hooks/useFeatureFlags/types.ts | ENABLE_ANALYZER + ENABLE_SYSTEM_LATENCY | 03 |
| 4 | src/shared/hooks/useFeatureFlags/constants.ts | both flags from fallback + localAllOn | 03 |
| 5 | src/ui/constants/index.ts | (no changes needed -- already clean) | -- |
| 6 | src/ui/urlsRegistry.ts | 4 URL functions | 03 |
| 7 | src/ui/urlsRegistry.spec.ts | corresponding tests | 03 |
| 8 | src/shared/test-utils/urlsRegistryMocks.ts | 4 mock entries | 03 |
| 9 | src/shared/lib/posthog.ts | 2 event constants | 03 |
| 10 | src/shared/test-utils/posthog-mock.ts | 1 event constant | 03 |
| 11 | src/ui/page_blocks/dashboard/ui/DashboardNavigation/constants.ts | 2 nav entries + imports | 03 |
| 12 | src/ui/page_blocks/dashboard/constants.ts | 2 nav event entries + imports | 03 |
| 13 | src/ui/page_blocks/dashboard/DashboardLayout.tsx | workstreamAnalyzer branch | 03 |
| 14 | src/ui/page_blocks/dashboard/DashboardLayout.spec.tsx | (review -- may not need changes) | 03 |
| 15 | src/ui/providers/context/layout/types.ts | 2 filter state entries + imports | 03 |
| 16 | src/ui/services/hooks/keys/insights.ts | workstreamAnalyzer + systemLatency blocks | 03 |
| 17 | src/ui/services/hooks/keys/insights.spec.ts | corresponding test blocks | 03 |
| 18 | src/ui/services/hooks/mutations/teams/removeRelatedInsights.ts | 2 cache invalidation entries | 03 |
| 19 | src/ui/services/hooks/mutations/teams/removeRelatedInsights.spec.ts | 2 test entries | 03 |
| 20 | src/ui/services/hooks/queries/insights/index.ts | 5 barrel re-exports | 03 |
| 21 | src/ui/page_blocks/dashboard/index.ts | WorkstreamsAnalyzerBlock export | 03 |
| 22 | src/ui/page_blocks/dashboard/workstream-analysis/index.ts | WorkstreamsAnalyzerBlock export | 03 |
| 23 | src/ui/page_blocks/dashboard/opportunities/MicroworkflowsContainer.tsx | analyzer cross-link (lines 16, 115-143) | 03 |
| 24 | src/shared/utils/insightsQueryParams/index.ts | 2 barrel re-exports | 03 |
| 25 | src/shared/utils/insightsQueryParams/workstreams.ts | getAnalyzerWorkstreamsQueryParams function | 03 |
| 26-30 | src/ui/page_blocks/dashboard/ui/InsightsFilters/ (types, validation, form, specs) | systemLatency + workstreamAnalyzer variants | 03 |
| 31-32 | src/ui/page_blocks/dashboard/workstream-analysis/filters/ (component + spec) | workstreamAnalyzer variant from union | 03 |
| 33 | src/shared/utils/insightsQueryParams/__test-utils__/testUtils.ts | systemLatency + analyzer test cases | 03 |
| 34 | src/ui/constants/testIds.ts | SYSTEM_LATENCY_TAB | 03 |

### Integration + docs cleanup (~20 files)

| # | File | What to change | Prompt |
|---|------|----------------|--------|
| 1 | integration/fixtures/index.ts | remove 2 barrel exports | 04 |
| 2 | integration/constants.ts | remove page names + test IDs | 04 |
| 3 | integration/pages/InsightsPage.ts | remove 2 switch cases | 04 |
| 4 | integration/tests/export.spec.ts | remove 2 export test blocks | 04 |
| 5 | integration/tests/navigation.spec.ts | remove system-latency assertion | 04 |
| 6 | integration/tests/components.spec.ts | remove workstreams filter check | 04 |
| 7 | integration/fixture.ts | remove 2 feature flag entries | 04 |
| 8 | integration/fixture-bff.ts | remove 2 feature flag entries | 04 |
| 9 | src/ui/providers/context/layout/LayoutProvider.spec.tsx | change default path from system-latency | 04 |
| 10 | src/ui/components/8flow/PageShells/SignedInPageShell.spec.tsx | remove flag ref | 04 |
| 11 | src/ui/components/8flow/Sidebar/Sidebar.spec.tsx | remove flag ref | 04 |
| 12 | scripts/run-integration.sh | remove system-latency from insights-c | 05 |
| 13 | scripts/AST/ast-config.ts | remove parity entry | 05 |
| 14 | scripts/AST/docs/ast-parity-matching.md | remove table row | 05 |
| 15 | CLAUDE.md | remove system-latency from structure + insights-c | 05 |
| 16 | docs/bff.md | remove system-latency route rows | 05 |
| 17 | docs/local-development.md | remove flag reference | 05 |
| 18 | docs/orchestration-protocol.md | remove system-latency from batch | 05 |
| 19 | docs/integration-testing.md | remove file references | 05 |
| 20 | .claude/skills/README.md | remove system-latency from batch | 05 |
| 21 | .claude/skills/orchestrate-poc/SKILL.md | remove analyzer + system-latency refs | 05 |

## Migration Phases

| # | Phase | Prompt | What | Files | Mode | Status |
|---|-------|--------|------|-------|------|--------|
| 1 | Delete workstreams | 01 | Delete page, components, hooks, mocks, integration test/fixture | ~26 delete | auto | pending |
| 2 | Delete system-latency | 02 | Delete page, components, hooks, mocks, query params, integration test/fixture | ~29 delete | auto | pending |
| 3 | Shared cleanup | 03 | Edit constants, types, flags, nav, URLs, filters, keys, barrels, layout | ~34 edit | auto | pending |
| 4 | Test cleanup | 04 | Edit integration tests, fixtures, POMs, unit test flag refs | ~11 edit | auto | pending |
| 5 | Docs + final verify | 05 | Edit docs, skills, AST config, runner script, dead export scan | ~10 edit | auto | pending |

## Dependency Graph

```
Prompt 01 (workstreams)    Prompt 02 (system-latency)
         \                      /
          \                    /
           v                  v
         Prompt 03 (shared cleanup)
                  |
                  v
         Prompt 04 (test cleanup)
                  |
                  v
         Prompt 05 (docs + final verify)
```

Prompts 01 and 02 are independent -- can run in either order (or parallel
if using two agents, though sequential is safer). Prompt 03 depends on
both. Prompt 04 depends on 03. Prompt 05 depends on 04.

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| 01 | | | | |
| 02 | | | | |
| 03 | | | | |
| 04 | | | | |
| 05 | | | | |
