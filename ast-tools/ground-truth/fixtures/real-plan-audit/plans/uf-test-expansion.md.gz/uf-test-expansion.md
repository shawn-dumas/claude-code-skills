# Feature: Test Coverage Expansion

> Fill integration test gaps and port deleted e2e coverage using Playwright + Firebase emulator + mock API handler.

## Design

9 specs across 3 tiers that close the remaining test coverage gaps in the
integration test suite. All specs run against the local dev server using the
Firebase Auth emulator and the mock API handler -- no external backend or SSO
credentials needed.

### Existing Infrastructure

- **Integration fixture**: `integration/fixture.ts` -- Playwright base fixture
  with PostHog /decide interception and TanStack Query devtools suppression.
- **Auth utility**: `integration/utils/auth.ts` -- `signInWithEmulator()` signs
  in via `window.__devSignIn` and navigates to a target insights page.
- **POMs**: 6 existing -- InsightsPage, RealtimePage, NavigationPage, SettingsPage,
  TeamsPage, UsersPage.
- **Mock API handler**: `src/pages/api/mock/[...endpoint].ts` -- stateful,
  serves fixture data for all endpoints. Supports `__reset` for clean slates.
- **Integration fixtures**: `integration/fixtures/` -- wrappers around
  `src/fixtures/` domain builders in API response envelope shapes.
- **Constants**: `integration/constants.ts` -- test IDs, page names, URL paths,
  cell test IDs for all dashboard domains.
- **Sort helpers**: `integration/utils/mockDataUtils.ts` -- assertion helpers for
  column sort verification.

### New Files

| File | Type | Purpose |
|------|------|---------|
| `integration/tests/auth.spec.ts` | Integration spec | Login flows, access denied, role gating |
| `integration/tests/url-classification.spec.ts` | Integration spec | URL classification filter/search/sort/export |
| `integration/tests/operational-hours.spec.ts` | Integration spec | Operational hours table, filtering, chart |
| `integration/tests/usage.spec.ts` | Integration spec | Favorite and Relay KPI tabs, columns |
| `integration/tests/systems.spec.ts` | Integration spec | Cards view, table view, page drill-down |
| `integration/tests/navigation.spec.ts` | Integration spec | Sidebar tab switching, role-gated visibility |
| `integration/pages/AuthPage.ts` | POM | Signin page interactions |
| `integration/pages/UrlClassificationPage.ts` | POM (optional) | URL classification settings interactions |
| `src/ui/page_blocks/dashboard/usage/shared/UsageContainer.spec.tsx` | Unit spec | Missing container unit test |

### Modified Files

| File | What changes |
|------|-------------|
| `integration/pages/index.ts` | Re-export new POMs |
| `integration/pages/InsightsPage.ts` | Add waitForFilters cases for new tab names if needed |
| `integration/pages/NavigationPage.ts` | May need expanded type to support role-gating assertions |
| `integration/pages/SettingsPage.ts` | May need URL classification methods |
| `integration/constants.ts` | Add any missing test ID constants |
| `src/pages/api/mock/[...endpoint].ts` | May need new/adjusted endpoints for edge cases |

### Dependency Graph

```
Prompt 1 (auth)         -- standalone, no POM deps beyond what exists
Prompt 2 (bpo+projects) -- ALREADY DONE (settings-crud.factory exists)
Prompt 3 (url-classification) -- needs SettingsPage POM methods or new POM
Prompt 4 (operational-hours) -- needs InsightsPage POM (exists)
Prompt 5 (usage) -- needs InsightsPage POM (exists)
Prompt 6 (systems) -- needs InsightsPage POM (exists)
Prompt 7 (navigation) -- needs NavigationPage POM (exists)
Prompt 8 (UsageContainer unit test) -- standalone Vitest spec
```

BPO and Projects are already implemented via the settings-crud.factory.ts
pattern. They are NOT empty placeholders -- they call `defineSettingsCrudTests`
with config for create, edit, delete, duplicate-name rejection, and blank-name
rejection. No work needed for those.

## Implementation Phases

| # | Phase | Prompt | Summary | Depends on | Status |
|---|-------|--------|---------|-----------|--------|
| 1 | Auth flows | test-expansion-01-auth | Login flow, access denied, role gating via Firebase emulator | none | done (ece94232) |
| 2 | URL classification | test-expansion-02-url-classification | Filter, search, sort, export for URL classification settings | none | done (3729d738) |
| 3 | Operational hours | test-expansion-03-operational-hours | Table columns, filtering, chart rendering | none | done (b20f8418) |
| 4 | Usage (Favorites + Relays) | test-expansion-04-usage | KPI tabs, column visibility, tab switching | none | done (f1eb0a2e) |
| 5 | Systems | test-expansion-05-systems | Cards view, table view, page drill-down | none | done (2d3a2694) |
| 6 | Navigation | test-expansion-06-navigation | Sidebar tab switching, role-gated tab visibility | none | done (164e1c48) |
| 7 | UsageContainer unit test | test-expansion-07-usage-container | Missing container unit spec for shared UsageContainer | none | done (27ac2bfc) |

Note: Prompts 1-6 are integration tests (Playwright). Prompt 7 is a Vitest unit
test. All prompts are independently runnable but sequenced for review clarity.
Earlier prompts may add POM methods or fixture helpers that later prompts can
reuse (no hard dependency -- later prompts can add their own if needed).

## Verification

After all prompts complete:

- All integration specs pass: `npx playwright test --config playwright.integration.config.ts`
- All unit tests pass: `pnpm test --run`
- `pnpm tsc --noEmit` -- 0 errors
- `pnpm build` -- clean
- `npx eslint . --max-warnings 0` -- clean
- 7 new spec files exist in `integration/tests/`
- 1 new unit spec file at `src/ui/page_blocks/dashboard/usage/shared/UsageContainer.spec.tsx`
- 1-2 new POM files in `integration/pages/`
