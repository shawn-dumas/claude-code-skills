# Port: NGA Systems Enhancements to UF

> Port the systems feature enhancements from next-gen-atlassian's
> sd/productionize branch (main3 port + polish) into user-frontend,
> adapting all code to UF conventions (BFF routes, nuqs URL state,
> DDAU containers, fetchApi + Zod, fixture builders).
>
> Created: 2026-03-15
> Branch: sd/nga-systems-port (off sd/productionize)
> Complexity: D6 S7 Z7 = 6.7
> Duration: F4 C4 = 16h (8-32h)
> Nearest: Backlog (6.7), FE-to-BFF Mapper Migration (5.0)
> Integration scope: final-only (systems chunk)
> Playwright scope: final-only (regression check on systems.spec.ts)

**Scoring rationale:** D6: requires mapping between two codebases with
different architectures (NGA Supabase RPCs vs UF BFF + ClickHouse).
Most risks caught by tsc/tests, but data shape mapping and dual data
path integration have silent-failure modes. S7: touches shared types,
Zod schemas, fixture builders, mock API routes, query hooks, query key
factories, new UI components, existing system components, containers,
navigation shell, analysis layout, filter components, system icons
utility -- 4+ layers. Z7: 8 prompts + cleanup, ~60-80 files. F4:
most prompts create new files (low mismatch risk); prompts 5-7 modify
existing UF components (~15-20 files peak). C4: two sessions over
1-2 days, generative work from clear spec but S7 scope means more
coordination points.

## Reference Material

- **Squash diff:** `~/plans/nga-systems-port-squash.diff` (37,574 lines).
  Contains the full diff of 61 NGA commits (f6c3560d..d97328dc) squashed
  into one. This is the "what" document -- work agents read it for the
  end-state of each file, then implement using UF conventions.

- **NGA repo:** `~/github/next-gen-atlassian` (branch `sd/productionize`).
  Work agents may read NGA source files directly when the diff is
  insufficient context.

- **UF repo:** `~/github/user-frontend-nga-systems-port` (worktree for
  branch `sd/nga-systems-port`, created from `~/github/user-frontend`).

## Architecture Mapping

| NGA Concept | UF Equivalent |
|---|---|
| `company-data/` API routes (Supabase RPC proxies) | Mock routes under `src/pages/api/mock/users/data-api/systems/` + stub BFF routes |
| `useFetchApi()` + raw `useQuery()` + Zod schema | Same pattern -- UF uses identical fetchApi + Zod approach |
| `SystemsBlock.tsx` (615-line monolith) | `SystemsContainer.tsx` (113 lines) + `useSystemsQueries` + `useSystemsUrlState` |
| `SystemsBlockContainer.tsx` (NGA container) | Already handled by `SystemsContainer.tsx` |
| Filter state in `useState` + `sessionStorage` | Filter state in nuqs URL params (`useSystemsUrlState`) |
| `company-data.ts` query key factory | `insightsQueryKeys` in `src/ui/services/hooks/keys/insights.ts` |
| `buildSystemColumns()` shared column factory | Integrate with UF's `useSystemPagesTableColumns` pattern |
| `getDashboardTabs` in `shared/navigation/` | Tab definitions in `DashboardNavigation` constants |
| NGA `FilterSection.tsx` (custom) | UF `OpportunitiesFilters variant='systems'` |
| NGA `ConfluenceDetail` container | New container following UF DDAU pattern |
| NGA `useProductivityQueries` | New query hooks following UF `useFetchApi` pattern |

## Data Layer Strategy

NGA's API routes proxy Supabase RPCs. UF uses BFF routes backed by
ClickHouse views or Postgres. For this port:

1. **Mock routes** serve fixture data in mocked mode. These are created
   in Prompt 02 and are fully functional.
2. **Stub BFF routes** return 501 Not Implemented with a TODO comment.
   The actual ClickHouse views/queries are backend work outside this
   port's scope.
3. **Query hooks** work against mock routes immediately. When BFF routes
   are implemented later, the hooks work without changes (same fetchApi
   pattern, same Zod schemas).

## Key Context and Discoveries

- **UF's SystemsContainer is already clean DDAU.** The port adds new
  features to it (Confluence/Sheets drill-down, productivity dual path)
  without regressing the architecture. New code follows the existing
  `useSystemsQueries` cascading pattern.

- **UF's systems types have a DIFFERENT shape from NGA.** NGA's
  `SystemData` is a client-side type with `systemName`, `urlHost`,
  `activeTime`, etc. UF's `MappedSystemOverviewItem` has `system_name`,
  `total_hosts`, `active_time`, etc. (snake_case, different field set).
  The port extends UF's existing types, not NGA's.

- **Feature flag gating deferred.** The new Confluence/Sheets detail
  views and productivity dual path could be behind a feature flag in
  the future, but this port does not create one. The existing
  `ENABLE_SYSTEMS` flag gates the entire systems page; the new features
  are additive behind that existing gate.

- **Navigation tab grouping already partially exists in UF.** The
  `dashboardPages` constant has a `group` property (PEOPLE, PROCESS,
  PLATFORM). The port adds visible section headers in the UI, not a
  new data structure.

- **The analysis layout area does not exist in UF.** NGA has
  `AnalysisLayout`, `AnalysisLayoutContainer`, `AnalysisHeaderContent`,
  `FilterPills`. UF has no `analysis/` directory. This work either
  needs to be adapted to UF's existing `DashboardLayout` or scoped
  out if UF's layout doesn't support the same pattern.

## Standing Prompt Elements

- **TYPE SAFETY SWEEP**: Yes (run on affected files after Prompt 07)
- **DEAD CODE PASS**: Yes (after Prompt 07, check for dead exports)
- **IMPORT BOUNDARY CHECK**: Yes (before Prompt 01, verify cross-domain imports)
- **NUQS AUDIT**: Yes (Prompt 06 touches container URL param handling)
- **TEST INFRA PREP**: Yes (Prompts 03-05 write tests; ensure shared
  mock helpers exist)
- **DOCS GREP**: Yes (after Prompt 08, check docs/ for stale references)
- **PW INTERCEPT AUDIT**: Not applicable (no response schema changes to
  existing endpoints)

## Prompt Sequence

| # | Prompt | Mode | Files | Depends On |
|---|--------|------|-------|------------|
| 01 | Types, Schemas, Fixtures | Auto | ~8 | -- |
| 02 | Mock API Routes | Auto | ~8 | 01 |
| 03 | Query Hooks | Auto | ~16 | 01, 02 |
| 04 | System Utilities (icons, UrlHostsBadge, column defs) | Auto | ~8 | 01 |
| 05 | Confluence + Google Sheets Detail Views | Auto | ~14 | 03, 04 |
| 06 | Productivity Dual Data Path | Manual | ~10 | 03, 05 |
| 07 | Systems Visual Overhaul (cards, table, idle time) | Manual | ~12 | 04, 06 |
| 08 | Navigation Tab Grouping + FilterPills | Manual | ~10 | 03 |
| -- | Cleanup | Auto | varies | all |

## Pre-Execution Verification

```bash
# Confirm worktree exists and is on the correct branch
cd ~/github/user-frontend-nga-systems-port && git branch --show-current
# should be sd/nga-systems-port

# Confirm clean working tree
git status

# Confirm plan files exist
ls ~/plans/nga-systems-port.md \
   ~/plans/nga-systems-port-cleanup.md \
   ~/plans/nga-systems-port-squash.diff \
   ~/plans/prompts/nga-systems-port-0*.md

# Confirm existing systems infrastructure
ls src/ui/page_blocks/dashboard/systems/SystemsContainer.tsx \
   src/ui/page_blocks/dashboard/systems/useSystemsQueries.ts \
   src/ui/page_blocks/dashboard/systems/useSystemsUrlState.ts \
   src/shared/types/systems.ts \
   src/shared/types/systems.schema.ts \
   src/fixtures/domains/systems.fixture.ts

# Baseline tsc + tests
pnpm tsc --noEmit
pnpm test --run 2>&1 | tail -5
```

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| 01 | -- | -- | -- | |
| 02 | -- | -- | -- | |
| 03 | -- | -- | -- | |
| 04 | -- | -- | -- | |
| 05 | -- | -- | -- | |
| 06 | -- | -- | -- | |
| 07 | -- | -- | -- | |
| 08 | Final | Final | | |
