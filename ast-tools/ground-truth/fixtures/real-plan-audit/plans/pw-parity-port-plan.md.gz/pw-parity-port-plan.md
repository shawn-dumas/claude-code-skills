# Playwright Parity Port Plan

> Created: 2026-03-14
> Branch: sd/productionize
> Source audit: ~/audits/26-03-13--user-frontend--pw-e2e-parity-audit.md
> Status: COMPLETE
> Cleanup file: ~/plans/pw-parity-port-cleanup.md

## Complexity

| Dimension | Score | Rationale |
| --------- | ----- | --------- |
| Difficulty (D) | 3 | Mechanical. Every test follows established patterns in the integration suite. No architectural decisions. |
| Scope (S) | 4 | Multiple spec files across the integration suite, but all in one directory with one test infrastructure. |
| Size (Z) | 3 | 4 prompts, ~10 files modified, single session. |
| Failure exposure (F) | 3 | Targeted edits -- appending tests to existing specs or creating small new tests. Low mismatch risk. |
| Calendar risk (C) | 1 | Single session. All prompts are well-specified generative work. No review gates. |

**Blended score:** 3.3 (low complexity)
**Duration estimate:** 4 prompts * 0.5h * (1 + 0.6) = 3.2h active, calendar floor 4h. **~3-4 hours.**

## Overview

Port 7 genuinely missing QA tests from the production/development branches
into the integration suite, and rename 6 existing integration tests to
improve parity tool name matching. This closes all portability gaps
identified in the parity audit before sd/productionize becomes main.

## What is genuinely missing (no integration equivalent)

| # | Source test | Branch | Integration target |
| - | --- | --- | --- |
| 1 | Verify export feature - Favorites Usage tab | development | export.spec.ts |
| 2 | Verify export feature - Relays Usage tab | development | export.spec.ts |
| 3 | Verify export feature - Microworkflows tab | development | export.spec.ts |
| 4 | Verify export feature - Systems tab | development | export.spec.ts |
| 5 | Verify export feature - System Latency tab | production | export.spec.ts |
| 6 | Refresh each tab and verify user is not navigated away | production | components.spec.ts |
| 7 | Expect table to be empty - Systems tab | development | systems.spec.ts |

## What exists but the tool can't match (name divergence)

| # | Source test | Existing integration test | Fix |
| - | --- | --- | --- |
| 8 | Expect table to be empty... - Favorites Usage tab | empty state without team selection - Favorites | Rename |
| 9 | Expect table to be empty... - Relays Usage tab | empty state without team selection - Relays | Rename |
| 10 | Expect table to be empty... - Systems tab (microworkflows) | empty table state when overview returns no data | Rename |
| 11 | Test columns sorting - Systems tab (microworkflows) | 13 individual sorting tests | No action -- 1:N split is correct |
| 12 | Expect columns visible... - Systems tab (systems) | toggle to table view + table sorting tests | No action -- cards paradigm is correct |
| 13 | Test columns sorting - Systems tab (systems) | 20+ individual sorting tests | No action -- 1:N split is correct |
| 14 | Test columns sorting - Team Productivity tab | 8 individual sorting tests | No action -- 1:N split is correct |

Items 11-14 need no action. The 1:N sorting split is an intentional
improvement. The tool's inability to match 1:N is a known limitation,
not a coverage gap.

## Dependencies

P1 and P2 are independent and can run in parallel.
P3 depends on P1 (export tests must exist before renaming related tests).
P4 depends on all prior prompts.

## Prompt Sequence

| # | Description | Files | Est. commits |
| - | --- | --- | --- |
| P1 | Add 5 CSV export tests for missing tabs | integration/tests/export.spec.ts | 1 |
| P2 | Port refresh-persistence test + systems empty state | integration/tests/components.spec.ts, integration/tests/systems.spec.ts | 1 |
| P3 | Rename 3 existing tests for parity tool name matching | integration/tests/favorites.spec.ts, integration/tests/relays.spec.ts, integration/tests/microworkflows.spec.ts | 1 |
| P4 | Re-run parity tool, update audit, update file mappings | scripts/AST/ast-config.ts, audit file | 1 |

## Verification Commands

```bash
pnpm tsc --noEmit
pnpm build
# Run affected integration spec chunks:
bash scripts/run-integration.sh spec integration/tests/export.spec.ts
bash scripts/run-integration.sh spec integration/tests/components.spec.ts
bash scripts/run-integration.sh spec integration/tests/systems.spec.ts
bash scripts/run-integration.sh spec integration/tests/favorites.spec.ts
bash scripts/run-integration.sh spec integration/tests/relays.spec.ts
bash scripts/run-integration.sh spec integration/tests/microworkflows.spec.ts
# Re-run parity tool:
npx tsx scripts/AST/ast-interpret-test-parity.ts --source-branch production --source-dir e2e/tests/ --target-dir integration/tests/ --pretty
npx tsx scripts/AST/ast-interpret-test-parity.ts --source-branch development --source-dir e2e/tests/ --target-dir integration/tests/ --pretty
# Run accuracy test:
npx vitest run --config scripts/AST/vitest.config.mts interpreter-accuracy
```

## Progress

| # | Status   | HEAD       | Notes |
| - | -------- | ---------- | ----- |
| P1 | complete | aa634992 | 6 export tests + System Latency fixme->live. Scope expanded: added both System Aggregate + User Details per tab (8 tests total). |
| P2 | complete | 671d2c21 | Refresh persistence + systems empty state |
| P3 | complete | 0dfabbb9 | 3 renames |
| P4 | complete |          | Parity: prod 87%->88%, dev 68%->75%. NOT_PORTED: prod 8->7, dev 18->10. Accuracy tests pass. |

---

## Prompt Details

### P1: CSV export tests for Favorites, Relays, Microworkflows, Systems, System Latency

**Context:**
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- File: integration/tests/export.spec.ts

Read ~/github/user-frontend/CLAUDE.md and integration/tests/export.spec.ts before starting.

**Task:**
Add 5 new CSV export tests to `integration/tests/export.spec.ts` following
the exact pattern of the existing export tests (e.g., "CSV export -
Realtime Activity tab"). Each test should:

1. Sign in with emulator
2. Navigate to the tab
3. Set up route intercepts for the tab's data endpoints with fixture data
4. Select a team/user and submit filters
5. Click the CSV export button
6. Verify the download was triggered (check for the download event or
   verify the blob URL)

The existing tests in the file are the template. Follow their structure exactly.

CSV export is client-side via papaparse in the shared Table component.
Every table has a CSVButton in its header unless `disableExport={true}`.
The csv filenames are:

- Favorites: `Favorite-Usage-System`, `Favorite-Usage-Users`
- Relays: `Relay-Usage-System`, `Relay-Usage-Users`
- Microworkflows: `8Flow-Insights-Microworkflows-Details`
- Systems: `8Flow-Insights-Systems`
- System Latency: `8Flow-Insights-Top-Used-Hosts`

Use the `/build-playwright-test` skill for each test if the existing
pattern is insufficient. Otherwise, copy the pattern from "CSV export -
Realtime Activity tab" and adapt for each tab.

**Tests to add:**
1. `CSV export - Favorites System Aggregate tab`
2. `CSV export - Relays System Aggregate tab`
3. `CSV export - Microworkflows overview tab`
4. `CSV export - Systems overview table`
5. `CSV export - System Latency tab`

**When done:**
```bash
pnpm tsc --noEmit
bash scripts/run-integration.sh spec integration/tests/export.spec.ts
```

---

### P2: Refresh persistence test + systems empty state

**Context:**
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- Files: integration/tests/components.spec.ts, integration/tests/systems.spec.ts

Read ~/github/user-frontend/CLAUDE.md before starting.

**Task 1: Refresh persistence test**

Add a test to `integration/tests/components.spec.ts`:

```
test('Refresh each tab and verify user is not navigated away')
```

Port from the QA spec on the production branch:
```bash
git show production:e2e/tests/generalComponents.spec.ts
```

The test signs in, navigates to an insights tab, reloads the page, and
verifies the user is still on the same tab (not redirected to signin or
a different page). The integration version should:
1. Sign in with emulator
2. Navigate to 2-3 different insight tabs
3. For each: reload the page and verify the URL still contains the tab path

**Task 2: Systems empty state test**

Add a test to `integration/tests/systems.spec.ts`:

```
test('empty state before filter submission - Systems')
```

The QA spec on development (mockDataSystems.spec.ts) tests that the table
is empty before a team is selected. The systems integration spec starts
from cards view after filter submission and never tests the pre-submission
empty state. Add a test that:
1. Signs in and navigates to /insights/systems
2. Verifies a placeholder or empty message is visible before any filter action
3. Does NOT submit filters -- just verifies the initial empty state

**When done:**
```bash
pnpm tsc --noEmit
bash scripts/run-integration.sh spec integration/tests/components.spec.ts
bash scripts/run-integration.sh spec integration/tests/systems.spec.ts
```

---

### P3: Rename 3 existing tests for parity tool name matching

**Context:**
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- Files: integration/tests/favorites.spec.ts, integration/tests/relays.spec.ts, integration/tests/microworkflows.spec.ts

**Task:**

Rename 3 existing integration tests so their names have better word
overlap with the source QA test names. This improves the parity tool's
ability to match them (the current names fall below the 0.15 similarity
threshold).

| File | Current name | New name |
| --- | --- | --- |
| favorites.spec.ts | `empty state without team selection - Favorites` | `Expect table to be empty if a team is not selected - Favorites` |
| relays.spec.ts | `empty state without team selection - Relays` | `Expect table to be empty if a team is not selected - Relays` |
| microworkflows.spec.ts | `empty table state when overview returns no data` | `Expect table to be empty if a team is not selected - Microworkflows` |

These are test name changes only. No behavioral changes. The tests
themselves stay identical.

**When done:**
```bash
pnpm tsc --noEmit
bash scripts/run-integration.sh spec integration/tests/favorites.spec.ts
bash scripts/run-integration.sh spec integration/tests/relays.spec.ts
bash scripts/run-integration.sh spec integration/tests/microworkflows.spec.ts
```

---

### P4: Re-run parity tool and update audit

**Context:**
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- Files: scripts/AST/ast-config.ts, ~/audits/26-03-13--user-frontend--pw-e2e-parity-audit.md

**Task:**

1. Run the parity tool against both branches:
```bash
npx tsx scripts/AST/ast-interpret-test-parity.ts \
  --source-branch production --source-dir e2e/tests/ \
  --target-dir integration/tests/ --pretty

npx tsx scripts/AST/ast-interpret-test-parity.ts \
  --source-branch development --source-dir e2e/tests/ \
  --target-dir integration/tests/ --pretty
```

2. Run the accuracy test:
```bash
npx vitest run --config scripts/AST/vitest.config.mts interpreter-accuracy
```

3. Update the audit file with the new scores, NOT_PORTED counts, and
   accuracy numbers. Note which gaps were closed by this plan.

4. Update the parity ground truth fixtures if any classifications changed
   (unlikely -- the fixtures use distilled code, not the real specs).

**When done:**
```bash
npx vitest run --config scripts/AST/vitest.config.mts
```
