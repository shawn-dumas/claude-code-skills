# Migration: QA Test Files from development to sd/productionize

> Port viable QA-authored test files from the `development` branch into the
> existing architecture on `sd/productionize`. Unit tests get adapted for
> Vitest 4 / React 19 / current production code. E2E specs for new tabs get
> ported into the existing `integration/` Playwright infrastructure using
> Firebase emulator auth and fixture builders.
>
> Created: 2026-03-05
> Completed: 2026-03-05
> Status: DONE (Phases 1-6 complete, 2 cleanup items in standalone prompt)

## Current State

QA has been adding tests to the `development` branch. That branch diverged
from the same base as `sd/productionize` (merge-base `cfca1ab5`). The DDAU
refactor on `sd/productionize` deleted, moved, and restructured significant
production code. Many of the QA tests are for code that no longer exists or
has changed substantially.

The `e2e/` directory on `development` uses OneLogin SSO auth. On
`sd/productionize`, the `e2e/` directory was replaced by `integration/`
which uses Firebase emulator auth, Page Object Models, and fixture builders.

### What exists on sd/productionize

- **18 integration specs** in `integration/tests/` (2,977 lines total)
- **7 POMs** in `integration/pages/` (InsightsPage, RealtimePage, UsersPage,
  TeamsPage, SettingsPage, AuthPage, NavigationPage)
- **7 integration fixtures** in `integration/fixtures/`
- **2 utils** in `integration/utils/` (auth.ts, mockDataUtils.ts)
- **Unit tests**: 180 spec files, 2,240 tests (approx)

### What is new on development (classified below)

```bash
# Count new/modified spec files on development
git diff --diff-filter=AM --name-only sd/productionize...development -- '*.spec.ts' '*.spec.tsx' | wc -l
# Current count: 33
```

## Target State

After migration:
- Tier 1a unit tests ported (new tests for existing production code)
- Tier 1b unit test enhancements merged into existing specs
- Tier 2a integration specs created for 4 NEW tabs (Favorites, Microworkflows,
  Relays, Workstreams) using existing POM/fixture infrastructure
- Tier 2b missing test cases from development e2e specs added to existing
  integration specs
- Tier 3 and SSO-only specs skipped (dead code)
- Constants updated with any missing test IDs

```bash
# After migration, no e2e/ directory should exist
ls e2e/ 2>/dev/null | wc -l
# Target: 0 (e2e/ does not exist on sd/productionize)
```

## Inventory

### Tier 1a: NEW Unit Specs -- Production Code EXISTS (portable)

| # | File (on development) | Lines | Production Code | Status |
|---|----------------------|-------|-----------------|--------|
| 1 | src/shared/utils/posthog/handleClickGlossary/handleClickGlossary.spec.ts | 20 | EXISTS | DONE -- ported with proper posthog mock |

### Tier 1b: MODIFIED Unit Specs -- Production Code EXISTS (merge new test cases)

| # | File | Dev Lines | Prod Lines | Delta | Prod Code Changed? | Status |
|---|------|-----------|------------|-------|-------------------|--------|
| 2 | src/shared/ui/MetricsDisplay/MetricsDisplay.spec.tsx | 112 | 111 | +1 | No | SKIPPED -- dev uses s/m labels, no new test cases |
| 3 | src/shared/utils/number/formatInt/formatInt.spec.ts | 54 | 42 | +12 | YES (accepts strings) | DONE -- prod+spec ported, added NO_VALUE_PLACEHOLDER |
| 4 | src/shared/utils/table/formatCellValue/formatCellValue.spec.ts | 207 | 68 | +139 | YES (NO_VALUE_PLACEHOLDER) | DONE -- prod+spec ported, fixed useTestTableColumns |
| 5 | src/shared/utils/time/formatDuration/formatDuration.spec.ts | 316 | 316 | 0 | YES (minor) | SKIPPED -- cosmetic label change (sec->s, min->m), not a bug fix |
| 6 | src/ui/components/8flow/modals/TextInputModal/TextInputModal.spec.tsx | 244 | 208 | +36 | YES (new validation) | DEFERRED -- UX feature in standalone prompt qa-test-migration-cleanup-items.md |
| 7 | src/ui/page_blocks/users/EditUserModal/utils.spec.ts | 471 | 451 | +20 | YES (minor filter fix) | DONE -- prod fix (.filter(Boolean) -> .filter(!== undefined)) + test ported |

### Tier 2a: NEW E2E Specs -- New Tab Coverage (port to integration/)

| # | Spec (on development) | Lines | Utils File | Utils Lines | Status |
|---|----------------------|-------|-----------|-------------|--------|
| 8 | e2e/tests/mockDataFavorites.spec.ts | 233 | mockDataFavoritesAndRelaysUsage.ts | 1701 | DONE -- sorting spec in integration/tests/favorites.spec.ts |
| 9 | e2e/tests/mockDataMicroworkflows.spec.ts | 418 | mockDataMicroworkflows.ts | 1834 | DONE -- integration/tests/microworkflows.spec.ts (18 tests) |
| 10 | e2e/tests/mockDataRelays.spec.ts | 243 | (shares with Favorites) | -- | DONE -- sorting spec in integration/tests/relays.spec.ts |
| 11 | e2e/tests/mockDataSystems.spec.ts | 654 | mockDataSystems.ts | 3202 | DONE -- enhanced integration/tests/systems.spec.ts (214->496 lines, 15 new tests) |
| 12 | e2e/tests/mockDataWorkstreams.spec.ts | 214 | mockDataWorkstreams.ts | 648 | DONE -- Workstreams = Analyzer tab; 10 sorting tests added to analyzer.spec.ts |

### Tier 2b: MODIFIED E2E Specs -- Overlap with Existing (diff for new cases)

| # | Dev Spec | Dev Lines | Existing Integration Spec | Prod Lines | Status |
|---|----------|-----------|--------------------------|------------|--------|
| 13 | e2e/tests/mockDataRealTime.spec.ts | 962 | realtime.spec.ts | 491 | DONE -- all 23 tests already covered, no new cases to port |
| 14 | e2e/tests/mockDataTeamProductivity.spec.ts | 231 | team-productivity.spec.ts | 116 | DONE -- added Per Project/BPO sub-tab test + HEAD COUNT sorting (116->178L, +2 tests) |
| 15 | e2e/tests/mockDataUserProductivity.spec.ts | 305 | user-productivity.spec.ts | 79 | DONE -- added column sorting test with 3 sort assertions (79->125L, +1 test) |
| 16 | e2e/tests/exportInsightsTabs.spec.ts | 915 | export.spec.ts | 118 | DONE -- added 4 export button tests for Favorites/Relays/Systems/Microworkflows (118->211L, +4 tests) |
| 17 | e2e/tests/bpo.spec.ts | 160 | bpo.spec.ts | 10 | DONE -- factory covers all 5 dev test cases, no additions needed |
| 18 | e2e/tests/projects.spec.ts | 159 | projects.spec.ts | 10 | DONE -- factory covers all 5 dev test cases, no additions needed |
| 19 | e2e/tests/teams.spec.ts | 329 | teams.spec.ts | 179 | DONE -- added admin flip test (179->231L, +1 test) |
| 20 | e2e/tests/users.spec.ts | 422 | users.spec.ts | 143 | DONE -- added name editing + admin flip tests (143->202L, +2 tests) |
| 21 | e2e/tests/userAssignmentsTeams.spec.ts | 555 | assignments.spec.ts | 161 | DONE -- +1 test; 4 more permutation tests in standalone prompt qa-test-migration-cleanup-items.md |
| 22 | e2e/tests/generalComponents.spec.ts | 229 | components.spec.ts | 106 | DONE -- all 3 viable tests already covered, refresh test skipped in dev too |

### Tier 3: DEAD on sd/productionize (SKIP)

| # | File | Reason |
|---|------|--------|
| - | src/shared/hooks/useCountdownTimer/useCountdownTimer.spec.ts (311L) | useCountdownTimer does not exist |
| - | src/shared/ui/Timestamp/Timestamp.spec.tsx (65L) | Timestamp component does not exist |
| - | src/ui/components/8flow/Header/InlineFiltersToggleBtn/...formatters.spec.ts (229L) | InlineFiltersToggleBtn does not exist |
| - | src/ui/components/8flow/Header/InlineFiltersToggleBtn/...getFormattedFiltersValues.spec.ts (299L) | InlineFiltersToggleBtn does not exist |
| - | src/ui/page_blocks/dashboard/hooks/useNavigateToWorkstream/useNavigateToWorkstream.spec.ts (202L) | useNavigateToWorkstream does not exist |
| - | src/ui/providers/context/auth/hooks/__tests__/useAuthBusinessLogic.spec.tsx (556L) | Different path, auth restructured (spec already exists at hooks/) |
| - | src/ui/providers/context/insightsContext/utils/adapters/mapSystemPages/mapSystemPages.spec.ts (277L) | Adapters directory does not exist |
| - | src/ui/providers/context/insightsContext/utils/adapters/mapUserOccurrences/mapUserOccurrences.spec.ts (349L) | Adapters directory does not exist |
| - | src/ui/providers/context/insightsContext/utils/adapters/mapUserWorkstreams/mapUserWorkstreams.spec.ts (132L) | Adapters directory does not exist |
| - | src/ui/providers/context/insightsContext/utils/queryParams/queryParams.spec.ts (673L) | queryParams directory does not exist |
| - | src/tests/testE2EUtils.spec.ts (587L) | src/tests/ directory does not exist |
| - | e2e/tests/ProdSmokeTests/prodSmokeTestsAirbnb.spec.ts | SSO-only, prod tenant |
| - | e2e/tests/ProdSmokeTests/prodSmokeTestsGenpact.spec.ts | SSO-only, prod tenant |

### Constants Delta

The development `e2e/constants.ts` has test IDs not present in
`integration/constants.ts`. Key additions needed for new tab specs:

- `SystemsIds` enum entries (SYSTEM_CELL, AVG_ACTIVE_TIME_USER_CELL,
  MICROWORKFLOW_OCCURRENCES_CELL, PAGE_CELL, TIME_SPENT_IN_PERIOD_CELL)
- `FavoritesandRelaysIds` -- already present in integration/constants.ts
- `SortingSelectTestIds` enum (for Systems tab sorting)
- `PageNavigationTestids` enum (for page size selection)
- `PlaceholderContainerTestIds` enum
- Team name differences (dev uses test tenants, prod uses fixture data)

## Migration Phases

| # | Phase | Prompt | What | Files | Status |
|---|-------|--------|------|-------|--------|
| 1 | Unit test port | qa-test-migration-01-unit-tests | Port 1 new spec, merge enhancements from 6 modified specs | 7 | DONE (4 ported, 3 skipped) |
| 2 | Constants + POM prep | qa-test-migration-02-constants-pom | Add missing test IDs to constants, extend InsightsPage POM for new tabs | 2-3 | DONE |
| 3 | New tab specs: Favorites + Relays | qa-test-migration-03-favorites-relays | Port Favorites and Relays e2e specs to integration/ | 2 specs + fixtures | DONE |
| 4 | New tab specs: Microworkflows + Workstreams | qa-test-migration-04-microworkflows-workstreams | Port Microworkflows and Workstreams e2e specs to integration/ | 2 specs + fixtures | DONE |
| 5 | New tab spec: Systems | qa-test-migration-05-systems | Port Systems e2e spec (largest, 654L + 3202L utils) to integration/ | 1 spec + fixtures | DONE |
| 6 | Existing spec enhancement | qa-test-migration-06-enhance-existing | Diff overlapping e2e specs, add missing test cases to existing integration specs | 10 specs | DONE (11 tests added across 6 specs, 4 specs unchanged) |
| 7 | Cleanup | qa-test-migration-cleanup | Address cleanup items, verify all specs run | varies | DONE -- 2 items moved to standalone prompt, 3 deferred |

## Dependency Graph

```
Phase 1 (unit tests -- independent, no e2e dependency)
     |
Phase 2 (constants + POM updates)
     |
     +--------+---------+
     |        |         |
     v        v         v
Phase 3    Phase 4    Phase 5   (new tab specs -- independent after Phase 2)
     |        |         |
     +--------+---------+
              |
              v
         Phase 6 (existing spec enhancement -- can diff after new tabs done)
              |
              v
         Phase 7 (cleanup)
```

## Final Results

| Metric | Baseline | After Migration |
|--------|----------|-----------------|
| Unit spec files | 198 | 199 (+1) |
| Unit tests | 2,407 | 2,505 (+98) |
| Integration spec files | 18 | 21 (+3: favorites, relays, microworkflows) |
| Commits | -- | 14 |
| tsc / build / eslint | clean | clean |

### Production code changes ported
- `formatInt`: widened to accept `string | number`
- `formatCellValue`: returns `-` for invalid inputs instead of `0.00`; added `NO_VALUE_PLACEHOLDER` constant
- `EditUserModal/utils`: `.filter(Boolean)` -> `.filter(field => field !== undefined)`

### Remaining work (standalone prompt)
- `~/plans/prompts/qa-test-migration-cleanup-items.md`: TextInputModal UX + 4 assignment permutation tests -- DONE (921e4749, ae752f33)

### Items deferred (no prompt, documented only)
- `formatDuration` label change (`sec`/`min` -> `s`/`m`): cosmetic, not a bug fix
- `MetricsDisplay` spec label mismatch: auto-resolves if formatDuration changes
- `microworkflows.spec.ts` URL matching style: works correctly as-is

## Blocking Considerations

1. **Tier 1b modified specs with production code changes**: The development
   branch changed production code (formatInt accepts strings, formatCellValue
   uses NO_VALUE_PLACEHOLDER). The new test cases test the NEW behavior which
   does not exist on sd/productionize. The work agent must:
   - Check if the production code change is desirable (bug fix or feature)
   - If yes: port both the production code change AND the new tests
   - If no: skip those test cases and document in cleanup

2. **E2E mock data utilities are enormous**: mockDataSystems.ts is 3,202 lines
   of hardcoded JSON. The migration strategy is to replace these with fixture
   builder calls using the existing `src/fixtures/` infrastructure. The work
   agent should NOT port the raw JSON. Instead, it should understand what data
   shape the spec needs and use `build()` / `buildMany()` from fixture builders.

3. **Auth swap**: Every e2e spec uses `signInAsONELOGINAdmin`. Replace with
   `signInWithEmulator` from `integration/utils/auth.ts`.

4. **Constants alignment**: Team names differ between branches (dev uses
   real tenant names, prod uses fixture data names). The work agent must use
   the fixture-appropriate team names.
