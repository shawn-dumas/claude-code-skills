# AST Vitest Parity Tool + Rename + Audit

> Rename ast-test-parity to ast-pw-test-parity, build a new
> ast-vitest-parity observation tool + interpreter, ground it with
> synthetic and forensic fixtures, then run a unit test parity audit
> comparing production branch tests to sd/productionize.
>
> Created: 2026-03-15
> Branch: sd/productionize (main worktree ~/github/user-frontend)
> Complexity: D5 S4 Z5 = 4.7
> Duration: F3 C2 = 6h (3-12h)
> Nearest: AST Tools Enhancement (5.7, F3 C1), FE Audit Fix (5.7, F4 C1)

**Scoring rationale:** D5: building a new AST tool modeled on an existing
one is moderate -- the observation extraction is simpler (no POM, no
page.route, no serial mode), but the matching algorithm needs judgment
(describe/it blocks, vi.mock targets, assertion patterns). The rename
is mechanical but touches many files. Most risks caught by existing
AST test infrastructure. S4: AST tools layer (scripts/AST/), skills
layer (.claude/skills/), docs layer (AGENTS.md, docs), ground truth
fixtures -- 3 layers but narrow within each. Z5: 6 prompts + cleanup,
~40-50 files (most are new files for the tool + fixtures, plus
mechanical edits for the rename). F3: the rename prompt edits ~24 files
but they're all find-and-replace on a unique string; the build prompts
create new files (low mismatch risk). C2: single day, two sessions --
prompts 1-4 are well-specified generative work that should execute
fast; prompt 5 (forensic) requires judgment but is bounded; prompt 6
(audit) is a report.

## Architecture

### Rename (Prompt 01)

Mechanical rename of all `ast-test-parity` references to
`ast-pw-test-parity`. Affects:

**Files to rename:**
- `scripts/AST/ast-test-parity.ts` -> `scripts/AST/ast-pw-test-parity.ts`
- `scripts/AST/ast-interpret-test-parity.ts` -> `scripts/AST/ast-interpret-pw-test-parity.ts`
- `scripts/AST/__tests__/ast-test-parity.spec.ts` -> `scripts/AST/__tests__/ast-pw-test-parity.spec.ts`
- `scripts/AST/__tests__/ast-interpret-test-parity.spec.ts` -> `scripts/AST/__tests__/ast-interpret-pw-test-parity.spec.ts`

**Files to edit (import paths -- will break if missed):**
- `scripts/AST/tool-registry.ts` -- import path (line 24), registry name `'test-parity'` -> `'pw-test-parity'` (line 121), comment (line 7)
- `scripts/AST/ast-interpret-test-parity.ts` -- import from `'./ast-test-parity'`, usage strings, isDirectRun guard
- `scripts/AST/__tests__/interpreter-accuracy.spec.ts` -- import paths from both tools
- `scripts/AST/__tests__/tool-registry.spec.ts` -- registry name assertion

**Files to edit (references in docs/skills):**
- `AGENTS.md` -- tool inventory table
- `.claude/skills/build-playwright-test/SKILL.md` -- Step 0 commands
- `.claude/skills/refactor-playwright-test/SKILL.md` -- Step 0 command, Step 6 feedback
- `.claude/skills/calibrate-ast-interpreter/SKILL.md` -- tool reference
- `.claude/skills/README.md` -- tool reference
- `scripts/AST/docs/ast-calibration.md` -- tool references
- `scripts/AST/docs/ast-observation-signals.md` -- tool references
- `scripts/AST/docs/ast-parity-matching.md` -- interpreter reference
- `scripts/AST/README.md` -- tool references

**Files to edit (comments -- not breaking but should be updated):**
- `scripts/AST/git-source.ts` -- "Extracted from ast-test-parity.ts"
- `scripts/AST/shared.ts` -- "shared by ast-test-analysis and ast-test-parity"
- `scripts/AST/ast-test-analysis.ts` -- "Adapted from ast-test-parity's"
- `scripts/AST/types.ts` -- section comments (2 occurrences)
- `scripts/AST/__tests__/fixtures/pw-helper.ts` -- comment
- `scripts/AST/__tests__/fixtures/pw-spec-factory.spec.ts` -- comment
- `scripts/AST/__tests__/fixtures/pw-spec-negative.spec.ts` -- comment
- `scripts/AST/__tests__/fixtures/pw-spec-positive.spec.ts` -- comment

**Files to edit (self-references inside renamed files):**
- `scripts/AST/ast-test-parity.ts` -- cache keys, usage strings, isDirectRun guard, stderr prefix

**Config:** `scripts/AST/ast-config.ts` -- `testParity` config key stays
(it's the config section, not the tool name); update any inline comments
referencing the old filename.

**Ground truth manifests:** `git-parity-*`, `synth-parity-*` --
`"tool": "parity"` key stays (tool class, not filename).

**Out-of-repo references:** `~/.claude/CLAUDE.md` references
`ast-test-parity` in the Audit Protocol section (AST-Confirmed Finding
Tier). This file is outside the UF repo. Prompt 01 must update it
after the in-repo rename, or add it to the cleanup file.

**No type renames.** The `Pw*` prefixed types (`PwSpecInventory`,
`PwTestBlock`, etc.) in `types.ts` are already correctly prefixed.
The `testParity` config key in `ast-config.ts` is a config section
name, not a tool name -- leave it.

### New Tool: ast-vitest-parity (Prompts 02-03)

**Observation tool** (`ast-vitest-parity.ts`): Extracts structural
observations from Vitest spec files:

| Observation Kind | Evidence Fields |
|---|---|
| `VT_DESCRIBE_BLOCK` | `name`, `nestedDepth`, `testCount` |
| `VT_TEST_BLOCK` | `name`, `parentDescribe`, `assertionCount` |
| `VT_ASSERTION` | `matcher`, `target`, `negated`, `parentTest` |
| `VT_MOCK_DECLARATION` | `mockTarget`, `mockType` (vi.mock/vi.spyOn/vi.fn), `parentDescribe` |
| `VT_RENDER_CALL` | `component`, `hasWrapper`, `parentTest` |
| `VT_FIXTURE_IMPORT` | `source`, `builders` |
| `VT_BEFORE_EACH` | `hasCleanup`, `scope` |
| `VT_AFTER_EACH` | `cleanupTargets`, `scope` |

Observation prefix is `VT_` (Vitest) to parallel `PW_` (Playwright).

**Reuse from `ast-test-analysis`:** The existing tool already extracts
`MOCK_DECLARATION`, `ASSERTION_CALL`, `RENDER_CALL`, `CLEANUP_CALL`,
`FIXTURE_IMPORT` from Vitest files. The new tool should import and
re-type these observations rather than re-extracting from scratch.
The additional observations (`VT_DESCRIBE_BLOCK`, `VT_TEST_BLOCK`
with `parentDescribe` context) are new extraction work. Prompt 02
should import from `ast-test-analysis` and document the dependency.

Supports `--source-branch` for reading files from git (same as
ast-pw-test-parity).

**Interpreter** (`ast-interpret-vitest-parity.ts`): Compares source
vs target Vitest spec files. Matches tests by:

1. Exact test name match (highest confidence)
2. Fuzzy test name similarity (Levenshtein / token overlap)
3. Assertion target overlap (what the test checks)
4. Mock target overlap (what the test mocks)

Scoring model mirrors PW parity:
- `PARITY`: matched test with comparable assertion count
- `REDUCED`: matched test with fewer assertions
- `EXPANDED`: matched test with more assertions
- `NOT_PORTED`: source test with no match in target

Score = sum(matched_weight) / sum(total_weight) * 100

### Ground Truth (Prompts 04-05)

**Prompt 04 -- Synthetic fixtures:** Build 3 synthetic fixture pairs
covering the four classification states:

- `synth-vitest-parity-01-exact-match`: Source and target with identical
  test names and assertion counts -> PARITY
- `synth-vitest-parity-02-reduced-coverage`: Source has 5 tests, target
  has 3 (2 missing, 1 reduced assertions) -> REDUCED + NOT_PORTED
- `synth-vitest-parity-03-expanded-refactor`: Target splits one source
  test into two with more assertions -> EXPANDED

**Prompt 05 -- Forensic fixtures:** Analyze git history and OpenCode
session logs to find real unit test refactoring pairs:

1. `git log production..sd/productionize -- '*.spec.ts' '*.spec.tsx'`
   to find test files that changed
2. For files that were rewritten (high insertion + deletion count),
   snapshot the `production` version (source) and current version
   (target)
3. Classify each test match manually to create ground truth
4. Target: 3-5 forensic fixtures from real refactored tests

### Audit (Prompt 06)

Run `ast-vitest-parity` + `ast-interpret-vitest-parity` across all
unit test files, comparing `production` branch (source) to current
`sd/productionize` (target). Output to `~/audits/`.

Audit answers:
- How many tests were ported with full parity?
- How many lost coverage (REDUCED)?
- How many were never ported (NOT_PORTED)?
- How many gained coverage (EXPANDED)?
- Which files need attention?

## Prompt Sequence

| # | Prompt | Mode | Files | Depends On |
|---|--------|------|-------|------------|
| 01 | Rename ast-test-parity to ast-pw-test-parity | Auto | ~24 | -- |
| 02 | Build ast-vitest-parity observation tool | Auto | ~5 | -- |
| 03 | Build ast-interpret-vitest-parity interpreter | Auto | ~3 | 02 |
| 04 | Build synthetic ground truth fixtures | Auto | ~9 | 02, 03 |
| 05 | Forensic analysis for real ground truth fixtures | Manual | ~10-15 | 02, 03 |
| 06 | Run unit test parity audit | Manual | audit output | 01, 03, 04, 05 |
| -- | Cleanup | Auto | varies | all |

**Sequencing note:** Prompts 01 and 02 have no data dependency, but per
the orchestration protocol, do NOT run them as parallel Task agents on
the same working tree. Run them sequentially. Prompt 03 depends on 02.
Prompts 04 and 05 depend on 02+03 but are independent of each other
(still run sequentially).

## Standing Prompt Elements

- **TYPE SAFETY SWEEP**: Yes (after Prompt 03, run ast-type-safety on new tools)
- **DEAD CODE PASS**: Not needed (creating new code, not refactoring)
- **IMPORT BOUNDARY CHECK**: Not needed (AST tools are standalone scripts)
- **TEST INFRA PREP**: Yes (Prompt 02 needs vitest.config.mts entry)
- **DOCS GREP**: Yes (after Prompt 01, verify no stale references remain)
- **SKILLS SYNC**: Yes (after Prompt 01 and after Prompt 03, run `bash ~/scripts/sync-skills.sh` per Skills Sync protocol)
- **AUDIT PROTOCOL UPDATE**: Yes (after Prompt 03, add `ast-vitest-parity` entry to AST-Confirmed Finding Tier in `~/.claude/CLAUDE.md`; rename `ast-test-parity` -> `ast-pw-test-parity` in the same section)

## Pre-Execution Verification

```bash
# Confirm on correct branch
cd ~/github/user-frontend && git branch --show-current
# should be sd/productionize

# Confirm clean working tree
git status

# Confirm existing tools exist
ls scripts/AST/ast-test-parity.ts \
   scripts/AST/ast-interpret-test-parity.ts \
   scripts/AST/__tests__/ast-test-parity.spec.ts \
   scripts/AST/__tests__/ast-interpret-test-parity.spec.ts

# Confirm production branch exists for parity comparison
git rev-parse production

# Baseline: existing AST tests pass
npx vitest run --config scripts/AST/vitest.config.mts 2>&1 | tail -10

# Count source test files on production branch
git ls-tree -r production --name-only | grep -E '\.(spec|test)\.(ts|tsx)$' | wc -l

# Count target test files on current branch
find src -name '*.spec.ts' -o -name '*.spec.tsx' -o -name '*.test.ts' -o -name '*.test.tsx' | wc -l
```

## Verification Checklist

| # | Verification | PASS/FAIL |
|---|---|---|
| 01 | `rg 'ast-test-parity' . --type md --type ts` returns 0 hits; AST tests pass | |
| 02 | `npx tsx scripts/AST/ast-vitest-parity.ts src/ui/page_blocks/dashboard/team/ --pretty` runs clean | |
| 03 | `npx tsx scripts/AST/ast-interpret-vitest-parity.ts --source-branch production ... --pretty` runs clean | |
| 04 | Synthetic fixtures produce expected classifications; AST tests pass | |
| 05 | Forensic fixtures produce expected classifications; AST tests pass | |
| 06 | Audit report written to ~/audits/ with summary statistics | |

## Post-Execution Verification

After all prompts and cleanup are complete, these must all pass before
the plan is considered done:

### Tests

```bash
# All AST tests pass (including new parity tool tests + interpreter-accuracy)
npx vitest run --config scripts/AST/vitest.config.mts

# Full project test suite still passes
pnpm test --run

# TypeScript compiles
npx tsc --noEmit
```

### Docs and Skills

```bash
# No stale references to old tool name anywhere in repo
rg 'ast-test-parity' . --type ts --type md -g '!plans/' -g '!node_modules/'
# Expected: 0 hits

# No stale references in out-of-repo files
rg 'ast-test-parity' ~/.claude/CLAUDE.md ~/.claude/skills/
# Expected: 0 hits

# New tool documented in AGENTS.md
rg 'ast-vitest-parity' AGENTS.md
# Expected: 1+ hits (tool inventory table)

# New tool documented in AST README
rg 'ast-vitest-parity' scripts/AST/README.md
# Expected: 1+ hits

# New tool in AST-Confirmed Finding Tier
rg 'ast-vitest-parity' ~/.claude/CLAUDE.md
# Expected: 1 hit (Vitest parity entry)

# Renamed tool in AST-Confirmed Finding Tier
rg 'ast-pw-test-parity' ~/.claude/CLAUDE.md
# Expected: 1 hit (Test parity entry, updated)

# Skills synced to standalone repo
diff <(rg -l 'ast-pw-test-parity' .claude/skills/) <(rg -l 'ast-pw-test-parity' ~/.claude/skills/)
# Expected: matching file lists

# Tool registered
rg 'vitest-parity' scripts/AST/tool-registry.ts
# Expected: registry entry + import
```

### Audit Output

```bash
# Audit report exists
ls ~/audits/vitest-parity-audit-2026-03-15.md
```
