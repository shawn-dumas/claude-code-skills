# Feature: Interpreter Calibration Infrastructure

> Add ground-truth calibration to all six uncalibrated AST interpreters,
> enabling deterministic classification that removes LLM judgment variance
> from audit and refactor findings.
>
> Created: 2026-03-15
> Branch: sd/productionize
> Complexity: D5 S5 Z6 = 5.3
> Duration: F2 C3 = 10h (5-20h)
> Nearest: FE-to-BFF Mapper Migration (5.0, F3 C3), AST Tools Enhancement (5.7, F3 C1)
> Integration scope: none (AST tooling only, no app code changes)
> Pre-flight: CERTIFIED 2026-03-15 by pre-flight-plan-audit
> Pre-flight findings: 0 blockers, 0 warnings (2 false-positive SKILL_REFERENCE on sync-skills.sh)

**Scoring rationale:** D5: moderate -- building evaluation harness
requires understanding interpreter internals, but each interpreter
already has thorough unit tests (300-930 lines each) that document
the classification logic. The main judgment call is authoring ground-truth
fixtures from real codebase files. S5: touches AST interpreter tests,
ground-truth fixtures, calibration skill, AGENTS.md/CLAUDE.md docs,
consuming skill SKILL.md files (7 skills), and sink repo. Z6: 10
prompts (7 interpreter work + 1 infrastructure + 1 docs/skill/feedback
+ 1 preflight/sync + 1 cleanup), ~30 files created/modified.
F2: each prompt creates 2-4 new files (fixtures + manifests) and modifies
1-2 existing files (test harness, skill). Low edit-mismatch risk since
most work is new file creation. C3: two sessions over 1-2 days.
Prompts 02-07 are independent and can run in any order after 01.

## Design

The calibration system currently supports three tools (intent, pw-parity,
vitest-parity) with ground-truth fixtures, accuracy regression tests,
and the `/calibrate-ast-interpreter` skill. Six interpreters lack this
infrastructure:

| Interpreter | Categories | Consuming skills | Existing unit tests |
|---|---|---|---|
| ast-interpret-effects | 6 | 6 | 442 lines |
| ast-interpret-hooks | 5 | 6 | 517 lines |
| ast-interpret-ownership | 5 | 5 | 770 lines |
| ast-interpret-template | 2 | 2 | 300 lines |
| ast-interpret-test-quality | 13 | 7 | 931 lines |
| ast-interpret-dead-code | 4 | 4 | 399 lines |

These interpreters produce classification judgments that skills trust
and tag as `[AST-confirmed]`. Without ground-truth calibration, there
is no way to measure whether those judgments are correct on real
codebase files.

### Fixture format

These interpreters classify observations from single files (not
before/after pairs like intent, or source/target pairs like parity).
Each fixture is a self-contained directory with:

- A synthetic or extracted source file (the input)
- A `manifest.json` with expected classifications per observation

Example manifest:

```json
{
  "tool": "effects",
  "created": "2026-03-15",
  "source": "synthetic",
  "files": ["component-with-effects.tsx"],
  "expectedClassifications": [
    {
      "file": "component-with-effects.tsx",
      "line": 12,
      "symbol": "useEffect",
      "expectedKind": "DERIVED_STATE",
      "notes": "sets state from prop transformation"
    }
  ],
  "status": "pending"
}
```

Self-contained fixtures (synthetic source files in the fixture directory)
are preferred over real-file references because they do not go stale
when the codebase changes.

### New Files

| File | Type | Purpose |
|------|------|---------|
| `scripts/AST/ground-truth/fixtures/synth-effects-*/` | Fixture dirs | Effects interpreter ground truth |
| `scripts/AST/ground-truth/fixtures/synth-hooks-*/` | Fixture dirs | Hooks interpreter ground truth |
| `scripts/AST/ground-truth/fixtures/synth-ownership-*/` | Fixture dirs | Ownership interpreter ground truth |
| `scripts/AST/ground-truth/fixtures/synth-template-*/` | Fixture dirs | Template interpreter ground truth |
| `scripts/AST/ground-truth/fixtures/synth-test-quality-*/` | Fixture dirs | Test quality interpreter ground truth |
| `scripts/AST/ground-truth/fixtures/synth-dead-code-*/` | Fixture dirs | Dead code interpreter ground truth |

### Modified Files

| File | What changes |
|------|-------------|
| `scripts/AST/__tests__/interpreter-accuracy.spec.ts` | Add entry-based evaluation harness + 6 new tool describe blocks |
| `.claude/skills/calibrate-ast-interpreter/SKILL.md` | Add --tool support for all 6 interpreters |
| `scripts/AST/docs/ast-calibration.md` | Add sections for all 6 interpreters, update accuracy table |
| `CLAUDE.md` | Update AST-confirmed categories list |
| `AGENTS.md` | Update calibration system description, list all 9 calibrated tools |
| `.claude/skills/audit-react-feature/SKILL.md` | Add feedback loop for effects/hooks/ownership/template interpreter misclassifications |
| `.claude/skills/audit-react-test/SKILL.md` | Add feedback loop for test-quality interpreter misclassifications |
| `.claude/skills/audit-module-test/SKILL.md` | Add feedback loop for test-quality interpreter misclassifications |
| `.claude/skills/audit-module/SKILL.md` | Add feedback loop for dead-code interpreter misclassifications |
| `.claude/skills/audit-api-handler/SKILL.md` | Add feedback loop for dead-code interpreter misclassifications |
| `.claude/skills/build-react-test/SKILL.md` | Add feedback loop for ownership interpreter misclassifications |
| `scripts/AST/ast-plan-audit.ts` | Update tool inventory validation if interpreter list is referenced |

## Implementation Phases

| # | Phase | Prompt | What | Depends on | Mode | Status |
|---|-------|--------|------|-----------|------|--------|
| 1 | Infrastructure | 01-evaluation-harness | Build entry-based evaluation function in interpreter-accuracy.spec.ts | none | Auto | pending |
| 2 | Effects | 02-effects | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 3 | Hooks | 03-hooks | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 4 | Ownership | 04-ownership | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 5 | Template | 05-template | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 6 | Test quality | 06-test-quality | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 7 | Dead code | 07-dead-code | Author fixtures, wire evaluate function, verify accuracy | Phase 1 | Auto | pending |
| 8 | Docs + skill + feedback wiring | 08-docs-skill-feedback | Update calibration skill, docs, AGENTS.md, CLAUDE.md; wire feedback loop into all consuming skills | Phases 2-7 | Auto | pending |
| 9 | Pre-flight + sync | 09-preflight-and-sync | Run ast-plan-audit, run pre-flight-plan-audit, sync to sink, commit and push both repos | Phase 8 | Auto | pending |
| 10 | Cleanup | cleanup | Sweep for dead code, verify all tests pass, final reconciliation | Phase 9 | Auto | pending |

Phases 2-7 are independent of each other and can run in any order.

## Cleanup file

`~/plans/interpreter-calibration-infrastructure-cleanup.md` -- prompts
append items during execution.

## Verification Checklist

After all phases complete:

- `npx vitest run --config scripts/AST/vitest.config.mts` -- all tests pass
- Every interpreter has >= 60% accuracy on its ground-truth fixtures
- `pnpm tsc --noEmit` -- zero errors
- `pnpm build` -- clean
- `/calibrate-ast-interpreter --tool <name>` works for all 9 tool values
- `ast-calibration.md` accuracy table has entries for all 9 tools
- All consuming skills have feedback loop instructions for their interpreters
- `ast-plan-audit` validates this plan (no PROMPT_VERIFICATION_MISSING, no PROMPT_DEPENDENCY_CYCLE)
- Sink (`~/.claude/skills/`) is synced, committed, and pushed
- UF repo is committed and pushed
