# Dev Panel

> Complexity: D6 S6 Z6 = 6.0
> Nearest: DDAU Exception Elimination (6.0), Git Protocol Hardening (6.0)
>
> Status: COMPLETE (2026-03-11)
> Prompts: 3 planned, 3 executed, 3 PASS
> Commits: 97901b33, c8bd9491, 09986702
> Branch: sd/dev-panel (worktree: user-frontend-dev-panel)
> Cleanup: 1 pre-existing item (SVG tsc errors), 0 introduced
> Score: 9/10 -- clean execution, all verifications passed, one minor
> deviation (Providers.spec.tsx mock added in P02, justified)

A non-production side drawer that lets engineers toggle feature flags, switch
roles, change the data source, and sign in to emulator accounts -- without the
browser console. A persistent top bar shows the active dev panel settings at
all times.

## Prerequisite

The BFF lift-and-shift plan is complete (archived 2026-03-08). The following
BFF artifacts are already in place and the dev panel depends on them:

- `clientEnv` (Zod-validated env module at `src/shared/lib/env/clientEnv.ts`)
  -- runtime `process.env` reads go through `clientEnv`. The
  `local/no-process-env` ESLint rule enforces this. The only exceptions are
  literal `process.env` guards used for build-time tree-shaking, each with an
  `eslint-disable` comment.
- Source files touched by the dev panel (useFeatureFlags, posthogProvider,
  AuthStateProvider) already import `clientEnv` where needed.
- `docs/local-development.md` and `CLAUDE.md` have BFF content merged in.

## Decisions

| Decision             | Choice                                                                                                                                                                                                         |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Flag toggle behavior | Live (no reload). Refactor `useFeatureFlags` to expose a setter.                                                                                                                                               |
| Panel UI             | Side drawer, slides in from the right edge.                                                                                                                                                                    |
| Trigger              | Keyboard shortcut only. No persistent button.                                                                                                                                                                  |
| Shortcut             | `Ctrl+Shift+.` (period). Unused in Chrome/Firefox/Safari. Memorable (". for dev settings").                                                                                                                    |
| Sign-in              | Include email/password fields that call `__devSignIn`. Only shown in `local` mode (Firebase emulator required).                                                                                                |
| Data source          | Toggle between `mock` (`/api/mock/`) and `bff` (`/api/`). Invalidates QueryClient on switch. Shows reachability status for BFF.                                                                                |
| Mount point          | Inside `Providers.tsx`, next to `ReactQueryDevtools`. Must be inside the provider tree to access PosthogContext and AuthStateContext.                                                                          |
| Override banner      | Thin fixed bar at the top of the viewport. Only visible when overrides are active (flags, roles, or data source). Amber background. Non-dismissible -- disappears when all overrides are cleared.              |
| Env gate             | Tree-shaking guard at mount point: `process.env.NEXT_PUBLIC_ENVIRONMENT !== 'production'` with `eslint-disable` comment (same pattern as all other dev helpers). Available in both `local` and `mocked` modes. |

## Technical Design

### 1. useFeatureFlags gains two callbacks

```ts
// Only active in local and mocked environments. Noops in production/staging/development.

setLocalOverrides(overrides: Partial<FeatureFlagsShape>)
  -> merges: setFeatureFlags({ ...localAllOnFlags, ...overrides })
  -> persists: writeStorage(LOCAL_FEATURE_FLAGS_KEY, overrides)

clearLocalOverrides()
  -> resets: setFeatureFlags(localAllOnFlags)
  -> removes: removeStorage(LOCAL_FEATURE_FLAGS_KEY)
```

Return type changes from `{ featureFlags }` to
`{ featureFlags, setLocalOverrides, clearLocalOverrides }`.

### 2. PosthogContext exposes the new callbacks

```ts
interface PosthogContextProps {
  posthogClient: PostHog | void;
  featureFlags: FeatureFlagsShape;
  setLocalOverrides: (overrides: Partial<FeatureFlagsShape>) => void;
  clearLocalOverrides: () => void;
}
```

The `window.__setFeatureFlags` / `__clearFeatureFlags` bindings move from
module-level code in `usePosthogClient.ts` into the `PosthogProvider` component
body. They call the new callbacks instead of writing to localStorage + reloading.

Note: unlike `__setRoles` in AuthStateProvider (which uses `=== 'local'` because
it requires the Firebase emulator), the flag helpers work in both local and
mocked modes. Use `process.env.NEXT_PUBLIC_ENVIRONMENT !== 'production'` as the
tree-shaking guard (with `eslint-disable` comment). This also fixes the existing
discrepancy where AGENTS.md claims these helpers are available in "local and
mocked" but the old code only gated on `=== 'local'`.

### 3. AuthStateContext gains isRolesOverridden

Add `isRolesOverridden: boolean` to `AuthStateContextType`. Managed by a
`useState<boolean>(false)` in `AuthStateProvider`. Set to `true` when
`__setRoles` is called, `false` when `__clearRoles` is called. This lets the
banner react to role overrides without polling a module-level variable.

### 4. Data source toggle infrastructure

**File**: `src/ui/config.ts`

Add a module-level mutable override and a setter:

```ts
let apiHostOverride: string | null = null;

export function getApiHost() {
  if (apiHostOverride !== null) return apiHostOverride;
  const env = clientEnv.NEXT_PUBLIC_ENVIRONMENT;
  if (env === Environment.MOCKED) {
    return "/api/mock";
  }
  return "/api";
}

// Dev-only. Tree-shaking guard at call sites.
export function setApiHost(source: "mock" | "bff") {
  apiHostOverride = source === "mock" ? "/api/mock" : "/api";
}

export function getActiveDataSource(): "mock" | "bff" {
  const host = apiHostOverride ?? getApiHost();
  return host === "/api/mock" ? "mock" : "bff";
}
```

Note: under the current codebase, `mocked` mode defaults to `/api/mock`
(fixture data) and `local` mode defaults to `/api` (real BFF routes). The
toggle lets `mocked` developers switch to real BFF routes if Docker + Postgres
is running, and lets `local` developers switch to mock fixture data when they
want deterministic data without database dependencies.

The DevPanel calls `setApiHost()` then `queryClient.invalidateQueries()` to
force all active queries to refetch from the new source. The `window.__devSignIn`
helper and auth token injection in `withAuth` (`mock-token` accepted in
non-production builds) mean auth works regardless of which source is active.

**Follow-up**: the injected `LOCAL_DEV_CONTEXT` in `withAuth` uses
`organizationId: 0`. BFF queries scoped to org 0 will return empty results
unless the Docker seed data includes that org. A follow-up task should align
the seed data with the injected context (or make the context configurable).
For now, if BFF returns empty/error, the override banner shows the status.

### 5. DevPanel component

Side drawer that slides in from the right edge of the viewport. Four sections:

**Data Source** -- a two-option toggle: `Mock` (`/api/mock/`, fixture data) and
`BFF` (`/api/`, real Postgres/ClickHouse-backed routes). `Mocked` mode defaults
to Mock; `local` mode defaults to BFF. The toggle lets developers switch between
real routes and fixture data at runtime. On change, calls `setApiHost(source)` then
`queryClient.invalidateQueries()`. Shows a status indicator next to BFF: green dot
if `/api/health` responds, red dot with "Docker not running" or "BFF unreachable"
if it fails. The health check runs on panel open and on toggle, not continuously.

**Feature Flags** -- one toggle per boolean flag, a number input for
`filters_date-range_max_days`. Reads `featureFlags` from `usePosthogContext()`.
On change, computes the delta from `localAllOnFlags` and calls
`setLocalOverrides(delta)`. A "Reset All" button calls `clearLocalOverrides()`.

Labels use the human-readable constant keys from `FeatureFlagsToLoad` (e.g.,
"Enable Systems" derived from `ENABLE_SYSTEMS`), with the PostHog string value
shown as a subtitle in muted text.

**Roles** (local mode only) -- a set of toggleable chips or checkboxes for each
role value (`member`, `teamowner`, `admin`, `superadmin`, `internal:admin`). On
change, calls `window.__setRoles(selectedRoles)`. A "Reset to Token" button
calls `window.__clearRoles()`. Shows current active roles from
`useAuthState().roles`.

In `mocked` mode, this section is hidden or shown as disabled with a note:
"Role overrides require local mode (Firebase emulator)." The `window.__setRoles`
helper only exists in `local` mode.

Navigation constraint note: display a small info line reminding the engineer
that hard navigation resets the role override.

**Dev Sign-In** (local mode only) -- email and password inputs with a "Sign In"
button that calls `window.__devSignIn(email, password)`. Pre-fills the last-used
email from localStorage. Shows the current user email from
`useAuthState().user?.email` when signed in. This section is hidden in `mocked`
mode (auth is synthetic, no sign-in needed).

The drawer is rendered with `position: fixed`, high z-index, and a semi-transparent
backdrop that closes the drawer on click. Opened/closed via `Ctrl+Shift+.`.

### 6. OverrideBanner component

A thin (~h-8, 32px) fixed bar at the very top of the viewport. Only rendered
when at least one override is active. Amber/yellow background
(`bg-amber-100 text-amber-900` or similar). Non-dismissible -- disappears only
when all overrides are cleared.

**Override detection:**

- Feature flags: compare current `featureFlags` against `localAllOnFlags`. If
  any value differs, flags are overridden. Count the number of differing keys.
- Roles: read `isRolesOverridden` from `useAuthState()`. If true, show the
  current roles.
- Data source: check if `getActiveDataSource()` differs from the build default
  for the current environment.

**Content examples:**

- "2 flags overridden" (flags only)
- "Roles: teamowner" (roles only)
- "2 flags overridden / Roles: teamowner" (both)
- "Data source: mock (default: bff)" (data source override in local mode)

The text is a clickable link/button that opens the DevPanel drawer (receives
`onOpenPanel` callback or shares open state with DevPanel). When the banner is
visible, it pushes page content down via a spacer div of the same height
rendered immediately after the fixed bar.

### 7. Mount point

In `Providers.tsx`, after `{children}`, alongside `ReactQueryDevtools`:

```tsx
<PosthogProvider>
  {children}
  <ReactQueryDevtools initialIsOpen={false} />
  {/* eslint-disable-next-line local/no-process-env -- tree-shaking: dead-code eliminated in production */}
  {process.env.NEXT_PUBLIC_ENVIRONMENT !== "production" && <DevPanel />}
</PosthogProvider>
```

The `DevPanel` component internally renders the `OverrideBanner` (it has access
to the open/close state, so the banner can open the panel on click). Both are
gated by the single env check in `Providers.tsx`. The `process.env` read is
intentional -- it is a tree-shaking guard (Next.js inlines the value at build
time and the minifier strips the false branch). The `eslint-disable` comment
satisfies the `local/no-process-env` rule.

Note: the gate is `!== "production"` rather than `=== "local"`. This makes the
DevPanel available in both `local` and `mocked` builds. In `mocked` mode the
sign-in section is hidden (auth is synthetic) but data source toggle, feature
flags, and roles all work.

## Implementation Steps

### Step 1: Refactor useFeatureFlags

**File**: `src/shared/hooks/useFeatureFlags/useFeatureFlags.ts`
**Skill**: `/refactor-react-hook`

- Add `setLocalOverrides` and `clearLocalOverrides` callbacks (useCallback, stable refs).
- Guard both: noop when `clientEnv.NEXT_PUBLIC_ENVIRONMENT` is not `local` or
  `mocked`. Import `clientEnv` from `@/shared/lib/env/clientEnv` and
  `Environment` from `@/shared/types` (neither is currently imported -- the
  file's existing `process.env` reads are tree-shaking guards).
- `setLocalOverrides` stores the raw overrides object (not the merged result)
  in localStorage, so clearing individual flags works correctly.
- Change return type from `{ featureFlags }` to
  `{ featureFlags, setLocalOverrides, clearLocalOverrides }`.
- Update the barrel export in `src/shared/hooks/index.ts` if needed.

### Step 2: Update PosthogProvider + context

**File**: `src/ui/providers/posthogProvider.tsx`
**Skill**: `/refactor-react-provider`

- Destructure `setLocalOverrides` and `clearLocalOverrides` from `useFeatureFlags`.
- Add both to `PosthogContextProps` and the context value.
- Move the `window.__setFeatureFlags` / `__clearFeatureFlags` bindings from
  `usePosthogClient.ts` module-level into the PosthogProvider component body.
  They now call `setLocalOverrides` / `clearLocalOverrides` instead of
  `writeStorage` + `location.reload()`. This means `__setFeatureFlags` no
  longer triggers a page reload -- it updates React state live.
- The `window.__` typings on `window` follow the same cast pattern as
  `__setRoles` in AuthStateProvider.

### Step 3: Clean up usePosthogClient

**File**: `src/shared/hooks/usePosthogClient/usePosthogClient.ts`

Remove the entire module-level `if` block (lines 13-28) that sets up
`window.__setFeatureFlags` and `window.__clearFeatureFlags`. This block uses
`process.env.NEXT_PUBLIC_ENVIRONMENT === 'local'` (a tree-shaking guard -- it
was never migrated to `clientEnv`). Delete it regardless; the functionality
moves to PosthogProvider in step 2. Also remove the now-unused imports:
`LOCAL_FEATURE_FLAGS_KEY` from `../useFeatureFlags/constants`,
`FeatureFlagsShape` from `../useFeatureFlags/types`, and
`writeStorage` / `removeStorage` from `@/shared/utils/typedStorage`.

This is a deletion-only change. No skill needed.

### Step 4: Add isRolesOverridden to AuthStateContext

**File**: `src/ui/providers/context/auth/AuthStateProvider.tsx`
**File**: `src/shared/types/auth.ts` (AuthStateContextType)

- Add `isRolesOverridden: boolean` to `AuthStateContextType`.
- Add `const [isRolesOverridden, setIsRolesOverridden] = useState(false)` in
  AuthStateProvider.
- In the `__setRoles` binding: call `setIsRolesOverridden(true)`.
- In the `__clearRoles` binding: call `setIsRolesOverridden(false)`.
- Add `isRolesOverridden` to the context value.

This is a small additive change (~10 lines across 2 files). Can be done by hand.

### Step 5: Add data source toggle to config.ts

**File**: `src/ui/config.ts`

Add `apiHostOverride`, `setApiHost()`, and `getActiveDataSource()` as described
in Technical Design section 4. The existing `getApiHost()` already returns
`/api` for local mode and `/api/mock` for mocked mode -- the override adds a
runtime escape hatch. Also add a `window.__setDataSource` dev helper following
the same tree-shaking guard pattern as `__devSignIn`.

Small additive change (~20 lines). No skill needed.

### Step 6: Build DevPanel + OverrideBanner

**Directory**: `src/ui/components/8flow/DevPanel/`
**Skill**: `/build-react-component` (for the structural scaffolding)

Files to create:

- `DevPanel.tsx` -- the drawer + keyboard shortcut listener + all four sections
- `OverrideBanner.tsx` -- the conditional override indicator bar
- `index.ts` -- barrel export
- `types.ts` -- props interface (if needed, may be empty since it reads from context)

DevPanel is a documented exception to DDAU (like ProfileMenu, DashboardLayout).
It reads directly from `usePosthogContext()`, `useAuthState()`, and
`getActiveDataSource()` because it is a dev-only ambient UI element with no
parent container. Document this in the exceptions list in AGENTS.md.

Implementation notes:

- Use Headless UI `Dialog` or `Transition` for the drawer animation (already
  a dependency).
- The keyboard shortcut hook: `useEffect` with `keydown` listener, check
  `event.ctrlKey && event.shiftKey && event.key === '.'`.
- Data source toggle: two-option segmented control. On switch, call
  `setApiHost(source)` then `queryClient.invalidateQueries()`. Run a
  `fetch('/api/health')` on panel open and on BFF toggle to check reachability.
  Show result as a status dot next to the BFF option.
- Feature flag toggles: derive the list from `FeatureFlagsToLoad` entries.
  Use a `Switch` (Headless UI) for booleans, a number input for
  `filters_date-range_max_days`.
- Role chips: use the `Role` const object values. Style the active roles
  distinctly.
- Sign-in form: simple controlled inputs. `onSubmit` calls
  `window.__devSignIn(email, password)`. Store last-used email in localStorage
  (key: `dev-panel-last-email`). Conditionally rendered: hidden when
  `clientEnv.NEXT_PUBLIC_ENVIRONMENT === Environment.MOCKED`.
- OverrideBanner: only rendered when overrides are active. Amber bar showing
  active overrides (flag count, role name, data source override). Clickable
  text opens the drawer. Pushes page content down via spacer div.
- All Tailwind, no custom CSS files.

### Step 7: Mount in Providers.tsx

**File**: `src/ui/providers/Providers.tsx`

Add the env-gated `<DevPanel />` render inside PosthogProvider, after
`ReactQueryDevtools`. ~3 lines. No skill needed.

### Step 8: Update docs

All by hand. No skill needed.

**CLAUDE.md**:

- Add `DevPanel` to the exceptions list with a one-line rationale.
- Update the dev helpers table: add `__setDataSource` (available in `local`
  and `mocked`). Note that `__setFeatureFlags` and `__clearFeatureFlags` no
  longer trigger a page reload (they update React state live). Add a note
  that all helpers are also available through the Dev Panel UI (`Ctrl+Shift+.`).
- Add a brief "Dev Panel" subsection under dev helpers explaining what it is,
  how to open it, and what it exposes.

**docs/local-development.md**:

- Add a "Dev Panel" section after the current "Role Overrides" section. Explain
  the keyboard shortcut, what the four sections do, and that the top bar shows
  active settings at all times.
- Update the "Runtime flag overrides" subsection: note that
  `window.__setFeatureFlags` no longer reloads the page. Mention the Dev Panel
  as the preferred way to toggle flags.
- Update the "Role Overrides" subsection: mention the Dev Panel as an
  alternative to console commands.
- Add a "Data Source Switching" subsection: explain the mock/BFF toggle, the
  health check, and the org 0 caveat (follow-up planned).

**docs/feature-flags.md**:

- Update the "Runtime overrides" subsection under "Local Development": note
  the no-reload behavior and the Dev Panel UI.
- Update the "Playwright agents" subsection: note that `__setFeatureFlags`
  no longer causes a reload, so no post-reload navigation is needed.
- Update the architecture diagram to show the DevPanel as a consumer.

**docs/integration-testing.md**:

- In the `window.__setFeatureFlags` section: note the no-reload behavior
  change and its impact on test flow (no longer need to wait for reload).
- Mention the Dev Panel exists but is not relevant for Playwright tests
  (Playwright should continue using `page.evaluate` with window helpers).

## Verification

After all steps:

```bash
pnpm tsc --noEmit        # 0 errors
pnpm lint                # 0 errors, 0 warnings
pnpm test --run          # all specs pass
pnpm build               # clean
```

Manual verification (local mode -- `NEXT_PUBLIC_ENVIRONMENT=local`):

1. Start local dev (`pnpm dev` with `.env.local`, Docker running)
2. No banner visible (no overrides active yet)
3. Sign in via emulator
4. Press `Ctrl+Shift+.` -- drawer opens with all four sections
5. Data source shows `bff` selected (local default). Switch to `mock` --
   amber banner appears showing data source override, queries refetch with
   fixture data
6. Switch back to `bff` -- banner data source indicator clears, queries
   refetch from real BFF routes
7. Toggle a feature flag off -- page updates live (no reload), banner shows
   "1 flag overridden"
8. Toggle it back on -- override indicator disappears from banner
9. Change role to `member` -- sidebar/page updates, banner shows role override
10. Click "Reset to Token" -- roles revert, banner override indicator clears
11. Open console, call `window.__setDataSource('mock')` -- data source
    switches, banner updates
12. Press `Ctrl+Shift+.` -- drawer reflects the current data source toggle state

Manual verification (mocked mode -- `NEXT_PUBLIC_ENVIRONMENT=mocked`):

1. Start dev server (no Docker, no Firebase needed)
2. No banner visible (no overrides active yet)
3. App loads as mock admin automatically (no sign-in)
4. Press `Ctrl+Shift+.` -- drawer opens. Sign-in section and Roles section
   are hidden (both require local mode / Firebase emulator).
5. Data source shows `mock` selected (mocked default). Switch to `bff` --
   banner shows data source override. If Docker not running, BFF status shows
   "unreachable". Queries fail gracefully, page shows error states.
6. Switch back to `mock` -- fixture data restored, banner clears

## Scope / Non-goals

- Non-production only (`local` and `mocked`). Zero code in production builds
  (tree-shaking eliminates the entire DevPanel + OverrideBanner).
- No persistence of panel open/closed state across reloads.
- No tests for the DevPanel itself (it is a dev tool, not production code).
  If this changes later, use `/build-react-test`.
- The existing `window.__*` helpers remain functional for console use and
  Playwright. The DevPanel is an additional interface, not a replacement.
- The org 0 data alignment issue (BFF queries return empty results with the
  synthetic `LOCAL_DEV_CONTEXT`) is a known limitation. Follow-up: either seed
  Docker with data for org 0, or make the injected organizationId configurable
  from the DevPanel.
