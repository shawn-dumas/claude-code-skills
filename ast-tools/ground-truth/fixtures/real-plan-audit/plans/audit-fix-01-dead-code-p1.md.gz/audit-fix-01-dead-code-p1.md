# Fix Prompt: P1 Dead Code + Infrastructure Sweep

## Context
- Repo: ~/github/user-frontend
- Branch: sd/productionize
- Source audit: ~/audits/26-03-05-11-16--user-frontend--complete-audit.md
- Cleanup file: ~/plans/backlog-cleanup.md (append to it)

Read ~/github/user-frontend/CLAUDE.md before starting.

## Fixes

### Fix 1: Remove 4 dead npm deps
`package.json:devDependencies` -- concurrently, monocart-reporter, playwright-extra, puppeteer-extra-plugin-stealth have zero usage. Removing them clears 4 security advisories.

```bash
pnpm remove concurrently monocart-reporter playwright-extra puppeteer-extra-plugin-stealth
```

No test needed -- purely structural.

### Fix 2: Delete dead reactQueryIntegration exports
`src/shared/utils/newrelic/reactQueryIntegration.ts:12,60` -- withReactQueryMonitoring and createNewRelicQueryClient have zero external consumers. The onError callback at line 36 is deprecated in TanStack Query v5.

Delete the entire `reactQueryIntegration.ts` file and its spec. Remove from barrel export.

Verify zero consumers first:
```bash
rg 'withReactQueryMonitoring|createNewRelicQueryClient|reactQueryIntegration' src/ --type ts
```

No test needed -- dead code deletion.

### Fix 3: Delete dead createQuantityThenTextSorter directory
`src/shared/utils/table/createQuantityThenTextSorter/` -- entire directory has zero external consumers.

Delete the directory and remove from barrel. Verify:
```bash
rg 'createQuantityThenTextSorter' src/ --type ts
```

No test needed -- dead code deletion.

### Fix 4: Delete dead getLastSundayOfMonth directory
`src/shared/utils/date/getLastSundayOfMonth/` -- entire directory has zero external consumers.

Delete the directory and remove from barrel. Verify:
```bash
rg 'getLastSundayOfMonth' src/ --type ts
```

No test needed -- dead code deletion.

### Fix 5: Remove getStandardTimezoneInfo from barrel export
`src/shared/utils/timezone/getStandardTimezoneInfo.ts:1` -- only consumed internally within the timezone module. Should not be in the public barrel.

Remove from the barrel export in `src/shared/utils/timezone/index.ts` (or equivalent). Keep the file itself -- it has an internal consumer.

Verify no external consumers:
```bash
rg 'getStandardTimezoneInfo' src/ --type ts --glob '!src/shared/utils/timezone/*'
```

No test needed -- barrel cleanup.

### Fix 6: Delete 12 dead interfaces in systems.schema.ts
`src/shared/types/systems.schema.ts:276-371` -- 12 exported interfaces with zero consumers.

Identify which interfaces have zero consumers via grep and delete them. Also delete FirebaseTenantConfig from `src/shared/types/auth.ts:10`.

No test needed -- dead code deletion.

### Fix 7: Delete FetchApiFunction and isApiError dead exports
`src/shared/lib/fetchApi.ts:97` -- FetchApiFunction type alias has zero consumers.
`src/shared/lib/fetchApi.ts:35-37` -- isApiError has zero production consumers.

Remove both from the file and barrel. Verify:
```bash
rg 'FetchApiFunction|isApiError' src/ --type ts --glob '!src/shared/lib/fetchApi.ts'
```

No test needed -- dead code deletion.

### Fix 8: Delete insightsQueryParams re-export shim
`src/shared/utils/insightsQueryParams/insightsQueryParams.ts:1` -- redundant re-export shim. Update the 5 consumers to import from the barrel instead.

Verify consumers:
```bash
rg "from.*insightsQueryParams/insightsQueryParams" src/ --type ts
```

Update each to import from `@/shared/utils/insightsQueryParams` (barrel). Then delete the file.

No test needed -- import path cleanup.

### Fix 9: Delete MetricsType and TTMForDaysResponse dead exports
`src/shared/types/analyzerActivity.ts:34` -- MetricsType only used internally. Remove export keyword.
`src/shared/types/productivity.schema.ts:218` -- TTMForDaysResponse never imported. Remove export.

No test needed -- export trimming.

### Fix 10: Move testUtils.ts out of production source
`src/shared/utils/insightsQueryParams/testUtils.ts:1` -- 589 lines of test helpers living in production source tree with zero production consumers.

Move to a test-adjacent location such as `src/shared/utils/insightsQueryParams/__test-utils__/testUtils.ts` or `src/fixtures/insightsQueryParamsTestUtils.ts`.

Update all consumers (spec files only) to import from the new location.

Verify zero production imports after move:
```bash
rg 'testUtils' src/ --type ts --glob '!**/*.spec.*' --glob '!**/__test*'
```

No test needed -- file relocation.

## Commit Strategy
One commit: "delete dead code and move test utils out of production source"

## When You Are Done

```bash
pnpm tsc --noEmit
pnpm test --run 2>&1 | tail -5
pnpm build 2>&1 | tail -5
npx eslint . --max-warnings 0 2>&1 | tail -3
```

Verify all dead exports are gone:
```bash
rg 'withReactQueryMonitoring|createNewRelicQueryClient|createQuantityThenTextSorter|getLastSundayOfMonth|FetchApiFunction|isApiError|FirebaseTenantConfig' src/ --type ts
```

```
=== RECONCILIATION: audit-fix-01-dead-code-p1 ===
HEAD: <git sha>
Commits: <count> (<first_sha>..<last_sha>)
tsc: <0 errors | N errors>
Tests: <N specs, M passed, K todo>
Build: <clean | failed>
ESLint: <clean | N errors, M warnings>

Prompt-Specific:
  Dead exports grep: <clean | list remaining>
  npm audit: <advisory count>

Behavioral Changes:
  No user-visible changes.

Cleanup Items Added: <N items to cleanup file>
Subsequent Prompts Modified: <none | list>
Deviations: <none | list>
Work Left Undone: <none | list>
=== END RECONCILIATION ===
```
