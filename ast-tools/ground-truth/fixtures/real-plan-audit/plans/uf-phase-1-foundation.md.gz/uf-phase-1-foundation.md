# Phase 1: Foundation

> Port all infrastructure from NGA into UF. This is the biggest phase (~165 files).
> Nothing else can start until this is done.

## Exit Criteria

- `pnpm tsc --noEmit` clean
- `pnpm build` clean
- `pnpm test` -- no new failures
- `NEXT_PUBLIC_LOCAL=true pnpm dev` serves all pages without 404 console errors
- Fixture builders produce Zod-valid data
- Mock handler returns 200 for all known endpoints

## Execution Order

Work items are grouped into sub-phases. Within a sub-phase, items can run
in parallel. Each sub-phase depends on the prior one completing.

---

### Sub-phase 1.0: Tooling + Config

Do this first. Everything else depends on the config being right.

#### 1.0a: Port CLAUDE.md

Copy `~/github/next-gen-atlassian/CLAUDE.md` to `~/github/user-frontend/CLAUDE.md`.
Adapt paths:
- Remove references to `src/pages/api/` (UF is static export, no API routes in prod)
- Update `pnpm dev` port from 3002 to 3001
- Update fetchApi description: base URL = UB in production, mock handler in local mode
- Remove Supabase references
- Keep all DDAU rules, G1-G10 principles, fixture system docs, testing philosophy, skills reference

#### 1.0b: Port .claude/skills/

```
cp -r ~/github/next-gen-atlassian/.claude/skills ~/github/user-frontend/.claude/skills
cp ~/github/next-gen-atlassian/.claude/launch.json ~/github/user-frontend/.claude/
rm -rf ~/github/user-frontend/.claude/commands/
```

32 skill files + README.md. Adapt any NGA-specific paths in skill files
(grep for `next-gen-atlassian` or port numbers).

#### 1.0c: Storybook -- disable Chromatic CI, accept breakage during Phases 2-7

Storybook stays (13 stories + Chromatic CI). Components will be gutted,
rewired, and decomposed in Phases 2-5 and the stories WILL break. This is
accepted. Do not slow down the refactor with story maintenance.

**Disable Chromatic CI checks on `sd/productionize` branch** so broken
stories don't block PRs during the refactor. Re-enable in Phase 8 after
stories are fixed.

#### 1.0d: ESLint + tsconfig + pre-commit alignment

**tsconfig.eslint.json**: Copy from NGA. This is the parser config that
includes test files.

**eslint.config.mjs changes**:
- Add `.next/**/*`, `next-env.d.ts`, `postcss.config.js` to ignores
- Add `**/*.spec.tsx` to test file pattern (UF only has `**/*.spec.ts`)
- Demote `no-unsafe-*` rules from `error` to `warn` (9 rules)
- Change parser tsconfig from `./tsconfig.json` to `./tsconfig.eslint.json`

**Pre-commit (.husky/pre-commit)**:
- Remove `--max-warnings 0` from eslint invocation (allow warnings through)

#### 1.0e: Path aliases

**tsconfig.json** -- add:
```json
"@/fixtures": ["./src/fixtures"],
"@/fixtures/*": ["./src/fixtures/*"]
```

**vitest.config.mts** -- add aliases:
```
'@/constants/testIds', '@/services', '@/hooks', '@/utils', '@/fixtures'
```

#### 1.0f: Vitest config alignment

In `vitest.config.mts`:
```ts
pool: 'forks',
teardownTimeout: 5000,
poolOptions: {
  forks: { minForks: 1, maxForks: 2 },
},
coverage: {
  reporter: ['text', 'html'],
},
```

Update `setupFiles` paths after 1.1i (shared/mocks/ -> shared/test-utils/).

#### 1.0g: Port misc root files

```
cp ~/github/next-gen-atlassian/AGENTS.md ~/github/user-frontend/
cp ~/github/next-gen-atlassian/vite-imports.d.ts ~/github/user-frontend/
```

#### 1.0h: Delete root dead files

```
cd ~/github/user-frontend
rm -f jsconfig.json svg.d.ts next.d.ts 8flow.manifest.json CHANGELOG.md
rm -f lint-staged.config.cjs tsconfig.storybook.json
rm -f vitest.storybook.config.mts vitest.shims.d.ts
```

Audit `.npmrc` -- verify no auth token. The `@8flowinc:registry=...` line
is fine (registry URL, not a secret).

**Checkpoint 1.0 exit criteria**:
```bash
pnpm tsc --noEmit    # still passes (config changes only, no source changes)
pnpm test            # still passes (no source changes)
```

---

### Sub-phase 1.1: Types + Shared Infrastructure

#### 1.1a: Port src/shared/types/ (44 files)

**Rationale for porting all 44**: The types are the foundation everything
else imports -- fixtures, service hooks, mock handler, and components all
depend on them. Porting dead types is low-cost (they sit unused). Missing
a type that a fixture or service hook needs three phases later is expensive.
Port all 44 now, let Phase 6 dead code detection prune anything unused.

This is the biggest single item. Port all 44 files from NGA:

```
src/shared/types/
  api.ts              auth.schema.ts       auth.ts
  automationSuggestion.ts  bpo-projects.schema.ts  bpo-projects.ts
  brand.ts            chat.ts              common.ts
  company.schema.ts   company.ts           detailsTabData.ts
  discoverFilterState.ts  elementAttributes.ts  events.schema.ts
  events.ts           explorer.ts          filterFormStates.schema.ts
  filterFormStates.ts index.ts             insights.ts
  microworkflows.schema.ts  microworkflows.ts  operationalHoursData.schema.ts
  operationalHoursData.ts  productivity.schema.ts  productivity.ts
  realtime.schema.ts  realtime.ts          relay.schema.ts
  relay.ts            spans.schema.ts      spans.ts
  systems.schema.ts   systems.ts           teams.schema.ts
  teams.ts            url-classification.schema.ts  url-classification.ts
  users.schema.ts     users.ts             window.d.ts
  workstreamData.schema.ts  workstreamData.ts  workstreamQueryParams.ts
```

**Before porting**: Move `src/types.ts` to `src/shared/types/common.ts` and
move `src/types/window.d.ts` to `src/shared/types/window.d.ts`. Update all
import paths. Then port the remaining 42 files from NGA.

**After porting**: Delete `src/types.ts` and `src/types/` directory.

**Known issue**: UF's existing code imports types from scattered locations
(provider types.ts files, inline interfaces). These imports will break.
Fix them as you go -- redirect to `@/shared/types/`.

**Reconciliation required (6 naming collisions)**:

This is NOT a clean copy. UF has existing types that collide with NGA's:

| Name | UF | NGA | Resolution |
|------|-----|-----|-----------|
| `User` | Re-export of `firebase/auth` User | App domain entity (uid, name, email, role, teamData) | Namespace Firebase's as `FirebaseUser` (`import { User as FirebaseUser } from 'firebase/auth'`). NGA's `User` becomes the canonical app type. |
| `Role` | TypeScript `enum` | `as const` + union (same values) | Replace UF's enum with NGA's `as const` pattern. Update all `Role.ADMIN` usages (syntax is identical). |
| `Environment` | 4 values (includes `LOCAL`) | 3 values (no `LOCAL`) | Keep UF's `LOCAL` value -- add it to NGA's definition. |
| `FirebaseTenantConfig` | Defined locally | Defined in `auth.ts` | Use NGA's centralized version. Delete UF's local copy. |
| `RuleOption<T>` | Defined locally | Defined in shared types | Use NGA's. Delete UF's. |
| `Team`, `UserTeamData` | Raw `number` for IDs | Branded `TeamId`/`UserId` | Adopt NGA's branded types. Wrap existing number literals with branded constructors. |

**Scope**: ~50 existing UF files need import path updates after this step.
This is the heaviest sub-step in Phase 1. Budget accordingly.

#### 1.1b: Port shared utils

```
src/shared/utils/typedStorage.ts + typedStorage.spec.ts
src/shared/utils/queryParams.ts + queryParams.spec.ts
src/shared/utils/map.ts + map.spec.ts
src/shared/utils/metadata.ts + metadata.spec.ts
src/shared/utils/time/formatSecondsHMS.ts + spec
src/shared/utils/date/getStartEndTimes/ (directory)
```

~10 files. These may conflict with UF's existing utils. Check for
duplicates and remove UF's versions if NGA's are more complete.

#### 1.1c: Port shared navigation + cleanup-registry

```
src/shared/navigation/getDashboardTabs.ts
src/shared/navigation/getSettingsTabs.ts
src/shared/navigation/index.ts
src/shared/navigation/types.ts
src/shared/cleanup-registry.ts
```

Skip `src/shared/lib/supabase.ts` -- NGA-only.

#### 1.1d: Port shared hooks (5 new)

```
src/shared/hooks/useContainerSize/
src/shared/hooks/useCountdown/
src/shared/hooks/useEscapeKey/
src/shared/hooks/useFilterCollapse/
src/shared/hooks/useHydrated/
```

#### 1.1e: Port shared UI components (5 new)

```
src/shared/ui/ActivityTypeBadge/
src/shared/ui/FilterSection.tsx
src/shared/ui/FloatingGlossaryHelp/
src/shared/ui/MetadataDetailsContent.tsx
src/shared/ui/Spinner/
```

#### 1.1f: Assess + port src/ui/utils/

**UF does not have `src/ui/utils/companyData/`.** These are NGA-created
mappers for company data processing. Port only if the mock handler or UI
components actually import them. Check with:
```bash
grep -rn "from.*ui/utils/companyData\|from.*@/utils/companyData" \
  ~/github/next-gen-atlassian/src/pages/api/mock/ \
  ~/github/next-gen-atlassian/src/ui/page_blocks/
```

```
src/ui/utils/companyData/  (10 files -- port only if imported)
src/ui/utils/anonymizeData.ts
```

#### 1.1g: Port src/ui/constants/testIds.ts

```
src/ui/constants/testIds.ts  (123 lines)
src/ui/constants/index.ts
```

Also consolidate `src/ui/constants.ts` (if it exists in UF) into the
`src/ui/constants/` directory.

#### 1.1h: Assess companyContext + port app.tsx

**UF has no multi-company support.** There is no `selectedCompany` in storage,
no company switching UI, no CompanySwitchModal. The company name is a field
on the auth user (`company: string` in auth types).

NGA's `CompanyScopeProvider` manages company switching between multiple
companies -- UF doesn't need this. Options:
- **Simplest**: Create a thin `useCompanyScope` hook that reads `company`
  from the auth state. No provider needed.
- **If NGA code imports `useCompanyScope` widely**: Port a minimal
  CompanyScopeProvider that wraps the auth company field, so downstream
  code doesn't need to change.

Assess which approach causes fewer import changes, then implement.

```
src/ui/providers/context/app.tsx  (port this regardless)
```

#### 1.1i: Replace shared/mocks/ with shared/test-utils/

Port all 13 files from NGA's `src/shared/test-utils/`:
```
asBoundaryInput.ts
createMinimalTableRow.ts
getFetchMock.ts
index.ts
mockCompanyScope.ts
mockFilterCollapse.ts
mockFilterStore.ts
mockLoadTeamsQuery.ts
mockLocalStorage.ts
mockSelectedWorkstreams.ts
mockWorkstreamsQuery.ts
nextRouterMocks.ts
posthog-mock.ts
```

Then delete UF's `src/shared/mocks/` (7 files):
```
index.ts, localStorage.ts, nextRouterMocks.ts, posthog-mock.ts,
queryClientMocks.ts, react-query.ts, urlsRegistryMocks.ts
```

Update `vitest.setup.ts` imports from `shared/mocks/` to `shared/test-utils/`.

**DST fix**: Port the timezone computation fix from NGA (defer to call time,
not module load). This was commit `a29c7a16` in NGA.

**Checkpoint 1.1 exit criteria**:
```bash
pnpm tsc --noEmit    # passes with new types + shared infra
pnpm test            # passes (fix import path breakage from moves)
```

If tsc fails here, the type system has a structural mismatch between NGA's
domain model and UF's existing code. Fix before proceeding -- do not push
through to 1.2 with type errors.

---

### Sub-phase 1.2: Fixture System + Mock Handler + fetchApi

#### 1.2a: Install new dependencies

```
pnpm add @faker-js/faker nuqs reactflow react-markdown remark-gfm \
  @heroicons/react papaparse @vercel/analytics
pnpm add -D @types/papaparse
```

#### 1.2b: Port src/fixtures/ (19 files)

Port in dependency order:
1. `brand.ts` (no deps)
2. `identity-pool.ts` (brand)
3. Domain fixtures (15 files) in order: auth, teams, bpo-projects, users,
   company, events, spans, microworkflows, systems, workstream-data,
   productivity, realtime, relay, url-classification, operational-hours
4. `scenario.ts` (all domains)
5. `index.ts` (barrel)

NGA fixtures are already audited and verified:
- scenario.ts has BPO/projects wired in
- operational-hours uses consecutive dates
- productivity has grouped-response builder and TTM multi-day builder
- Known weakness: user groupAssignments always empty (byProject/byBpo hit faker fallback)

#### 1.2c: Port mock handler (1 file)

Port `src/pages/api/mock/[...endpoint].ts` from NGA. This is the ONLY
API route handler to port. It is dev-only (`output: 'export'` means no
API routes in the production build).

Do NOT port the 35 real API route handlers. UF talks to UB directly.

#### 1.2d: Port + configure fetchApi

Port `src/shared/lib/fetchApi/fetchApi.ts` from NGA. Configure:
- Production: base URL = UB (user-backend)
- Local mode (`NEXT_PUBLIC_LOCAL=true`): base URL = mock handler

This is the single point of contact for all data fetching. When UB is
eventually ported into UF, the UB handlers become `pages/api/` routes
and fetchApi just changes its base URL.

**UB-specific configuration (differs from NGA)**:

NGA's fetchApi had an `isInternalApiRoute` check and `getInternalApiHost()`
for routing to internal Next.js API routes. UF does not need either of
these -- UF has no internal API routes in production. Instead:

- `baseUrl`: read from `NEXT_PUBLIC_API_URL` env var (points to UB)
- Auth token: attach Firebase ID token via `Authorization: Bearer <token>`
  header. NGA did this too, but UF must verify the token refresh flow
  works correctly with UB's expected auth scheme.
- `fallbackOn404`: likely not needed. NGA used this for graceful degradation
  when company data was missing. UB should return proper error responses.
- Local mode override: when `NEXT_PUBLIC_LOCAL=true`, ignore `baseUrl` and
  route all requests to `/api/mock/` on localhost. The mock handler serves
  fixture data.
- `schema` parameter: still required (Zod validation at trust boundary).
  Port as-is from NGA.

#### 1.2e: Assess and port src/server/ (~12 files)

These are NOT API route handlers. They are pure data processing modules
that the mock handler imports to read/process company data from disk.
In NGA, the mock handler uses `src/server/companyData/` to read status.json
and serve fixture data. In UF production, these never run -- UF talks to
UB directly. They only execute during `NEXT_PUBLIC_LOCAL=true pnpm dev`.

Directories:
- `companyData/` -- reads uploaded company data from disk (status.json, events, spans)
- `relayUsage/` -- processes relay usage data
- `workstream-analysis/` -- processes workstream analysis data

The monoliths were already decomposed in NGA:
- executiveSummaryDataProcessor (467L -> 13 sub-functions + 37 tests)
- processMining.ts (654L -> 3 modules + 25 tests)
- analyzerDataset (858L -> 5 modules + 46 tests)

**Assess before porting blindly.** The mock handler in NGA serves most data
from `buildStandardScenario()` without touching disk (proven during this
session's bug bash). Only port the files the mock handler actually imports.
Check with:
```bash
grep -rn "from '@/root/src/server\|from '@/server\|from '.*server/" \
  ~/github/next-gen-atlassian/src/pages/api/mock/
```
If the mock handler only imports `companyDataStorage` for disk reads, and
those disk reads are bypassed by `NEXT_PUBLIC_LOCAL` early returns, then
most of `src/server/` may not be needed at all in UF.

#### 1.2f: ~~Port data/companies/~~ -- SKIP

**UF does not need this directory.** It held disk-based company data for
NGA's upload flow (status.json, events.json, etc.). UF talks to UB
directly and the mock handler serves from `buildStandardScenario()`.
No disk reads needed.

**Checkpoint 1.2 exit criteria**:
```bash
pnpm tsc --noEmit                    # passes
pnpm build                           # passes
NEXT_PUBLIC_LOCAL=true pnpm dev      # serves pages
```
Manually verify: navigate to /users, /teams, /settings/bpos in the browser.
Data loads from mock handler. No 404s in devtools Network tab.

This is the first time the full system is running end-to-end. If pages
don't load, debug now -- do not proceed to Phase 2 with a broken mock layer.

---

### Sub-phase 1.3: Documentation

#### 1.3: Port docs/ (7 files)

```
cp -r ~/github/next-gen-atlassian/docs ~/github/user-frontend/docs
```

Files (skip `ai-chat-setup.md` -- NGA's Anthropic SDK backend, not applicable):
- anonymization-reference.md
- optimization-summary.md
- process-mining-tree-layout.md
- span-migration-instructions.md
- sql-materialized-views.md
- sql-migration-steps.md

After copying, grep each file for NGA-specific paths (`src/pages/api/`,
`src/server/`, `../src/`, port numbers) and update for UF's structure.

---

## Source Directory Cleanup (do during sub-phase 1.1)

| Item | Action |
|------|--------|
| `src/types.ts` | Move to `src/shared/types/common.ts` (part of 1.1a) |
| `src/types/` | Move `window.d.ts` to `src/shared/types/`, delete dir (part of 1.1a) |
| `src/tests/` | Move to co-located .spec files (part of 1.1i or defer to Phase 7) |
| `src/ui/constants.ts` | Consolidate into `src/ui/constants/` dir (part of 1.1g) |

## Dead Code Deletion (do during sub-phase 1.0)

NGA deleted ~8,500 lines of dead code in its first commit. UF likely has
the same dead code. Run a dead code audit after config is aligned:

- Delete dead CompanySwitchModal (1,537 lines if still present)
- Delete standalone executive dashboard prototype (if present)
- Delete dead `src/components/` directory (already confirmed absent)
- Delete dead `shared/mockData/` directory (if present)
- Remove `lint-staged` from devDeps (not used, husky invokes directly)

## Post-Port Skill Verification

Phase 1 is mostly porting from a clean codebase, so build/refactor skills
are not the primary tool. But use these after porting to verify:

- `/audit-api-handler` on the mock handler after 1.2c (verify schema, error handling)
- `/audit-module` on each `src/server/` module after 1.2e (verify G1-G10)
- `/audit-module` on `fetchApi.ts` after 1.2d (verify G1-G10)
- `/build-fixture` if any new UF-specific fixture domains are needed beyond the 15 ported
- `/audit-npm-deps` after 1.2a to verify no dead/misplaced deps

## Verification Checklist

After all sub-phases complete:

```bash
pnpm tsc --noEmit           # 0 errors
pnpm build                   # clean
pnpm test                    # no new failures vs. baseline
NEXT_PUBLIC_LOCAL=true pnpm dev  # serves pages, no 404s in console
```

Manually verify:
- Navigate to /users, /teams, /settings/bpos -- data loads from mock handler
- Navigate to /insights/analysis/systems -- filter bar renders
- Open browser devtools Network tab -- all API calls return 200 in local mode
