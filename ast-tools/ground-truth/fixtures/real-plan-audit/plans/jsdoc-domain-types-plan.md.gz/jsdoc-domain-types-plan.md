# Plan: Domain-Semantic JSDoc on shared/types/

## Goal

Add JSDoc to `src/shared/types/` where the TypeScript signature alone does not
convey business meaning. Not comprehensive documentation -- targeted annotations
on fields, interfaces, and types whose domain semantics are non-obvious.

## Scope

**In scope (28 files):**

All non-schema, non-test, non-declaration type files in `src/shared/types/`:

- `analyzer.ts`, `analyzerActivity.ts`
- `api.ts`
- `auth.ts`
- `bpo-projects.ts`
- `brand.ts`
- `chat.ts`
- `common.ts`
- `company.ts`
- `discoverFilterState.ts`
- `elementAttributes.ts`
- `events.ts`
- `filterFormStates.ts`
- `insightsFilters.ts`
- `microworkflows.ts`
- `operationalHoursData.ts`
- `productivity.ts`
- `realtime.ts`
- `relay.ts`
- `spans.ts`
- `systems.ts`
- `table.ts`
- `teams.ts`
- `ui.ts`
- `url-classification.ts`
- `users.ts`
- `workstreamData.ts`
- `workstreamQueryParams.ts`

**Out of scope:**

- `*.schema.ts` (16 files) -- Zod schemas are self-documenting
- `*.spec.ts` (2 files) -- test files
- `window.d.ts` -- declaration file
- `index.ts` -- barrel file

## Approach

For each file, read the types/interfaces and ask:

1. **Would a developer unfamiliar with the 8flow domain understand what this
   field means from the type signature alone?** If not, add a JSDoc comment
   explaining the domain semantics.

2. **Are there fields with generic types (string, number, boolean) that carry
   specific business meaning?** These are the primary candidates. A field
   `lastSeen: string` needs `/** ISO 8601 timestamp of the relay's last
   heartbeat, in UTC. */`. A field `name: string` does not.

3. **Are there interfaces that represent API response shapes, aggregation
   buckets, or computed metrics?** These benefit from a top-level JSDoc
   explaining what the shape represents and where it comes from.

4. **Are there union types, enums, or branded types whose values carry
   domain-specific meaning?** Document what the values mean in business terms.

### What NOT to add

- Do not document self-evident fields (`id: string`, `name: string`,
  `createdAt: ISOTimestamp`)
- Do not restate the type (`/** A string */` on a string field)
- Do not add JSDoc to every interface -- only where the name + field names
  are insufficient
- Do not document internal/private types that are only used in one place
  and are obvious in context
- Branded types that already have clear names (`ISOTimestamp`, `UserId`)
  do not need JSDoc unless the branding rules are non-obvious

## Verification

- `pnpm tsc --noEmit` -- must pass (JSDoc should never break types)
- `pnpm test --run` -- must pass
- Spot-check: no D2/D11 comments created (no restating the code, no
  redundant type narration)

## Prompt

Single prompt: `prompts/jsdoc-domain-types-01.md`

## Estimated scope

Low-to-moderate. Many files will need zero or minimal JSDoc. The
domain-heavy files (systems, relay, productivity, microworkflows,
operationalHoursData, analyzer) will need the most.
