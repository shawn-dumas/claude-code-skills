# BFF Audit Fix Plan v2

> Created: 2026-03-13
> Track: BFF + non-BFF (Keith's kb/bff-fixes merge)
> Branch: sd/bff-handler-refactor-v2
> Base: sd/productionize (post kb/bff-fixes merge)
> Source audit: inline (AST sweep + agent audit, this session)
> Status: ALL PROMPTS PASS -- cleanup + PR in continuation prompt
> Integration scope: per-prompt
> Cleanup file: ~/plans/bff-audit-fix-v2-26-03-13-cleanup.md

## Audit Summary

25 BFF handlers scanned. 9 functions in 9 files exceed CC=10.
2 type safety violations (non-null assertions in workstreams.ts).
All v1 structural issues (schema extraction, resolveRole duplication,
buildTenantWithProviders, mock drift, test P8) confirmed still present.
3 new Keith routes (activity-timeline, workstreams, systems/overview) all
have CC > 10. 14 non-BFF files scanned: 1 FAIL, 5 WARN, 9 CLEAN.

### Complexity hotspots

| File                   | Function        |  CC | Source               |
| ---------------------- | --------------- | --: | -------------------- |
| `user-data.ts`         | `handler`       |  22 | v1 (Keith reverted)  |
| `activity-timeline.ts` | `transformRows` |  21 | NEW (Keith)          |
| `auth/roles.ts`        | `handler`       |  20 | v1 (Keith reverted)  |
| `workstreams.ts`       | `handler`       |  16 | NEW (Keith)          |
| `create-bulk.ts`       | `handler`       |  16 | Existing (not in v1) |
| `update.ts`            | `handler`       |  14 | v1 (Keith reverted)  |
| `systems/overview.ts`  | `handler`       |  13 | NEW (Keith)          |
| `getDayStats.ts`       | `handler`       |  12 | v1 (Keith reverted)  |
| `getTtmForDays.ts`     | `handler`       |  10 | v1 (Keith reverted)  |

### Type safety violations

| File                            | Type                  | Line     |
| ------------------------------- | --------------------- | -------- |
| `workstreams.ts`                | NON_NULL_ASSERTION    | 131, 132 |
| `useTTMForDaysTableColumns.tsx` | AS cast (`as string`) | 35       |

### Structural issues (all from v1, all still present)

- Inline schemas in groups (5 handlers) and teams (4 handlers)
- `resolveRole` duplication in `user-info.ts`
- `buildTenantWithProviders` exported from `tenant/getByEmail.ts`
- Mock `teams/remove.ts` hard-deletes (splice) vs production soft-delete
- 2 test P8 violations in `fetchUserProfiles.spec.ts`, `resolveTeamIdsToUids.spec.ts`

## Dependencies

- P01 must complete before P02 (P01 touches user-data.ts, auth/roles.ts,
  update.ts; P02 also touches sibling handlers)
- P03 is independent of P01/P02

## Prompt Sequence

| #   | File                              | Category     | Concern | Fixes | Est. Commits |
| --- | --------------------------------- | ------------ | ------- | ----- | ------------ |
| P01 | bff-v2-P01-architecture-high.md   | Architecture | High    | 6     | 6            |
| P02 | bff-v2-P02-architecture-medium.md | Architecture | Medium  | 8     | 7            |
| P03 | bff-v2-P03-non-bff-fixes.md       | Code quality | Low     | 4     | 2            |

## Verification Commands

```bash
pnpm tsc --noEmit
pnpm build
pnpm test --run
pnpm test:integration
npx eslint . --max-warnings 0
```

## Verification Checklist

| #   | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
| --- | ------------- | -------------------- | -------------- | --------- |
| P01 | Yes (207p/1f) | Yes (207p/1f)        | Yes            | PASS      |
| P02 | Yes (207p/1f) | Yes (207p/1f)        | Yes            | PASS      |
| P03 | N/A           | N/A                  | N/A            | PASS      |

## Progress

| #   | Status | HEAD     | Notes                                                           |
| --- | ------ | -------- | --------------------------------------------------------------- |
| P01 | PASS   | 9b32ee4b | 5 commits, all CC <= 5, 0 type violations                       |
| P02 | PASS   | 0dc76db7 | 7 commits, all CC <= 7, 0 inline schemas, structural fixes done |
| P03 | PASS   | d5feb789 | 2 commits, Fix 3 skipped (false positive), 0 type violations    |
