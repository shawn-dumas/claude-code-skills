# Backlog: Post-Audit Cleanup

> Created: 2026-03-05
> Branch: sd/productionize
> HEAD at start: ba8cc6e5

## Items

| # | Item | Type | Files | Effort | Prompt | Status |
|---|------|------|-------|--------|--------|--------|
| B1 | Wire New Relic error reporting via QueryCache/MutationCache (v5 pattern) | bug fix | 2 | small | 01 | done |
| B2 | Make buildMutationMock generic, eliminate 15 mutation double casts | test improvement | ~6 | medium | 02 | done |
| B3 | Add buildRouterMock helper, eliminate 2 router double casts | test improvement | ~3 | small | 02 | done |
| B4 | Add useChatApi unit spec | test improvement | 1 (new) | medium | 03 | done |

## Dependency Graph

```
Prompt 1 (independent -- production wiring)
Prompt 2 (independent -- test infrastructure)
Prompt 3 (independent -- new test file)
```

All three are independent. No shared files, no ordering constraints.
Prompt 2 groups B2 and B3 because they are the same work type (mock helper
improvement) in the same file (`react-query.ts` / new `router-mock.ts`).

## Prompt Sequence

| # | Prompt | Items | Prerequisite | Status |
|---|--------|-------|-------------|--------|
| 1 | newrelic-querycache | B1 | none | done |
| 2 | mock-helpers | B2, B3 | none | done |
| 3 | usechatapi-spec | B4 | none | done |
