# Git Protocol Hardening for PM Agent Sessions

You are a work agent. Execute this prompt exactly. Read
`~/github/user-frontend/CLAUDE.md` before starting any work.

## Context

Non-engineering product managers use Claude Code agents to build PoC
features via the `orchestrate-poc`, `iterate-poc`, and
`generate-handoff-tickets` skills. The code-level defenses are strong
(41 skills, DDAU architecture, pre-commit hooks for prettier + ESLint +
tsc, Zod at boundaries, branded types). But the git layer is
unmanaged -- no commit message convention, no branch naming standard, no
merge strategy, no traceability from commits to PoC/PRD artifacts.

Engineers reviewing a PoC PR currently see a flat list of commits with
no way to identify which commits implement the feature vs. iterations
vs. side-quest bug discoveries, and no way to filter by architectural
layer.

This prompt creates a git protocol for PM agent sessions and embeds it
in the skills and docs that govern those sessions. **Engineers working
on non-poc branches are not affected at all** -- the protocol only
activates on `poc/*` branches.

## What you are creating/modifying

### New files (2)

1. `~/github/user-frontend/docs/git-protocol.md`
2. `~/github/user-frontend/.husky/commit-msg`

### Modified files (12)

Skills exist as **separate copies** (not symlinks) in two locations:
`~/github/user-frontend/.claude/skills/` and `~/.claude/skills/`. Both
must be edited identically. The edits below specify the project path;
after each skill edit, copy the identical change to the personal path.

3. `~/github/user-frontend/CLAUDE.md`
4. `~/github/user-frontend/docs/poc-pipeline.md`
5. `~/github/user-frontend/.github/PULL_REQUEST_TEMPLATE.md`
6. `~/github/user-frontend/.claude/skills/orchestrate-poc/SKILL.md`
   **AND** `~/.claude/skills/orchestrate-poc/SKILL.md` (identical edit)
7. `~/github/user-frontend/.claude/skills/iterate-poc/SKILL.md`
   **AND** `~/.claude/skills/iterate-poc/SKILL.md` (identical edit)
8. `~/github/user-frontend/.claude/skills/iterate-poc-prd/SKILL.md`
   **AND** `~/.claude/skills/iterate-poc-prd/SKILL.md` (identical edit)
9. `~/github/user-frontend/.claude/skills/generate-handoff-tickets/SKILL.md`
   **AND** `~/.claude/skills/generate-handoff-tickets/SKILL.md` (identical edit)
10. `~/.claude/CLAUDE.md`

---

## File 1: `~/github/user-frontend/docs/git-protocol.md` (NEW)

Create this file with the following content exactly:

````markdown
# Git Protocol for PoC Branches

Commit conventions, branch naming, merge strategy, and sync rules for
PoC feature branches operated by product team agents.

This protocol activates only on branches matching `poc/*`. Engineers
working on other branches are not affected.

## Branch Naming

```
poc/<slug>/<pm-initials>
```

- `<slug>` matches the PRD filename: `poc-<slug>.md` (or
  `poc-<slug>-prd.md`).
- `<pm-initials>` are the PM's lowercase initials (2-3 chars).
- Examples: `poc/team-utilization/jd`, `poc/system-health/ms`.

The `poc/` prefix is parseable by CI, scripts, and eng tooling. All PoC
work happens on a single branch per feature -- iterations do not create
sub-branches. The `Phase` and `Prompt` trailers in commit messages
distinguish original build from iterations.

## Commit Message Format

Every commit on a `poc/*` branch must follow this format:

```
<type>(<scope>): <subject>

[body]

PoC: <slug>
PRD: ~/plans/poc-<slug>.md
Phase: <phase identifier>
Prompt: <prompt filename or "manual">
Components: <comma-separated list>
[Side-quest: <description>]
```

### Type (required)

One of:

| Type | Use when |
|------|----------|
| `feat` | New functionality from the PRD |
| `fix` | Bug fix (in-PoC or side-quest discovery) |
| `refactor` | Restructuring without behavior change |
| `test` | Test additions or changes |
| `chore` | Wiring, config, feature flags, navigation plumbing |
| `docs` | PRD updates, doc changes |

### Scope (required)

The `page_blocks` domain name or system area. Examples:
`team-utilization`, `usage`, `fixtures`, `types`, `mock-routes`,
`navigation`, `feature-flags`.

### Subject (required)

Imperative mood, lowercase, no period. Max 72 characters.

### Body (optional but encouraged)

What was done and why. Reference specific FRs from the PRD when
implementing requirements (e.g., "Implements FR-1 and FR-2").

### Trailers (required on `poc/*` branches)

| Trailer | Required | Description |
|---------|----------|-------------|
| `PoC` | Yes | The feature slug (e.g., `team-utilization`) |
| `PRD` | Yes | Path to PRD file (e.g., `~/plans/poc-team-utilization.md`) |
| `Phase` | Yes | Orchestration phase (e.g., `1-types`, `6-components`, `iteration`, `cleanup`) |
| `Prompt` | Yes | Prompt filename (e.g., `poc-team-utilization-06-components.md`) or `manual` for hand-driven changes |
| `Components` | Yes | Comma-separated list from the vocabulary below |
| `Side-quest` | Conditional | Required when the commit introduces a `TODO(production-bug)` comment or appends an out-of-scope item to the cleanup file |

### Component Vocabulary

Use only these values in the `Components` trailer:

`types`, `schemas`, `fixtures`, `mock-routes`, `service-hooks`,
`container`, `components`, `page-file`, `navigation`, `feature-flags`,
`tests`, `providers`, `wiring`, `docs`

Multiple values are comma-separated: `Components: container, components, tests`

### Side-quest Trailer

Present only when the commit introduces a `TODO(production-bug)` comment
or discovers an issue outside the PoC's scope. Format:

```
Side-quest: <short description of the discovered issue and where the TODO comment lives>
```

### Examples

**Feature commit:**

```
feat(team-utilization): add utilization table with sortable columns

Implements FR-1 and FR-2 from the PRD. Table displays per-user
utilization rates with active time, idle time, and utilization
percentage columns. Sortable by all numeric columns.

PoC: team-utilization
PRD: ~/plans/poc-team-utilization.md
Phase: 6-components
Prompt: poc-team-utilization-06-components.md
Components: container, components, tests
```

**Side-quest commit:**

```
fix(team-utilization): guard against null shiftDuration in utilization calc

Division by zero when shiftDuration is null produces NaN in the
utilization column. Added a guard that displays a dash instead.

PoC: team-utilization
PRD: ~/plans/poc-team-utilization.md
Phase: iteration
Prompt: poc-team-utilization-iter-01-bugfix.md
Components: container, components
Side-quest: CompanySpan.shiftDuration is nullable but the type says required -- see TODO(production-bug) in src/shared/types/productivity.ts
```

**Docs-only commit:**

```
docs(team-utilization): update PRD with stakeholder feedback on column labels

PoC: team-utilization
PRD: ~/plans/poc-team-utilization.md
Phase: iteration
Prompt: manual
Components: docs
```

## Merge Strategy

### PoC PR into development: squash-merge

When a PoC feature PR lands in `development`, it is **squash-merged**.
The squash commit message uses this template:

```
feat(<slug>): [PoC] <Feature name> (#<PR number>)

PoC-to-development squash merge.

PRD: ~/plans/poc-<slug>.md
Epic: AV-XXXX
Feature Flag: <flag name>
PM: <full name>
Agent Sessions: <N> commits over <N> days

Components touched: <aggregated list from all commits>

Side-quests discovered: <N>
  - <description> (file:line)
  - <description> (file:line)
```

Individual commit history is preserved in the PR on GitHub. The
`development` branch gets one clean commit per feature.

### Why squash, not fast-forward

Fast-forward requires the PM's agent to rebase before merge. Rebasing a
PoC branch with 20-40 commits against a moving `development` branch is
a conflict minefield for an agent operated by a non-engineer.
Squash-merge sidesteps this -- the PM's branch never needs to be
rebased.

## Syncing with Development

PM agents must merge `development` into the PoC branch (never rebase)
at these points:

- Before starting a new `iterate-poc` session
- Before running `generate-handoff-tickets`
- Weekly, if the PoC is long-lived (>2 weeks)

Merge preserves the PoC's commit history and creates an explicit merge
commit showing when the sync happened.

```bash
git fetch origin development
git merge origin/development --no-edit
```

**If there are merge conflicts, stop and escalate.** Do not attempt to
resolve merge conflicts automatically. Tell the PM:

> Merge conflicts detected when syncing with development. This needs
> engineering help. Do not proceed until the conflicts are resolved by
> an engineer.

## Engineering Escape Hatch

Engineers working on `poc/*` branches (during review, hotfix) can bypass
the commit-msg validation:

```bash
GIT_PROTOCOL=skip git commit -m "fix: whatever"
```

This skips the PoC trailer validation only. The pre-commit hook
(prettier, ESLint, tsc) still runs. `--no-verify` is prohibited because
it also skips the pre-commit checks.

This escape hatch is not documented in CLAUDE.md, not in any skill, and
not in any generated prompt. PM agents do not know it exists.

## Querying the History

Engineers can filter PoC commits by trailer:

```bash
# All commits for a PoC
git log --grep="PoC: team-utilization"

# All container changes across PoCs
git log --grep="Components:.*container"

# All side-quest discoveries
git log --grep="Side-quest:"

# All commits from a specific prompt
git log --grep="Prompt: poc-team-utilization-06"
```
````

---

## File 2: `~/github/user-frontend/.husky/commit-msg` (NEW)

Create this file and make it executable (`chmod +x`).

Read the existing `.husky/pre-commit` file first to match the script
style (it is a plain shell script, no Husky v4 `npx` wrapper).

Create the following script:

```bash
#!/usr/bin/env bash

# Commit message validation for PoC branches.
# On poc/* branches: enforces structured commit messages with trailers.
# On all other branches: no validation (engineers are left alone).

BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")

# Only enforce on poc/* branches
case "$BRANCH" in
  poc/*) ;;
  *) exit 0 ;;
esac

# Engineering escape hatch (undocumented -- not in CLAUDE.md or skills)
if [ "$GIT_PROTOCOL" = "skip" ]; then
  exit 0
fi

MSG_FILE="$1"
MSG=$(cat "$MSG_FILE")

ERRORS=""

# --- Type prefix ---
# Must start with one of: feat|fix|refactor|test|chore|docs followed by (scope):
if ! echo "$MSG" | head -1 | grep -qE '^(feat|fix|refactor|test|chore|docs)\([a-z0-9-]+\): .+'; then
  ERRORS="${ERRORS}\n  - First line must match: <type>(<scope>): <subject>"
  ERRORS="${ERRORS}\n    Types: feat, fix, refactor, test, chore, docs"
  ERRORS="${ERRORS}\n    Example: feat(team-utilization): add sortable columns"
fi

# --- Subject length ---
SUBJECT=$(echo "$MSG" | head -1)
if [ ${#SUBJECT} -gt 72 ]; then
  ERRORS="${ERRORS}\n  - Subject line exceeds 72 characters (${#SUBJECT} chars)"
fi

# --- PoC trailer ---
if ! echo "$MSG" | grep -qE '^PoC: [a-z0-9-]+$'; then
  ERRORS="${ERRORS}\n  - Missing 'PoC: <slug>' trailer"
fi

# --- PRD trailer ---
if ! echo "$MSG" | grep -qE '^PRD: '; then
  ERRORS="${ERRORS}\n  - Missing 'PRD: <path>' trailer"
fi

# --- Phase trailer ---
if ! echo "$MSG" | grep -qE '^Phase: '; then
  ERRORS="${ERRORS}\n  - Missing 'Phase: <phase>' trailer"
fi

# --- Prompt trailer ---
if ! echo "$MSG" | grep -qE '^Prompt: '; then
  ERRORS="${ERRORS}\n  - Missing 'Prompt: <filename or manual>' trailer"
fi

# --- Components trailer ---
VALID_COMPONENTS="types|schemas|fixtures|mock-routes|service-hooks|container|components|page-file|navigation|feature-flags|tests|providers|wiring|docs"
if ! echo "$MSG" | grep -qE '^Components: '; then
  ERRORS="${ERRORS}\n  - Missing 'Components: <list>' trailer"
else
  # Validate each component value
  COMP_LINE=$(echo "$MSG" | grep -E '^Components: ')
  COMP_VALUES=$(echo "$COMP_LINE" | sed 's/^Components: //' | tr ',' '\n' | sed 's/^ *//;s/ *$//')
  while IFS= read -r comp; do
    if [ -n "$comp" ] && ! echo "$comp" | grep -qE "^(${VALID_COMPONENTS})$"; then
      ERRORS="${ERRORS}\n  - Invalid component '${comp}' in Components trailer"
      ERRORS="${ERRORS}\n    Valid: types, schemas, fixtures, mock-routes, service-hooks,"
      ERRORS="${ERRORS}\n    container, components, page-file, navigation, feature-flags,"
      ERRORS="${ERRORS}\n    tests, providers, wiring, docs"
    fi
  done <<< "$COMP_VALUES"
fi

# --- Side-quest trailer (conditional) ---
# Check if staged diff contains TODO(production-bug)
if git diff --cached --diff-filter=ACM -U0 2>/dev/null | grep -q 'TODO(production-bug)'; then
  if ! echo "$MSG" | grep -qE '^Side-quest: '; then
    ERRORS="${ERRORS}\n  - Staged changes contain TODO(production-bug) but commit is missing 'Side-quest: <description>' trailer"
  fi
fi

# --- Report ---
if [ -n "$ERRORS" ]; then
  echo ""
  echo "Commit message rejected (poc/* branch protocol):"
  echo -e "$ERRORS"
  echo ""
  echo "See docs/git-protocol.md for the full format specification."
  echo ""
  exit 1
fi

exit 0
```

After creating the file, run: `chmod +x ~/github/user-frontend/.husky/commit-msg`

---

## File 3: `~/github/user-frontend/CLAUDE.md` (MODIFY)

Make two edits to this file.

### Edit 3a: Add to Gotchas section

Find the existing Gotchas section. After the line:

```
- Never use `--no-verify` on git commit. It skips prettier, ESLint, AND
  tsc.
```

Insert:

```
- **PoC branch commit protocol.** On `poc/*` branches, the `commit-msg`
  hook enforces structured commit messages with PoC, PRD, Phase, Prompt,
  and Components trailers. See `docs/git-protocol.md` for the full
  format. Engineers on non-poc branches are not affected.
```

### Edit 3b: Add to Further Reading section

Find the Further Reading section. After the line:

```
- `docs/poc-pipeline.md` -- PoC-to-production pipeline, data layer strategy, pre-sales workflow
```

Insert:

```
- `docs/git-protocol.md` -- commit message format, branch naming, merge strategy for PoC branches
```

---

## File 4: `~/github/user-frontend/docs/poc-pipeline.md` (MODIFY)

Make three edits to this file.

### Edit 4a: Update PoC Environments section

Find the section starting with:

```
### PoC Environments

When a new PoC environment is needed, the product team opens a ticket.
DevOps and data teams provision:

- A `poc/<name>` branch in the dashboard repo based on production
```

Replace the paragraph starting with "Recommended (not required)" through
the end of "to prevent drift from the generally available dashboard."
with:

```
The product team creates feature work branches named
`poc/<slug>/<pm-initials>` off the `poc/<name>` environment branch.
Branch naming must follow the convention in `docs/git-protocol.md`:
`<slug>` matches the PRD filename, `<pm-initials>` are the PM's
lowercase initials.

The product team must periodically merge the production branch back into
`poc/<name>` to prevent drift. Sync cadence:

- Before starting a new `iterate-poc` session
- Before running `generate-handoff-tickets`
- Weekly, if the PoC is long-lived (>2 weeks)

Always merge, never rebase. If merge conflicts arise, escalate to
engineering. See `docs/git-protocol.md` for the full sync protocol.
```

### Edit 4b: Update Phase 2: Handoff section

Find step 2 under Phase 2: Handoff:

```
2. PM opens a draft PR containing the single feature (nothing else)
```

Replace that single line with:

```
2. PM opens a draft PR containing the single feature (nothing else).
   The PR description follows the PoC handoff template (see
   `.github/PULL_REQUEST_TEMPLATE.md`). `generate-handoff-tickets`
   produces the squash-merge commit template and commit summary table
   for the PR body.
```

### Edit 4c: Add to Related Documentation section

Find the Related Documentation section at the end. Add this line after
the existing entries:

```
- `docs/git-protocol.md` -- commit message format, branch naming, merge strategy for PoC branches
```

---

## File 5: `~/github/user-frontend/.github/PULL_REQUEST_TEMPLATE.md` (MODIFY)

Replace the entire file content with:

```markdown
## Description

-
-

## Ticket

https://8flow.atlassian.net/browse/AV-XXXX

---

<!-- PoC Handoff section: fill in if this PR is from a poc/* branch.
     Delete this section for non-PoC PRs. -->

## PoC Handoff

**PRD:** ~/plans/poc-SLUG.md
**Epic:** AV-XXXX
**Feature Flag:** FLAG_NAME
**PM:** NAME
**Source Branch:** poc/SLUG/INITIALS

### Commit Summary

<!-- generate-handoff-tickets produces this table. Paste it here. -->

| Phase | Commits | Components |
|-------|---------|------------|
| 1-types | N | types, schemas, feature-flags |
| ... | ... | ... |

### Side-Quest Discoveries

<!-- List any TODO(production-bug) items introduced during PoC work. -->

- [ ] DESCRIPTION (file:line)

### Squash Merge Template

<!-- Paste the squash-merge commit message here. The engineer merging
     the PR copies this into the squash commit message field. -->

```
feat(SLUG): [PoC] FEATURE NAME (#PR)

PoC-to-development squash merge.

PRD: ~/plans/poc-SLUG.md
Epic: AV-XXXX
Feature Flag: FLAG_NAME
PM: NAME
Agent Sessions: N commits over N days

Components touched: LIST

Side-quests discovered: N
  - DESCRIPTION (file:line)
```
```

---

## File 6: `orchestrate-poc/SKILL.md` (MODIFY -- BOTH LOCATIONS)

Apply these edits to BOTH:
- `~/github/user-frontend/.claude/skills/orchestrate-poc/SKILL.md`
- `~/.claude/skills/orchestrate-poc/SKILL.md`

Make three edits to each copy.

### Edit 6a: Add branch creation to Phase 0

Find the section after Q0d (the "After Q0a-Q0d" paragraph):

```
**After Q0a-Q0d:** Create the working PRD and cleanup files (same as
Step 1 below), then proceed to Phase 0E (Spike Audit).
```

Insert BEFORE that paragraph (between Q0d's options block and the
"After Q0a-Q0d" line):

```
### Q0e: Branch Setup

For **Greenfield** PoCs, create the feature branch:

```
Question: What are your initials? (2-3 lowercase letters, used for branch naming)
Header: PM initials
```

Create the branch:
```bash
git checkout -b poc/<slug>/<initials>
```

Where `<slug>` is derived from the feature idea (lowercase,
hyphen-separated, e.g., "team utilization rates" becomes
`team-utilization`).

For **Existing spike** PoCs, verify the branch follows the naming
convention. If it does not (e.g., it is named `feature/team-util` or
`adam/team-thing`), ask:

```
Question: The current branch is named "<current>". PoC branches should
follow the convention poc/<slug>/<initials>. Should I rename it?
Header: Branch naming
Options:
  - "Rename" -- Rename the branch to follow the convention.
  - "Keep as-is" -- Leave the branch name. I will note the actual name in the PRD.
```

If "Rename": `git branch -m <old-name> poc/<slug>/<initials>`

Record the branch name in the PRD header's `Source Branch` field.
```

### Edit 6b: Add commit protocol to prompt generation rules

Find the section in Step 7.4 that lists the prompt generation rules.
The rules currently end with:

```
- Include the standard reconciliation block
```

After that line, add:

```
- **Commit protocol.** Every prompt must include a "Commit Protocol"
  section with the following text (fill in `<slug>` and `<phase>` for
  each prompt):

  > ## Commit Protocol
  >
  > You are on a `poc/*` branch. All commits must follow
  > `docs/git-protocol.md`. The commit-msg hook will reject
  > non-conforming messages. Use this format:
  >
  > ```
  > <type>(<scope>): <subject>
  >
  > [body]
  >
  > PoC: <slug>
  > PRD: ~/plans/poc-<slug>.md
  > Phase: <phase>
  > Prompt: <prompt-filename>
  > Components: <comma-separated from: types, schemas, fixtures,
  >   mock-routes, service-hooks, container, components, page-file,
  >   navigation, feature-flags, tests, providers, wiring, docs>
  > [Side-quest: <description>]  (only if you add a TODO(production-bug))
  > ```
  >
  > If a commit is rejected by the hook, read the error message, fix
  > the commit message, and retry. Do not use `--no-verify`.
```

### Edit 6c: Add commit format check to orchestrator loop

Find Step 8 (Execute the Orchestrator Loop), specifically the
independent verification commands:

```
    git log --oneline -10
    pnpm tsc --noEmit
```

Replace `git log --oneline -10` with:

```
    git log --oneline -10
    # Verify commit message format (last N commits from this prompt)
    git log -5 --format="%s%n%b" | grep -c "^PoC: " || echo "WARNING: recent commits missing PoC trailer"
```

---

## File 7: `iterate-poc/SKILL.md` (MODIFY -- BOTH LOCATIONS)

Apply these edits to BOTH:
- `~/github/user-frontend/.claude/skills/iterate-poc/SKILL.md`
- `~/.claude/skills/iterate-poc/SKILL.md`

Make two edits to each copy.

### Edit 7a: Add development sync check to Preconditions

Find precondition 3 (the branch checkout check). After the entire
precondition 3 block (ending with the Question options for branch
switching), add a new precondition:

```
4. **The branch is not behind development.** Check for divergence:
   ```bash
   git fetch origin development 2>/dev/null
   BEHIND=$(git rev-list --count HEAD..origin/development 2>/dev/null || echo "0")
   ```

   If `$BEHIND` is greater than 0, inform the PM:
   ```
   Question: Your branch is BEHIND commits behind development. Merging
   now to pick up recent changes before starting the iteration.
   Header: Sync with development
   Options:
     - "Merge now" -- Merge development into this branch before proceeding.
     - "Skip" -- Proceed without syncing. I understand the branch may be stale.
   ```

   If "Merge now": run `git merge origin/development --no-edit`. If
   there are merge conflicts, stop:
   > Merge conflicts detected when syncing with development. This needs
   > engineering help. Do not proceed until the conflicts are resolved.
```

### Edit 7b: Add commit protocol to prompt generation

Find Step 4.2 (Prompt Generation Rules). The section references
orchestrate-poc Step 7.4 for rules. After the line:

```
- **Reconciliation block** uses the standard format from
  `~/.claude/CLAUDE.md`.
```

Add:

```
- **Commit protocol.** Same as orchestrate-poc Step 7.4: every prompt
  includes a "Commit Protocol" section instructing the work agent to
  follow `docs/git-protocol.md`. Use `Phase: iteration` and the
  iteration prompt filename for the trailers.
```

---

## File 8: `iterate-poc-prd/SKILL.md` (MODIFY -- BOTH LOCATIONS)

Apply this edit to BOTH:
- `~/github/user-frontend/.claude/skills/iterate-poc-prd/SKILL.md`
- `~/.claude/skills/iterate-poc-prd/SKILL.md`

Find the "Scope Boundaries" section near the end. After the line:

```
- **Full PRD rewrites.** If the feedback is so extensive that more than
  half the PRD sections need rewriting, recommend re-running the
  relevant phases of `orchestrate-poc` instead.
```

Add:

```

### Commit Protocol for PRD-only Changes

This skill modifies documents, not code. If working on a `poc/*` branch
and the PRD edit requires a commit, use:

```
docs(<slug>): <subject describing the PRD change>

PoC: <slug>
PRD: ~/plans/poc-<slug>.md
Phase: iteration
Prompt: manual
Components: docs
```

The `commit-msg` hook on `poc/*` branches requires all trailers. PRD-only
changes use `Components: docs` and `Prompt: manual`.
```

---

## File 9: `generate-handoff-tickets/SKILL.md` (MODIFY -- BOTH LOCATIONS)

Apply this edit to BOTH:
- `~/github/user-frontend/.claude/skills/generate-handoff-tickets/SKILL.md`
- `~/.claude/skills/generate-handoff-tickets/SKILL.md`

Find Step 6 (Update the PRD). Insert a new Step 6.5 between Step 6 and
the Error Handling section:

```
## Step 6.5: Generate PR Artifacts

After updating the PRD, generate two artifacts the PM will need when
opening the handoff PR.

### 6.5.1 Commit Summary Table

Parse the git log on the current branch to build a commit summary:

```bash
git log --format="%s%n%b" origin/development..HEAD
```

From the commit messages, extract `Phase` and `Components` trailers.
Aggregate into a table:

```markdown
| Phase | Commits | Components |
|-------|---------|------------|
| 1-types | N | types, schemas, feature-flags |
| 2-fixtures | N | fixtures |
| ... | ... | ... |
| iteration | N | container, components |
```

If commits do not have trailers (pre-protocol commits), group them as
`| pre-protocol | N | unknown |`.

### 6.5.2 Side-Quest Summary

Extract all `Side-quest:` trailers from the git log:

```bash
git log --format="%b" origin/development..HEAD | grep "^Side-quest: "
```

Also check the cleanup file for `TODO(production-bug)` references.
Compile into a checklist:

```markdown
- [ ] <description> (<file:line>)
```

### 6.5.3 Squash Merge Template

Generate the squash-merge commit message using the template from
`docs/git-protocol.md`. Fill in all fields from the PRD header and
the aggregated commit data.

### 6.5.4 Output

Present all three artifacts to the PM:

> **PR artifacts generated.**
>
> When you open the draft PR, paste the following into the PR
> description (the PoC Handoff section of the PR template):
>
> <commit summary table>
> <side-quest checklist>
> <squash merge template>
>
> The engineer merging the PR will use the squash merge template as
> the commit message.

```

---

## File 10: `~/.claude/CLAUDE.md` (MODIFY)

Make two edits to the personal CLAUDE.md.

### Edit 10a: Add to work agent rules

Find the "Work agent rules" section. After rule 7 (the integration test
rule), add:

```
8. Follow the commit protocol in `docs/git-protocol.md` when working on
   `poc/*` branches. Every commit must include PoC, PRD, Phase, Prompt,
   and Components trailers. The commit-msg hook will reject non-conforming
   messages. Do not use `--no-verify` to bypass it.
```

### Edit 10b: Add commit format check to verification commands

Find the "Verification commands" section that lists the post-prompt
checks. After the line:

```bash
npx eslint . --max-warnings 0 2>&1 | tail -3
```

Add:

```bash
# On poc/* branches: verify commit message format
BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
if [[ "$BRANCH" == poc/* ]]; then
  git log -3 --format="%s%n%b" | grep -c "^PoC: " || echo "WARNING: recent commits missing PoC trailers"
fi
```

---

## Verification

After all edits are complete, verify:

```bash
# In ~/github/user-frontend/:

# 1. New files exist
ls -la docs/git-protocol.md
ls -la .husky/commit-msg

# 2. commit-msg hook is executable
test -x .husky/commit-msg && echo "PASS: hook is executable" || echo "FAIL: hook not executable"

# 3. CLAUDE.md has the new entries
grep -c "git-protocol.md" CLAUDE.md
grep -c "PoC branch commit protocol" CLAUDE.md

# 4. poc-pipeline.md has the updates
grep -c "poc/<slug>/<pm-initials>" docs/poc-pipeline.md
grep -c "git-protocol.md" docs/poc-pipeline.md

# 5. PR template has PoC section
grep -c "PoC Handoff" .github/PULL_REQUEST_TEMPLATE.md

# 6. orchestrate-poc has branch setup and commit protocol (BOTH locations)
grep -c "Q0e" .claude/skills/orchestrate-poc/SKILL.md
grep -c "Commit Protocol" .claude/skills/orchestrate-poc/SKILL.md
grep -c "Commit protocol" .claude/skills/orchestrate-poc/SKILL.md
grep -c "Q0e" ~/.claude/skills/orchestrate-poc/SKILL.md
grep -c "Commit Protocol" ~/.claude/skills/orchestrate-poc/SKILL.md
grep -c "Commit protocol" ~/.claude/skills/orchestrate-poc/SKILL.md

# 7. iterate-poc has sync check and commit protocol (BOTH locations)
grep -c "not behind development" .claude/skills/iterate-poc/SKILL.md
grep -c "Commit protocol" .claude/skills/iterate-poc/SKILL.md
grep -c "not behind development" ~/.claude/skills/iterate-poc/SKILL.md
grep -c "Commit protocol" ~/.claude/skills/iterate-poc/SKILL.md

# 8. iterate-poc-prd has commit format guidance (BOTH locations)
grep -c "Commit Protocol for PRD-only" .claude/skills/iterate-poc-prd/SKILL.md
grep -c "Commit Protocol for PRD-only" ~/.claude/skills/iterate-poc-prd/SKILL.md

# 9. generate-handoff-tickets has PR artifacts step (BOTH locations)
grep -c "Step 6.5" .claude/skills/generate-handoff-tickets/SKILL.md
grep -c "Squash Merge Template" .claude/skills/generate-handoff-tickets/SKILL.md
grep -c "Step 6.5" ~/.claude/skills/generate-handoff-tickets/SKILL.md
grep -c "Squash Merge Template" ~/.claude/skills/generate-handoff-tickets/SKILL.md

# 10. Verify both copies are identical for each skill
for skill in orchestrate-poc iterate-poc iterate-poc-prd generate-handoff-tickets; do
  diff .claude/skills/$skill/SKILL.md ~/.claude/skills/$skill/SKILL.md > /dev/null 2>&1 \
    && echo "PASS: $skill copies are identical" \
    || echo "FAIL: $skill copies DIFFER"
done

# 11. Personal CLAUDE.md has work agent rule 8 and commit format check
grep -c "docs/git-protocol.md" ~/.claude/CLAUDE.md
grep -c "PoC trailers" ~/.claude/CLAUDE.md
```

Every grep should return >= 1. If any returns 0, the edit was missed.

Additionally, test the commit-msg hook by simulating a bad commit on a
test branch:

```bash
# Create a temporary test branch
git checkout -b poc/test-hook/xx

# Test 1: bad message should be rejected
echo "bad commit message" > /tmp/test-commit-msg
.husky/commit-msg /tmp/test-commit-msg && echo "FAIL: should have rejected" || echo "PASS: rejected bad message"

# Test 2: good message should pass
cat > /tmp/test-commit-msg << 'TESTEOF'
feat(test-hook): test commit message format

PoC: test-hook
PRD: ~/plans/poc-test-hook.md
Phase: test
Prompt: manual
Components: docs
TESTEOF
.husky/commit-msg /tmp/test-commit-msg && echo "PASS: accepted good message" || echo "FAIL: rejected good message"

# Test 3: engineering escape hatch
echo "quick fix" > /tmp/test-commit-msg
GIT_PROTOCOL=skip .husky/commit-msg /tmp/test-commit-msg && echo "PASS: escape hatch works" || echo "FAIL: escape hatch broken"

# Clean up
git checkout -
git branch -D poc/test-hook/xx
rm /tmp/test-commit-msg
```

All three tests should show PASS.

---

## Reconciliation

Output this block after completing all work:

```
=== RECONCILIATION: Git Protocol Hardening ===
HEAD: <git sha>
Commits: <count> (<first_sha>..<last_sha>)
tsc: N/A (no production code changed)
Tests: N/A (no test files changed)
Build: N/A (no production code changed)
ESLint: N/A (no production code changed)

Prompt-Specific:
  docs/git-protocol.md exists: <yes/no>
  .husky/commit-msg exists and executable: <yes/no>
  CLAUDE.md grep git-protocol.md count: <N>
  poc-pipeline.md grep git-protocol.md count: <N>
  PR template grep "PoC Handoff" count: <N>
  orchestrate-poc grep "Q0e" count: <N> (project) / <N> (personal)
  orchestrate-poc grep "Commit Protocol" count: <N> (project) / <N> (personal)
  iterate-poc grep "not behind development" count: <N> (project) / <N> (personal)
  iterate-poc-prd grep "Commit Protocol for PRD-only" count: <N> (project) / <N> (personal)
  generate-handoff-tickets grep "Step 6.5" count: <N> (project) / <N> (personal)
  Skill copies identical: <all PASS / list failures>
  Personal CLAUDE.md grep "docs/git-protocol.md" count: <N>
  Hook test 1 (reject bad): <PASS/FAIL>
  Hook test 2 (accept good): <PASS/FAIL>
  Hook test 3 (escape hatch): <PASS/FAIL>

Behavioral Changes:
  Commits on poc/* branches now require structured messages with PoC,
  PRD, Phase, Prompt, and Components trailers. Engineers on non-poc
  branches are unaffected. The commit-msg hook enforces the format.

Cleanup Items Added: 0
Subsequent Prompts Modified: none
Deviations: <none | list>
Work Left Undone: <none | list>
=== END RECONCILIATION ===
```
