# Migration: BFF Lift-and-Shift from kb/bff

> Surgically copy the BFF server layer, env system, mock handler refactoring,
> integration test infrastructure, and supporting config from the kb/bff branch
> into sd/productionize. No git merge -- pure file copy + targeted edits.
> Created: 2026-03-06
> Updated: 2026-03-06 (rebased on 3182365b after Keith pushed 10 new commits)

## Context

- Source branch: `origin/kb/bff` (HEAD: 3182365b)
- Target branch: `sd/productionize` (HEAD: 8a2bfb5d)
- Worktree: `~/github/user-frontend-bff/`
- Merge base: `8abaa717` (Mar 3)
- kb/bff is 21 commits ahead; sd/productionize is 185 commits ahead
- sd/productionize is the dominant branch (architectural improvements,
  185 commits of test coverage, fixture work, DDAU cleanup)
- kb/bff contributes additive server-side code + env system + test infra +
  16 BFF API routes + mock handler refactoring

## Why Not Merge

A `git merge` would create 10+ conflicts and silently auto-merge files
where the BFF branch has older, regressed versions of code that
sd/productionize improved. The lift-and-shift eliminates all ambiguity
about which version of any line wins.

## Current State

sd/productionize: static-export frontend, all API calls proxy to UB
(user-backend) or mock handler (single 598-line catch-all).

```bash
# process.env reads to migrate (will be flagged by new ESLint rule)
grep -r 'process\.env\.' src/ --include='*.ts' --include='*.tsx' | grep -v node_modules | grep -v '.spec.' | wc -l
# Current count: ~22 (across 9 production files)
```

## Target State

Server-rendered Next.js with co-located BFF API routes. All process.env
reads go through Zod-validated clientEnv/serverEnv modules. Mock handler
refactored from single catch-all to 49 filesystem-based routes. Integration
test infrastructure stands up.

```bash
# After migration:
# - src/server/ exists with db clients, middleware, error handling, mock infra
# - src/pages/api/ has 16 BFF route files (health + 15 user management)
# - src/pages/api/mock/ has 49 filesystem-based mock route files
# - src/shared/lib/env/ exists with clientEnv, serverEnv, index
# - eslint-rules/no-process-env.js exists and is enforced
# - process.env reads in production code: 0 (except documented tree-shaking exceptions)
# - docker-compose.yml, scripts/sync-db.sh, scripts/seed-emulator-users.ts exist
# - src/tests/integration/ has 8 API-level test specs + setup infrastructure
# - pnpm tsc --noEmit: 0 errors
# - pnpm build: clean (server mode, not static export)
# - npx eslint . --max-warnings 0: clean
```

## Inventory

| #   | File                                                                  | Domain        | Type          | Prompt | Status    |
| --- | --------------------------------------------------------------------- | ------------- | ------------- | ------ | --------- |
| 1   | src/shared/lib/env/clientEnv.ts                                       | env           | new file      | 01     | completed |
| 2   | src/shared/lib/env/serverEnv.ts                                       | env           | new file      | 01     | completed |
| 3   | src/shared/lib/env/index.ts                                           | env           | new file      | 01     | completed |
| 4   | eslint-rules/no-process-env.js                                        | eslint        | new file      | 01     | completed |
| 5   | src/server/db/clickhouse.ts                                           | server        | new file      | 01     | completed |
| 6   | src/server/db/firebase-admin.ts                                       | server        | new file      | 01     | completed |
| 7   | src/server/db/postgres.ts                                             | server        | new file      | 01     | completed |
| 8   | src/server/db/relations.ts                                            | server        | new file      | 01     | completed |
| 9   | src/server/db/schema.ts                                               | server        | new file      | 01     | completed |
| 10  | src/server/errors/ApiErrorResponse.ts                                 | server        | new file      | 01     | completed |
| 11  | src/server/middleware/withAuth.ts                                     | server        | new file      | 01     | completed |
| 12  | src/server/middleware/withErrorHandler.ts                             | server        | new file      | 01     | completed |
| 13  | src/server/middleware/withMethod.ts                                   | server        | new file      | 01     | completed |
| 14  | src/server/mock/cors.ts                                               | server-mock   | new file      | 01     | completed |
| 15  | src/server/mock/handlers/auth.ts                                      | server-mock   | new file      | 01     | completed |
| 16  | src/server/mock/scenario.ts                                           | server-mock   | new file      | 01     | completed |
| 17  | drizzle.config.ts                                                     | drizzle       | new file      | 01     | completed |
| 18  | drizzle/0000_empty_killraven.sql                                      | drizzle       | new file      | 01     | completed |
| 19  | drizzle/meta/0000_snapshot.json                                       | drizzle       | new file      | 01     | completed |
| 20  | drizzle/meta/\_journal.json                                           | drizzle       | new file      | 01     | completed |
| 21  | src/pages/api/health.ts                                               | api           | new file      | 01     | completed |
| 22  | src/pages/api/users/user-data.ts                                      | api           | new file      | 01     | completed |
| 23  | src/pages/api/users/update.ts                                         | api           | new file      | 01     | completed |
| 24  | src/pages/api/users/auth/roles.ts                                     | api           | new file      | 01     | completed |
| 25  | src/pages/api/users/groups/index.ts                                   | api           | new file      | 01     | completed |
| 26  | src/pages/api/users/groups/[id].ts                                    | api           | new file      | 01     | completed |
| 27  | src/pages/api/users/groups/assign-users.ts                            | api           | new file      | 01     | completed |
| 28  | src/pages/api/users/groups/assign-users-to-projects.ts                | api           | new file      | 01     | completed |
| 29  | src/pages/api/users/groups/delete.ts                                  | api           | new file      | 01     | completed |
| 30  | src/pages/api/users/teams/create.ts                                   | api           | new file      | 01     | completed |
| 31  | src/pages/api/users/teams/getByOrgId.ts                               | api           | new file      | 01     | completed |
| 32  | src/pages/api/users/teams/remove.ts                                   | api           | new file      | 01     | completed |
| 33  | src/pages/api/users/teams/update.ts                                   | api           | new file      | 01     | completed |
| 34  | src/pages/api/users/userTeam/add-team-owners.ts                       | api           | new file      | 01     | completed |
| 35  | src/pages/api/users/userTeam/create-bulk.ts                           | api           | new file      | 01     | completed |
| 36  | src/pages/api/users/userTeam/remove-bulk.ts                           | api           | new file      | 01     | completed |
| 37  | docker-compose.yml                                                    | infra         | new file      | 01     | completed |
| 38  | scripts/sync-db.sh                                                    | infra         | new file      | 01     | completed |
| 39  | package.json                                                          | config        | surgical edit | 01     | completed |
| 40  | next.config.js                                                        | config        | surgical edit | 01     | completed |
| 41  | tsconfig.json                                                         | config        | surgical edit | 01     | completed |
| 42  | src/ui/config.ts                                                      | config        | surgical edit | 02     | completed |
| 43  | src/shared/lib/fetchApi/useFetchApi.ts                                | env-migration | surgical edit | 02     | completed |
| 44  | src/ui/providers/context/auth/firebase.ts                             | env-migration | surgical edit | 02     | completed |
| 45  | src/ui/providers/context/auth/hooks/useAuthBusinessLogic.ts           | env-migration | surgical edit | 02     | completed |
| 46  | src/ui/providers/context/webExtension.tsx                             | env-migration | surgical edit | 02     | completed |
| 47  | src/ui/components/8flow/TenantLogin/TenantLogin.tsx                   | env-migration | surgical edit | 02     | completed |
| 48  | src/ui/providers/context/auth/AuthStateProvider.tsx                   | env-migration | surgical edit | 02     | completed |
| 49  | src/shared/hooks/useFeatureFlags/useFeatureFlags.ts                   | env-migration | surgical edit | 02     | completed |
| 50  | src/shared/hooks/usePosthogClient/usePosthogClient.ts                 | env-migration | surgical edit | 02     | completed |
| 51  | eslint.config.mjs                                                     | config        | surgical edit | 02     | completed |
| 52  | src/shared/lib/fetchApi/useFetchApi.spec.ts                           | test-update   | surgical edit | 02     | completed |
| 53  | src/shared/hooks/usePosthogClient/usePosthogClient.spec.ts            | test-update   | surgical edit | 02     | completed |
| 53b | src/ui/config.spec.ts                                                 | test-update   | rewrite       | 02     | completed |
| 53c | src/ui/providers/context/webExtension.sendMessage.spec.ts             | test-update   | surgical edit | 02     | completed |
| 53d | env.d.ts                                                              | config        | surgical edit | 02     | completed |
| 53e | src/server/mock/handlers/auth.ts                                      | server-mock   | surgical edit | 02     | completed |
| 54  | src/pages/api/mock/[...endpoint].ts                                   | mock-handler  | delete        | 03     | completed |
| 54b | src/server/mock/scenario.ts                                           | mock-handler  | replace       | 03     | completed |
| 54c | src/pages/api/mock/\_\_reset.ts                                       | mock-handler  | new file      | 03     | completed |
| 55  | src/pages/api/mock/users/\* (18 CRUD + 31 read-only = 49 files)       | mock-handler  | new files     | 03     | completed |
| 55b | vitest.config.mts                                                     | config        | surgical edit | 03     | completed |
| 56  | docker/firebase-emulator/Dockerfile                                   | test-infra    | new file      | 03     | completed |
| 57  | scripts/seed-emulator-users.ts                                        | test-infra    | new file      | 03     | completed |
| 58  | src/tests/integration/setup/globalSetup.ts                            | test-infra    | new file      | 03     | completed |
| 59  | src/tests/integration/setup/containers.ts                             | test-infra    | new file      | 03     | completed |
| 60  | src/tests/integration/setup/nextServer.ts                             | test-infra    | new file      | 03     | completed |
| 61  | src/tests/integration/setup/seedDatabase.ts                           | test-infra    | new file      | 03     | completed |
| 62  | src/tests/integration/setup/authHelpers.ts                            | test-infra    | new file      | 03     | completed |
| 63  | src/tests/integration/setup/user_management.sql                       | test-infra    | new file      | 03     | completed |
| 64  | src/tests/integration/api/health.spec.ts                              | test-infra    | new file      | 03     | completed |
| 65  | src/tests/integration/api/users/user-data.spec.ts                     | test-infra    | new file      | 03     | completed |
| 66  | src/tests/integration/api/users/auth-roles.spec.ts                    | test-infra    | new file      | 03     | completed |
| 67  | src/tests/integration/api/users/groups.spec.ts                        | test-infra    | new file      | 03     | completed |
| 68  | src/tests/integration/api/users/teams-create-update-remove.spec.ts    | test-infra    | new file      | 03     | completed |
| 69  | src/tests/integration/api/users/teams-getByOrgId.spec.ts              | test-infra    | new file      | 03     | completed |
| 70  | src/tests/integration/api/users/update.spec.ts                        | test-infra    | new file      | 03     | completed |
| 71  | src/tests/integration/api/users/userTeam-create-remove-owners.spec.ts | test-infra    | new file      | 03     | completed |
| 72  | vitest.integration.config.mts                                         | test-infra    | new file      | 03     | completed |
| 73  | CLAUDE.md                                                             | docs          | surgical edit | 04     | completed |
| 74  | .gitignore                                                            | docs          | surgical edit | 04     | completed |
| 75  | docs/bff.md                                                           | docs          | new file      | 04     | completed |
| 76  | docs/bff-user-backend-migration.md                                    | docs          | new file      | 04     | completed |
| 77  | docs/testing.md                                                       | docs          | new file      | 04     | completed |
| 78  | docs/local-development.md                                             | docs          | surgical edit | 04     | completed |

## Migration Phases

| #   | Phase               | Prompt           | What                                                                         | Files | Mode   | Status    |
| --- | ------------------- | ---------------- | ---------------------------------------------------------------------------- | ----- | ------ | --------- |
| 1   | Foundation          | 01-foundation    | deps, env modules, server layer + mock infra, 16 API routes, config          | 41    | Task   | completed |
| 2   | clientEnv migration | 02-clientenv     | process.env -> clientEnv, ESLint rule, config.spec + webExt.sendMessage.spec | 16    | Manual | completed |
| 3   | Test infra          | 03-test-infra    | stateful mock handler refactoring, Docker, seed, integration tests           | 70    | Manual | completed |
| 4   | Docs + metadata     | 04-docs-metadata | CLAUDE.md, .gitignore, docs                                                  | 6     | Manual | completed |

**Final HEAD:** `69d5e0f7`
**Final metrics:** tsc: 0 errors, tests: 312 files / 3336 passed, build: clean, ESLint: clean (0 errors, 0 warnings)
**BFF route count:** 16, **Mock route count:** 50

**Note on Prompt 03 mode change:** Originally planned as Task agent (mechanical copy).
Now Manual because the mock handler refactoring requires extracting CRUD mutation logic
from the catch-all into 18 standalone files with a mutable state singleton. This preserves
Playwright test compatibility (5 specs depend on stateful CRUD behavior).

## Dependency Graph

```
Phase 1 (foundation: deps + server + env modules + routes + mock infra)
     |
     v
Phase 2 (clientEnv migration + ESLint rule activation)
     |
     v
Phase 3 (mock handler refactoring + test infrastructure)
     |
     v
Phase 4 (docs + metadata -- no code deps, runs last for accuracy)
```

Strictly sequential. Phase 2 needs the env modules from Phase 1. Phase 3
needs the server/mock infra from Phase 1 and ESLint rule from Phase 2.
Phase 4 should go last so docs reflect the final state.

## Key Decisions

- **server-only removed.** The BFF branch dropped all `import 'server-only'`
  from server files (Pages Router incompatibility). Do NOT add server-only.
- **BFF is the default routing mode.** `NEXT_PUBLIC_BFF`, `NEXT_PUBLIC_LOCAL_DEV`,
  and `NEXT_PUBLIC_API_HOST` have been removed from clientEnv. In production,
  `getApiHost()` returns `/api`. In local mode, `/api/mock`.
- **Mock handler refactoring with state preservation.** The 598-line catch-all
  is replaced by ~51 filesystem routes. The 18 CRUD routes preserve mutable
  state via an enhanced scenario.ts (same globalThis pattern as the catch-all).
  The 32 read-only routes are copied from the BFF worktree. This ensures all
  5 stateful Playwright specs (assignments, teams, bpo, projects, users) keep
  passing unchanged.
- **urls_registry.ts is out of scope.** BFF-branch-only refactoring touching 40+
  files. Will be addressed separately if needed.
- **signin.tsx ?uid= shortcut deferred.** Depends on urls_registry. Cleanup item.
- **Keep .husky/pre-commit.** The BFF branch deleted it. We want it.
- **Do NOT move @tanstack/react-query-devtools to dependencies.**
- **pnpm version stays at 9+.** Do NOT add `packageManager` field.
- **Tree-shaking exceptions documented.** Some `process.env` reads must stay
  literal for webpack dead-code elimination. Each gets an eslint-disable comment.

## Notes

- **Do NOT bring over kb/bff's versions of webExtension.tsx or
  useAuthBusinessLogic.ts wholesale.** Our versions are architecturally
  ahead. Only apply the clientEnv reads to our existing code.
- **useChatApi.ts does not exist on our branch.** Skip it entirely.
- **Keith pushed 10 commits after the plan was originally written**
  (db6cb30a -> 3182365b). All prompts were updated to account for:
  15 new BFF API routes (was 2), mock handler refactoring (was not in scope),
  6 new integration test specs (was 2), server-only removal, clientEnv schema
  shrinkage, and docker-compose + scripts additions.
