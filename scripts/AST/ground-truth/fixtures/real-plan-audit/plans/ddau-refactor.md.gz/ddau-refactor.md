# DDAU Refactor Plan -- next-gen-atlassian

> **Repo:** `8flowinc/next-gen-atlassian` (package name `@8flowinc/user-frontend`)
>
> **Branch:** `sd/productionize` (100+ commits ahead of main as of 2026-02-22)
>
> **Goal:** Convert the entire codebase to clean DDAU (Data Down, Actions Up)
> architecture where service hooks are standalone, providers hold only UI state,
> containers own all orchestration, and components receive everything via props.
> JSX templates follow least-power: return statements are flat declarations of
> layout, not programs that compute what to render.
>
> **Design principles:** See [CLAUDE.md](CLAUDE.md) in this repo for the full
> set of hard rules (zero spooky action, least power, useEffect discipline,
> state ownership, hook/context boundaries). See the skills README for template
> discipline rules.

---

## At a Glance

```
DDAU Refactor Progress -- sd/productionize
================================================================
Phase 0: Infrastructure
[##########################################################] 100%
  Cleanup registry, query keys, nuqs, directory structure

Phase 1: Extract service hooks (~40 hooks from 6 domains)
[##########################################################] 100%
  All 40 hooks extracted. Factory utilities deleted.

Phase 2: Strip providers (6 providers)
[##########################################################] 100%
  InsightsContext, BpoProject, Teams, UserDetail,
  UrlClassification, MicroworkflowSuggestions -- all deleted.
  CompanyProvider -> CompanyScopeProvider (kept, cleaned).

Phase 3: Create containers (8 routes + layout)
[##########################################################] 100%
  DashboardLayout, productivity, team-productivity,
  realtime-activity, explorer, relay-usage, chat,
  AnalysisLayout -- all containerized.

Phase 4: God component decomposition (4 components)
[##########################################################] 100%
  SystemsBlock          1017 -> 530
  OpportunitiesV2Block   500 -> 105
  ProcessMiningView     4655 -> 1547
  ProductivityPage      5860 -> 1284

Phase 5: Safe cleanup (behavior-preserving)
[##########################################################] 100%
  Dead code (~8500 ln), bug fixes (5), localStorage consol.
  ESLint auto-fixes deferred to Phase 9.4.

Phase 6: Full-scope DDAU completion
[##########################################################] 100%
  6.1 Dead code sweep       tsc 360->334
  6.2 Broken spec fixes     all passing
  6.3 useEffect cleanup     38 effects eliminated
  6.4 Lint/debug cleanup    done

Phase 7: Structural decomposition (6 components)
[##########################################################] 100%
  7.1 OpportunitiesV2Block  2388 -> 1273 ln (29 files, 56 tests)
      Shared: MetricPercentageBar (25 sites), TruncatedCell (34 sites)
      Domain: AgentConfigPanel, OpportunityDescription, TypeBadge
  7.2 CompanySwitchModal    DELETED -- dead code (1537 lines)
  7.3 SystemsBlock          SummaryStrip, SelectionSummary, formatNumber
  7.4 ActivitiesTable       flatten template + dedup badges
  7.5 RealtimeFilters       dead types + unused props removed
  7.6 SignedInPageShell      dead hooks removed, barrel exports

Phase 8: Area-by-area DDAU migration
[##########################################################] 100%
  8.1 settings/teams        FlyoutProvider eliminated, useRouter removed
  8.2 settings/users        FlyoutProvider eliminated, circular import fixed
  8.4 Account + OpportV2    useAuthState hoisted, useCompanyScope lifted

Phase 9: Type safety + lint pass
[##########################################################] 100%
  9.1 Unused variables      43 errors fixed   (292->249)
  9.2 as-any replacement    3 errors fixed    (249->246)
  9.3-9.4 ESLint auto-fix   36 files, style-only (246 unchanged)

Phase 10: Effect + cast cleanup
[##########################################################] 100%
  exhaustive-deps annotations (8 suppressions documented)
  || to ?? conversions (12 files)     tsc 246->245

Phase 11: Fix-all audit (109 items, 12 sub-phases)
[##########################################################] 100%
  Dead code, shared utils, service layer, containers,
  DDAU conversions, god components, template flattening
  tsc: 244 -> 0

Phase 12: Type refactor (3 tracks, 12 commits)
[##########################################################] 100%
  A: 16 domain modules, all duplicates eliminated
  B: 115 `any` gone, guards fixed, trust boundaries
  C: 4 branded IDs, 18 enums converted, zero enum in src/

Phase 12b: Production `any` sweep (8 agents, 2 waves)
[##########################################################] 100%
  ~170 production `any` eliminated across ~55 files
  4 justified `any` retained (TanStack ColumnDef x3, zodResolver x1)

Phase 13: Remaining audit fixes (7 agents, 2 waves)
[##########################################################] 100%
  SystemsTab 1458->452, ActivitiesTable 1050->476
  Chat.tsx return 174->94, all JSON.parse Zod-validated

Phase 14: Template discipline pass (was Phase 11)
[#####################################################-----]  ~90%
  Largely completed by Phases 11+13. Verification pending.

Phase 15: Test verification + PR readiness (was Phase 12)
[####################--------------------------------------]  ~30%
  15.0 test fixes DONE. 15.5 ESLint config DONE. Pre-commit hook restored.
  Browser + PR remain.

Parallel: Dependency Updates (Steps 1-3)
[##########################################################] 100%
  Step 1: Cleanup + Tier 1 patches (7 dead deps, all in-range)
  Step 2: Tier 2 cross-major dev-only (11 packages, 9 commits)
  Step 3: React 19 + Next.js 15 (10 commits, 2 CVEs resolved)
  Vulns: 50 -> 3 (94% reduction). Zero production surface.
  Steps 4+: deferred (Firebase 12, Zod 4, Tailwind 4, etc.)
================================================================
OVERALL   [######################################################--]  ~95%
           Phases 0-13 COMPLETE. Phase 14 ~90%. Phase 15 ~30%.
           Dependency Steps 1-3 COMPLETE. Verified 2026-02-22.
tsc:      555 -> 0   (-555)       Commits: 100+ ahead of main
ESLint:   454 -> 0 errors, 394 warnings (pre-commit active, blocks errors)
DDAU:     50% -> ~85% (est.)      Providers deleted: 6/6
Dead code removed: ~13,200 lines  useEffects eliminated: 41+
God components decomposed: 13     Service hooks (clean): 20
Shared components extracted: 7    Shared type modules: 16
Branded types: 4 IDs              Enums removed: 18
JSON.parse: all Zod-validated     Lines of type analysis: 940
Vulns:    50 -> 3 (94%)           React 19 + Next.js 15 landed
```

---

## Skills

Each refactoring step is automated by a skill. Run the audit first for any
domain before running write skills in that domain.

| Skill | Purpose |
|-------|---------|
| `/audit-react-feature <dir>` | Read-only diagnostic with migration checklist |
| `/refactor-react-service-hook <file>` | Strip factory indirection, side effects, cross-domain keys |
| `/refactor-react-hook <file>` | Refactor utility/context/composite hooks |
| `/refactor-react-provider <file>` | Strip data-fetching, split broad contexts, cleanup registry |
| `/refactor-react-route <file>` | Create/complete container, absorb all hook calls |
| `/refactor-react-component <file>` | DDAU conversion, extract container for leaves |
| `/flatten-jsx-template <file>` | Lift logic out of JSX return into named intermediates |
| `/extract-shared-presentational <Name> <pattern> <files...>` | Extract repeated rendering patterns into shared components |

All refactor skills run `npx tsc --noEmit` and available tests after rewriting
to verify the refactor is behavior-preserving. The audit skill is read-only.

**Worktree protocol:** Each phase should be done on its own branch. Skills that
move files or update imports should NOT run in parallel on overlapping import
graphs. See [WORKTREE-PROTOCOL.md](WORKTREE-PROTOCOL.md).

---

## Metrics

| Metric | Start | Phase 10 (2026-02-19) | Current (2026-02-22) |
|--------|-------|-----------------------|----------------------|
| tsc errors | 555 | 245 | 0 |
| DDAU compliance (components) | ~50% | ~66% (107/162) | ~85% (est.) |
| Containers created | 0 | 15+ | 15+ |
| Providers stripped/deleted | 0 | 6/6 | 6/6 |
| God components decomposed | 0 | 10 | 13 (+SystemsTab, ActivitiesTable, Chat) |
| useEffects eliminated | 0 | 38+ | 41+ |
| Service hooks (all clean) | 0 | 20 | 20 |
| Lines deleted (dead code) | 0 | ~11,800+ | ~13,200+ |
| Commits on branch | 0 | 64 | 100+ |
| Shared type modules | -- | -- | 16 (src/shared/types/) |
| Branded types (Tier 1 IDs) | -- | -- | 4 (UserId, WorkstreamId, TeamId, OrganizationId) |
| Enums converted to as-const | -- | -- | 18 (zero enum in src/) |
| JSON.parse calls validated | -- | -- | all (Zod .parse server, .safeParse client) |
| `any` eliminated (production) | -- | -- | ~285 (115 Phase 12 + 170 Phase 12b; 4 justified remain) |
| Non-null assertions reduced | -- | -- | ~81 eliminated via getOrCreate + guards |
| ESLint source errors | 454 | -- | 0 errors, 394 warnings (pre-commit hook active, blocks errors, allows warnings) |

**tsc note (historical):** At Phase 10, 39 of the 245 remaining errors were
TS2306 from `next.d.ts` in the project root shadowing `node_modules/next`.
These were resolved as part of Phase 11 (fix-all audit). tsc is now at 0 errors.

---

## Phase Summary

| Phase | Status | Description |
|-------|--------|-------------|
| 0 | DONE | Infrastructure: directory structure, cleanup registry, key migration, auth integration, move 15 clean hooks, install nuqs |
| 1 | DONE | Extract service hooks: ~40 hooks from 6 provider domains, delete factory utilities |
| 2 | DONE | Strip providers: remove data-fetching from 6 providers, delete 4-5 entirely |
| 3 | DONE | Create containers: 15+ containers (layouts, routes, non-route entry points) |
| 4 | DONE | Convert components: ~20 DDAU conversions, 4 god component splits |
| 5 | DONE | Safe cleanup: dead code, bug fixes, localStorage consolidation (ESLint absorbed into 9.4) |
| 6 | DONE | Full-scope cleanup: dead code sweep, spec fixes, useEffect cleanup, lint/debug cleanup |
| 7 | DONE | Structural decomposition: 6 components split, 7 shared components extracted, 1537 lines dead code deleted |
| 8 | DONE | Area-by-area DDAU: teams/, users/, Account, OpportunitiesV2 migrated |
| 9 | DONE | Type safety: 46 errors fixed, ESLint auto-fix on 36 files |
| 10 | DONE | Effect + cast cleanup: exhaustive-deps documented, || to ?? converted |
| 11 | DONE | Fix-all audit: 109 items across 12 sub-phases, tsc 244->0 |
| 12 | DONE | Type refactor: 3 tracks (centralize, safety, branded types), 12 commits |
| 12b | DONE | Production `any` sweep: 8 agents, 2 waves, ~170 `any` eliminated across ~55 files (4 justified retained) |
| 13 | DONE | Remaining audit fixes: 7 agents, 2 waves, 50 files, 3 god components decomposed |
| 14 | MOSTLY DONE | Template discipline pass (was Phase 11): largely completed by Phases 11+13, verification pending |
| 15 | IN PROGRESS | Test verification + PR readiness (was Phase 12). 15.0 test fixes DONE. 15.5 ESLint config DONE. Pre-commit hook restored (0 errors, 394 warnings). |

---

## Phases 0-6: DONE

Detailed progress in the Phase Files and the Progress Log at the end.

| File | Phase | Summary |
|------|-------|---------|
| [ddau-phase-0.md](ddau-phase-0.md) | Infrastructure | Directory structure, cleanup registry, key migration, auth integration, move 15 clean hooks, install nuqs |
| [ddau-phase-1.md](ddau-phase-1.md) | Extract service hooks | ~40 hooks from 6 provider domains, delete factory utilities |
| [ddau-phase-2.md](ddau-phase-2.md) | Strip providers | Remove data-fetching from 6 providers, delete 4-5 entirely |
| [ddau-phase-3.md](ddau-phase-3.md) | Create containers | 8-10 containers (orchestration boundaries: layouts, routes, non-route entry points) |
| [ddau-phase-4.md](ddau-phase-4.md) | Convert components | ~15-20 DDAU conversions, 4 god component splits |

**Key accomplishments (Phases 0-4):**
- InsightsContextProvider fully removed (replaced by `useFilterStore` + nuqs)
- `useFilterStore` hook (useSyncExternalStore + localStorage) replaces context filter state
- `useSelectedWorkstreams` hook (URL + TQ cache) replaces context workstream selection
- 8+ URL state params migrated to nuqs (tz, hours, ws, user, filter params)
- 4 god components decomposed: SystemsBlock (1017->530), OpportunitiesV2Block (500->105), ProcessMiningView (4655->1547), productivity.tsx (5860->1284)
- All 6 providers stripped/deleted, 15+ containers created

**Key accomplishments (Phases 5-6):**
- ~8,500 lines dead code deleted
- 5 real bugs found and fixed during audit
- 10 useEffects eliminated, 3 timer leaks fixed
- `useHydrated()` hook created, replacing ~6 `setIsMounted(true)` patterns
- ~15 eslint-disable directives addressed, ~20 console statements removed

---

## Phase 7: Structural Decomposition -- DONE

> 6 components decomposed. 7 shared presentational components extracted.
> 1,537 lines of dead code (CompanySwitchModal) discovered and deleted.

### 7.1 OpportunitiesV2Block -- commit `c253031`

- 2388 -> 1273 lines, return 973 -> 57 lines
- 29 files changed, +2048/-2656, 56 new tests
- Shared components extracted:
  - `MetricPercentageBar` (25 call sites across 6 files)
  - `TruncatedCell` (34 call sites across 4 files)
- Domain components extracted:
  - `AgentConfigurationPanel` (367 lines)
  - `SelectedOpportunitySummary`
  - `OpportunityDescription`
  - `OpportunityTypeBadge`
- Utilities: `opportunityUtils.ts` (calculateOpportunityScoreWithDetails, getScoreColors, etc.)
- `alert()` replaced with `toastError()`
- tsc: 332 -> 301

### 7.2 CompanySwitchModal -- commit `fe0ccb3`

- DELETED: 1,537 lines, zero consumers found
- tsc: 301 -> 292

### 7.3 Systems feature -- commit `fa3dafe`

- Shared components: `SummaryStrip`, `SelectionSummary`, `formatNumber` utility
- Template flattened across systems components

### 7.4 ActivitiesTable -- commit `54a2e31`

- Template flattened, badge rendering deduplicated

### 7.5 RealtimeFilters -- commit `671efad`

- Dead types deleted, unused props removed

### 7.6 SignedInPageShell -- commit `818fe84`

- Dead hooks removed, barrel exports added

---

## Phase 8: Area-by-Area DDAU Migration -- DONE

### 8.1 settings/teams/ -- commit `0db96d8`

- `TeamNameLink`: `useRouter` removed, replaced with `<Link>`
- `OrgHostDetailsPanel`: `useFlyoutContext` eliminated
- FlyoutProvider eliminated from teams area
- 8 files changed, tsc unchanged at 292

### 8.2 settings/users/ -- commit `2668313`

- `UserPanel` / `UserRoleSelect`: DDAU conversion
- FlyoutProvider eliminated from users area
- Circular import fixed
- 6 files changed, tsc unchanged at 292

### 8.4 Account + OpportunitiesV2 sweep -- commit `82561ee`

- `useAuthState` hoisted to container boundary
- `useCompanyScope` moved to wrapper component
- Infrastructure components (Account, etc.) correctly classified as boundary layer

---

## Phase 9: Type Safety + Lint Pass -- DONE

### 9.1 Unused variables -- commit `24cc8b0`

- 43 TS6133/TS6196 errors fixed across 21 files
- tsc: 292 -> 249

### 9.2 as-any replacement -- commit `3c38709`

- `productivityColumns.tsx`: replaced `(col as any).accessorKey` with `'accessorKey' in col` type guard (3 sites)
- `ProcessMiningView.tsx`: `ConnectionLineType.Bezier` and `BackgroundVariant.Lines` enums instead of string literals; removed invalid `pathOptions`
- 16 remaining `as any` casts deferred (library compat: zod/react-hook-form, missing type defs: FilterState.timezone/transition.workstreams, test mocks)
- tsc: 249 -> 246

### 9.3-9.4 ESLint auto-fix -- commit `a6bf9fb`

- 36 files touched
- `type` aliases -> `interface` where applicable
- `let` -> `const` where never reassigned
- Bracket notation -> dot notation
- `interface { [key: string]: T }` -> `Record<string, T>`
- tsc: 246 (unchanged, style-only)

---

## Phase 10: Effect + Cast Cleanup -- DONE

### commit `fec39ef`

- All 8 `eslint-disable react-hooks/exhaustive-deps` suppressions in touched files annotated with justification comments
- `||` to `??` conversions across 12 UI files (array coalescing where values are always nullish-or-array)
- `|| 'System'` -> `?? 'System'` in SystemsCardView
- 18 files changed
- tsc: 246 -> 245

**Deferred from Phase 10 (post-PR or follow-up):**
- `next/router` -> `next/navigation` migration (9 files)
- `usePosthogClient` singleton pattern
- Remaining `localStorage.removeItem` calls that should use `registerCleanup`

---

## Phase 11: Fix-All Audit -- DONE

> 109 items across 12 sub-phases. Full-repo audit found violations in 16
> areas, then a systematic fix plan eliminated them all. tsc went from
> 244 to 0 errors. Baseline commit `0106416`, final commit `764c0a3`.

**Key metrics:**
- 109 items completed (3 closed as no-ops: already clean or file removed)
- 35+ commits from baseline to completion
- tsc: 244 -> 0 (project start was 555)
- ~65 skill invocations + ~40 manual edits

**By category:**

| Category | Items | Highlights |
|----------|------:|-----------|
| Dead code deletion | 16 | flyoutContext.tsx, 40+ dead exports, write-only storage keys |
| Shared utilities + type relocations | 21 | useContainerSize hook, formatDuration dedup, cross-domain type moves |
| Service hook extraction | 5 | 2 inline useQuery calls extracted, 3 leaf components converted to DDAU |
| Provider/context cleanup | 3 | registerCleanup for auth logout, eliminable useEffects |
| Container boundary fixes | 11 | usePathname removal, toast hoisting, useAuthState lifting, ghost state elimination |
| useEffect elimination | 12 | useAutoScroll extraction, animation timer replacements, CSS transitions |
| Timer race fixes | 10 | setTimeout cleanup, rAF replacements, CSS transition substitutions |
| DDAU leaf conversions | 4 | render-function patterns, column definition refactors, CrudGroupBlock unification |
| God component decomposition | 7 | OpportunitiesV2Block, ImplementationPlanPDF, SystemsTab, useActionsTableColumns, WorkstreamDetails, SystemsCardView, ActivitiesTable |
| Template flattening | 16 | Chat, usage (4 files), AnalysisLayout, systems, Sidebar, TableFilter, users |
| Repeated pattern extraction | 5 | SelectionSummary variant, activity type badges, MetadataDetailsContent shared, explorer utility dedup |
| Debug/storage/URL corrections | 8 | Stale TODOs, dual localStorage paths, sessionStorage to URL state |

See [ddau-phase-11-fix-all-audit.md](ddau-phase-11-fix-all-audit.md)
for per-item detail (109 items with status, skill, target files, and expected outcomes).

---

## Phase 12: Type Refactor -- DONE

> Three independent tracks: centralize/deduplicate, type safety fixes,
> and branded types. 12 commits total. All shared types now live in
> `src/shared/types/` with a barrel index. Zero `enum` declarations remain.

### Track A: Centralize and Deduplicate (7 commits)

- **Phase 0 (infrastructure):** Created `brand.ts` (17 branded types + constructors), `api.ts` (ErrorResponse, QueryOptions), 16 domain module stubs, barrel index
- **Phase 1 (deduplicate):** Eliminated all copies from duplication map: ErrorResponse (17 API routes), QueryOptions (11 service hooks), DatasetKey (5 defs), microworkflow types (4), span types (5), CompanyDataStatus (2). Split `companyData.ts` into fetch-only (0 exported types remain)
- **Phase 2 (relocate):** 4 sub-commits (2a: 102 files, 2b: 90 files, 2c: 41 files, 2d: 8 files). insightsContext/types.ts decomposed (79+ types, zero circular deps). All multi-consumer types relocated. Single-consumer types stay co-located per rule 2.4.2
- **Post-Phase 2:** 11 skills updated with "Type touchpoints" blocks. Barrel completeness verified (14 missing re-exports added)

### Track B: Type Safety (3 commits)

- **B1:** 115 `any` eliminated from 3 productivity files (typed interfaces in `productivity.ts`)
- **B2:** All `catch (error: any)` standardized to `catch (error: unknown)` with proper narrowing
- **B3:** `isApiError` fixed (instanceof), `isUser` improved (5-field check), `isObjectType` renamed to `hasKeys` (honest return type)
- **B4:** ~81 non-null assertions eliminated via `getOrCreate` helper (src/shared/utils/map.ts) + guard clauses
- **B5:** Trust boundary validation -- `schema?: ZodType<T>` on fetchApi (opt-in), `readStorage`/`writeStorage` (typedStorage.ts), `parseQueryParam`/`requireQueryParam` (queryParams.ts). Supabase typed client deferred (needs DB schema access)

### Track C: Branded Types + Enum Cleanup (3 commits)

- **C1-C3:** 4 Tier 1 branded IDs deployed: `UserId` (155 constructor calls, 23 files), `WorkstreamId` (39 calls, 10 files), `TeamId` + `OrganizationId` (14 calls, 8 files)
- **C4:** 18 enums converted to `as const` + derived union type (including 2 discovered: TextFormat, PageSizeValue). Zero `enum` declarations remain in `src/`

**New shared utilities:**
- `getOrCreate` (src/shared/utils/map.ts)
- `readStorage`/`writeStorage` (src/shared/utils/typedStorage.ts)
- `parseQueryParam`/`requireQueryParam` (src/shared/utils/queryParams.ts)

**Deferred:** Supabase typed client (TODO in `src/lib/supabase.ts`, needs DB schema access).

See [ddau-phase-12-type-refactor.md](ddau-phase-12-type-refactor.md) for
analysis sections (type inventory, duplication map, branded type catalog,
type safety audit) and per-commit detail.

---

## Phase 12b: Production `any` Sweep -- DONE

> 8 agents across 2 waves. ~170 explicit `any` annotations eliminated from
> ~55 production files. 4 justified `any` retained. 34 test-file `any`
> remain (Phase 15.2 scope). Post-audit fix: 1 missed file
> (`src/server/workstream-analysis/utils.ts`) typed manually.

**Wave 1 (4 agents, simultaneous) -- data layer + foundation:**

| Agent | Domain | Files | `any` eliminated |
|-------|--------|-------|-----------------|
| 1 | Productivity data types | companyDataStorage.ts, productivity.tsx, useDashboardData.ts, ProductivityDataUpload.tsx | ~24 |
| 2 | Server-side API routes | 12 files in pages/api/ (spans, events, microworkflows, getUserLoadTimeByHost, etc.) | ~25 |
| 3 | Explorer data layer | ProcessMiningView.tsx, ProcessMiningViewContainer.tsx, NodeDetailsPanel.tsx, FlowNodes.tsx, form.ts, validation.ts | ~29 |
| 4 | Shared types + utilities | shared/types/spans.ts, companyData.ts, systemsSpans.ts, Tabs.tsx, errorTracking.ts, supabase.ts, middleware.ts | ~15 |

**Wave 2 (4 agents, simultaneous) -- UI consumers:**

| Agent | Domain | Files | `any` eliminated | Justified retained |
|-------|--------|-------|------------------|--------------------|
| 5 | Productivity UI | useProductivityKpiData.ts, TimeDistributionSection.tsx, ProductivityTrendCard.tsx, OverviewSection.tsx | ~15 | 0 |
| 6 | Analysis + filters | AnalysisLayoutContainer.tsx, SystemsBlock.tsx, buildActionsData.ts, InsightsFilters.tsx, + 6 more | ~23 | 1 (zodResolver) |
| 7 | TanStack ColumnDef + Table | activitiesTableColumns.tsx, UserDetailPanel.tsx, SystemsTab.tsx, Table.tsx, storage.ts, + 6 more | ~20 | 1 (TanStack invariance) |
| 8 | Relay/Teams/misc | RelayUserDetails.tsx, EditTeamForm.tsx, chat/utils.tsx, MicroworkflowsBlockContainer.tsx, + 11 more | ~27 | 0 |

**Recovery:** Agent 3's explorer changes were lost during parallel file writes.
Re-ran manually to fix all 22 remaining `any` in 7 explorer files.

**Justified `any` retained (4):**
- `Table.tsx:87` -- `onClickRow?: (value: any) => void`: TanStack Table `Data` generic
  is invariant, callback value type varies at runtime.
- `useUsersTableColumns.tsx:19` -- `ColumnDef<MappedUser, any>`: TanStack ColumnDef TValue
  is invariant; heterogeneous column value types require `any`.
- `CrudGroupBlock.tsx:27` -- `ColumnDef<TData, any>[]`: same TanStack invariance issue.
- `InsightsFilters.tsx:67` -- `zodResolver(validationSchema as any)`: zod v3 / zodResolver
  overload incompatibility, no narrow cast available.

All 4 have `eslint-disable-next-line` with justification comments.

**Post-audit fix:** `src/server/workstream-analysis/utils.ts` had `Promise<any>`
that was missed by the plan (which listed `src/pages/api/.../utils.ts` -- a
different file). Fixed by adding `type WorkstreamLoadTimeData = z.infer<typeof WorkstreamLoadTimeSchema>`.

See [ddau-any-fix-plan.md](ddau-any-fix-plan.md) for per-agent task specifications.
The orchestrator prompt is in [ddau-any-fix-orchestrator.md](ddau-any-fix-orchestrator.md).

---

## Phase 13: Remaining Audit Fixes -- DONE

> 7 agents across 2 waves, all file-independent within each wave.
> 50 files changed, +2902/-2207. Final commit `bbc5ec8`.

**Wave 1 (4 agents, simultaneous):**

| Agent | Domain | Key results |
|-------|--------|------------|
| 1 | chat/ | Chat.tsx return 174->94 lines, ResponseMessage typewriter rAF, ChatContainer guard, useChatApi Zod |
| 2 | SystemsTab | 1458->452 lines: useSystemsTabSelection hook, useAnimationTimers hook, SystemDetailPanel, UserStatsSection. JSON.parse Zod in 2 containers |
| 3 | ActivitiesTable | 1050->476 lines: detail panels extracted, filter bar extracted. JSON.parse Zod in 2 files |
| 4 | analysis/ + misc | AnalysisLayout flatten, MicroworkflowsBlockWrapper moved to opportunities/, ColumnTooltip useLayoutEffect, flyoutContext.tsx deleted |

**Wave 2 (3 agents, simultaneous):**

| Agent | Domain | Key results |
|-------|--------|------------|
| 5 | Container boundaries | useAuthState lifted from users/index.tsx, EditAssignmentModal, TeamBlock.tsx. JSON.parse Zod in productivityUtils.ts |
| 6 | Server JSON.parse | 13 files, ~17 calls: all server-side JSON.parse wrapped with Zod `.parse()`. Deep clones replaced with `structuredClone()` |
| 7 | Client JSON.parse | 7 files, ~10 calls: all client-side JSON.parse wrapped with Zod `.safeParse()` or `readStorage`. reportPeriodTypeItems moved to shared constants |

**Summary:**
- 3 god components decomposed (SystemsTab, ActivitiesTable, Chat.tsx)
- All JSON.parse calls now Zod-validated (`.parse()` server, `.safeParse()` client)
- 3 useEffects eliminated, 1 converted to useLayoutEffect
- useAuthState lifted from 3 leaf components to containers
- Cross-domain import fixed (MicroworkflowsBlockWrapper)
- Dead code deleted (flyoutContext.tsx)
- Commits: `7d5f071` (Agent 5), `bbc5ec8` (all others)

See [ddau-phase-13-remaining-fixes.md](ddau-phase-13-remaining-fixes.md) for per-agent
task specifications and verification criteria. The multi-agent orchestrator
prompt is in [ddau-phase-13-orchestrator.md](ddau-phase-13-orchestrator.md).

---

## Phase 14: Template Discipline Pass -- MOSTLY DONE (was Phase 11)

> The original Phase 11 aimed to flatten worst-offender templates and
> extract shared components. Phases 11 and 13 (in the new numbering)
> completed the bulk of this work.

**Completed by Phase 11 (fix-all audit):**
- Template flattening across 16 components (Chat, usage x4, AnalysisLayout, systems, Sidebar, TableFilter, users, etc.)
- Repeated pattern extraction (SelectionSummary, activity type badges, MetadataDetailsContent, explorer utilities)
- God component decomposition (7 components split, including several from the original worst-offender list)

**Completed by Phase 13 (remaining audit fixes):**
- SystemsTab 1458->452 lines (was on original worst-offender list)
- ActivitiesTable 1050->476 lines (was on original worst-offender list)
- Chat.tsx return 174->94 lines

**Remaining:** Verification pass via [ddau-codebase-audit.md](ddau-codebase-audit.md).
Run `/audit-react-feature` on each area to confirm no return statements
exceed 100 lines and no chained ternaries remain. Phase 14 can be marked
DONE after the first clean audit run, or any remaining items fold into Phase 15.

---

## Phase 15: Test Verification + PR Readiness (was Phase 12)

### 15.0 Fix Failing Tests + Vitest Hang -- DONE (2026-02-23)

21 test failures across 6 files + vitest process hang. All caused by stale
tests not updated during Phases 0-13.

**Root causes and fixes:**
- **Zod schema too strict** (12 failures): `storage.ts` inner schema required
  all fields but table state is written incrementally. Added `.partial().passthrough()`.
- **SummaryStrip testids** (2 failures): Tests expected label-based testids but
  component uses `key ?? index`. Added `key` prop to test items.
- **useFeatureFlags mocks** (3 failures): Mocks returned JSON-encoded strings
  (`'"45"'`) but `z.coerce.string()` calls `String()`, not `JSON.parse()`.
  Changed to plain strings (`'45'`).
- **TableFilter full rewrite** (2+8 failures): Plan identified 2 stale tests
  but the entire file was stale (component API changed: removed storage access,
  renamed `onFilterData` to `onApplyFilters`, added `onClearFilters`). Full
  rewrite: 10 tests across 4 describe blocks.
- **InsightsFilters localStorage mock** (1 failure): Test mocked
  `localStorage.getItem` but component reads via mocked `useFilterStore`.
  Switched to mocking the store directly.
- **Vitest hang**: `fetchMocker.enableMocks()` in `vitest.setup.ts` never
  disabled, holding open handles in `pool: 'forks'`. Added `afterAll` cleanup
  + `teardownTimeout: 5000` in vitest config.

**Additional fixes discovered during execution:**
- React 19 passes `undefined` as 2nd arg to component mocks; replaced all
  `expect.anything()` with `undefined` (6 sites in TableFilter.spec.tsx)
- `tsconfig.eslint.json` missing `**/*.mts` in `include` (ESLint parser error)
- `vitest.config.mts` triple-slash references violated `@typescript-eslint/triple-slash-reference`
- `InsightsFilters.spec.tsx` `as any` on mock return replaced with
  `as ReturnType<typeof useLoadTeamsQuery>`

**Files modified (8):** `vitest.setup.ts`, `vitest.config.mts`,
`tsconfig.eslint.json`, `storage.ts`, `SummaryStrip.spec.tsx`,
`useFeatureFlags.spec.ts`, `TableFilter.spec.tsx`, `InsightsFilters.spec.tsx`

**Verification:** 75/75 tests pass, tsc clean, ESLint clean on all 7 touched
files, process exits in ~4s.

### 15.1 Mock Type Factories

Build mock type factories for hooks used across multiple specs:
- `useFilterStore`
- `useSelectedWorkstreams`
- `useCompanyScope`
- `useFilterCollapse`

One factory per hook, co-located in the hook's directory or in a shared
`src/shared/test-utils/` module.

### 15.2 Spec `as any` Sweep

Replace all bare `as any` casts on `.mockReturnValue()` calls with factory
calls or properly typed mock objects. Goal: zero `no-explicit-any` /
`no-unsafe-argument` lint errors in spec files.

### 15.3 Browser Testing

Per [ddau-refactor-testing.md](ddau-refactor-testing.md):
- Smoke tests (10 routes)
- Interactive flows (Systems, Opportunities, Explorer with zoom regression Z1-Z4, Productivity 17 scenarios)
- Cross-feature navigation

### 15.4 Final Audit Sweep

Run `/audit-react-feature` on every feature area. Verify:
- Zero hook calls in leaf components (except MAY-remain ambient hooks)
- Zero context reads in leaves
- Zero storage access in leaves
- Zero toast calls outside containers
- All return statements under 100 lines
- No chained ternaries in JSX

### 15.5 ESLint Config Cleanup -- DONE (2026-02-23)

Starting state: 454 source errors across 66 files (5006 total reported, but
4548 were from `.next/` build output).

**Changes made:**
1. **Added `.next/**/*` to ESLint ignores** in `eslint.config.mjs` --
   eliminates 4548 phantom errors from build output.
2. **Ran `--fix` on auto-fixable rules** (~32 errors fixed: `no-duplicate-imports`,
   `no-unnecessary-type-assertion`, `prefer-optional-chain`, `prefer-nullish-coalescing`).
3. **Downgraded `no-unsafe-*` + `no-explicit-any` to `warn`** -- 393 errors
   (86% of total) are from untyped Supabase query responses cascading through
   API routes. These cannot be fixed until the Supabase typed client is generated
   (`npx supabase gen types typescript`). TODO comments in `eslint.config.mjs`
   mark all 10 rules for revert to `'error'` once DB schema access is available.

**Result (initial):** 11 errors, 396 warnings. The 11 remaining errors were non-any issues
(duplicated imports not auto-fixable in flat config, `react-hooks/exhaustive-deps`,
`no-base-to-string`, `no-misused-promises`, `no-unused-vars`, `triple-slash-reference`,
`no-non-null-asserted-optional-chain`).

**Update (2026-02-23):** All 11 errors resolved. Pre-commit hook re-enabled in `.husky/pre-commit`. Current state: 0 errors, 394 warnings. The `no-unsafe-*` rules are downgraded to `warn` in `eslint.config.mjs` until the Supabase typed client is generated. Next step:
```bash
pnpm eslint --max-warnings 0 $(git diff --name-only main...HEAD -- '*.ts' '*.tsx' | \
  while read f; do [ -f "$f" ] && echo "$f"; done | tr '\n' ' ')
```
All touched files must pass with zero errors. Warnings are allowed until
Supabase typed client lands.

### 15.6 tsc Clean

```bash
npx tsc --noEmit
```

tsc is already at 0 errors. Verify it stays there.

### 15.7 PR Ready

- Squash or organize commits into logical groups
- Write PR description with summary of architectural changes
- QA testing notes

**Deferred items to address before or during Phase 15:**
- Supabase typed client (TODO in `src/lib/supabase.ts`, needs DB schema access)
- ~~ESLint pre-commit restore~~ DONE 2026-02-23. Hook re-enabled: blocks on errors, allows warnings. 0 errors, 394 warnings (all `no-unsafe-*` backlog). `no-unsafe-*` rules downgraded to `warn` in `eslint.config.mjs`.
- `next/router` -> `next/navigation` migration (9 files, from Phase 10 deferrals)
- `usePosthogClient` singleton pattern
- `registerCleanup` for remaining `localStorage.removeItem` calls

---

## Parallel: Dependency Updates

> Same branch (`sd/productionize`), same regression window, but orthogonal
> to the DDAU architectural work. Full analysis, compatibility matrices,
> and per-package execution plans are in the sub-plan.

### Steps 1-2: DONE (2026-02-20/21)

- **Step 1 (cleanup + Tier 1):** 7 dead deps removed, misplaced deps fixed,
  all in-range patches applied. `next` 14.2.32->14.2.35, `storybook` 9.1.5->9.1.19,
  `@typescript-eslint/*` 8.43.0->8.56.0. Commit `2a9f6c1`.
- **Step 2 (Tier 2):** 11 packages upgraded across 9 commits. `sharp` 0.34.5,
  `jsdom` 28.1.0, `dotenv` 17.3.1, `lint-staged` 16.2.7, others. Zero regressions.
- Infrastructure: vitest worker limit (prevents OOM), tinypool config fix.
- **Vulnerabilities:** 50 -> 6 (88% reduction). Remaining: 2 Next.js CVEs
  (no 14.x fix, requires Next.js 15), 3 Storybook webpack chain (dev-only).

### Step 3: React 19 + Next.js 15 -- DONE (2026-02-22)

10 commits. react 19.2.4, next 15.5.12. Both CVEs resolved.
Vulnerability count: 6 -> 3 (all remaining dev-only).
Companion upgrades completed:
- `next-themes` 0.3.0 -> 0.4.6
- `react-flatpickr` 3.x -> 4.0.11
- `react-hot-toast` -> `sonner` 2.0.7
- `react-csv` removed (replaced with manual CSV blob + download)
- `@types/react-flatpickr` removed (ships own types)
- 3 utility files moved out of `pages/api/` (Next 15 route validator)
- `MutableRefObject` -> `RefObject` (React 19 deprecation)

Verified 2026-02-22: tsc 0, build clean, zero new test failures.

### Steps 4+: Deferred (post-launch)

Firebase 12 (coordinate with auth cutover), Zod 4, Tailwind 4, Vite 7/Vitest 4,
Storybook 10, reactflow -> @xyflow/react, echarts 6.

See [ddau-dependency-updates.md](ddau-dependency-updates.md) for the full plan
including third-party compatibility matrix, execution phases, and residual
vulnerability inventory.

---

## Current State (2026-02-22)

### Tech Stack

Next.js 15 (Pages Router), React 19, TanStack Query v5, Firebase Auth,
Supabase, Tailwind CSS, react-hook-form + zod, sonner, PostHog,
Vitest, Playwright, Storybook, pnpm

### Architecture (post Phase 13)

- Filter state: `useFilterStore` (localStorage + useSyncExternalStore)
- URL state: standalone nuqs hooks (useQueryState for tz, hours, ws, user, filter params)
- Workstream selection: `useSelectedWorkstreams` hook (URL + TQ cache)
- No context providers remain in the insights data path
- FilterCollapseContext is scoped UI state (kept)
- Service hooks layer: 20 hooks, all clean (zero toasts, zero router, zero storage leaks, zero cross-domain coupling)
- All JSON.parse calls Zod-validated (`.parse()` server-side, `.safeParse()` client-side)
- Branded types: `UserId`, `WorkstreamId`, `TeamId`, `OrganizationId` (compile-time safety, zero runtime cost)
- 16 shared type modules in `src/shared/types/` (barrel index, all duplicates eliminated)
- Zero `enum` declarations in `src/` (all 18 converted to `as const` + union type)
- `typedStorage` (`readStorage`/`writeStorage`) for validated storage access
- Trust boundary utilities: `parseQueryParam`/`requireQueryParam` for API route params
- `getOrCreate` map utility eliminates ~50 non-null assertions

### tsc Errors: 0

tsc is at zero errors as of Phase 11 (commit `764c0a3`). Historical breakdown
at Phase 10 (245 errors) is preserved below for reference.

<details>
<summary>Historical: tsc Error Breakdown at Phase 10 (245 total)</summary>

| Code | Count | Description | Notes |
|------|------:|-------------|-------|
| TS2306 | 39 | Not a module (`next.d.ts`) | Infrastructure noise, resolved in Phase 11 |
| TS2345 | 55 | Argument type mismatch | Mix of touched/untouched files |
| TS2322 | 37 | Type assignment mismatch | Mix of touched/untouched files |
| TS2339 | 26 | Property does not exist | Mostly untyped API responses |
| TS2532 | 18 | Object is possibly undefined | Needs null checks |
| TS2769 | 15 | No overload matches | Library compat (react-flow, zod) |
| TS7006 | 12 | Implicit any on parameter | Needs type annotations |
| TS2304 | 10 | Cannot find name | Missing imports or types |
| Other | 33 | Various | Scattered across codebase |

</details>

### Provider Tree (current)

```
_app.tsx
  NewRelicProvider > WebExtensionProvider > ThemeProvider > GlobalUiProvider
    > AuthStateProvider > PosthogProvider > CompanyProvider
      > QueryClientProvider > TeamsContextProvider
        > AppProvider (duplicate of GlobalUiProvider)
          > {page with getLayout}

DashboardLayout mounts:
  FilterCollapseContext.Provider > {page content}
  (InsightsContextProvider DELETED)
  (MicroworkflowSuggestionsProvider DELETED)

Per settings page:
  BpoProjectContextProvider (DELETED -- hooks standalone)
  UrlClassificationContextProvider (DELETED -- hooks standalone)
  FlyoutProvider (DELETED -- local useState in teams/ and users/)
  SelectedItemsProvider (DELETED -- was dead)
```

---

## Progress Log

### 2026-02-18 -- Phases 0-3 + nuqs migration

**Commit:** `366c723` on `sd/productionize`
**tsc:** 555 errors (unchanged)

- Phases 0-3 complete (all actionable items)
- Phase 4 partial: team/ containers converted
- nuqs installed, `url-params.ts` extended with filter parsers
- DashboardLayout migrated from InsightsContextProvider to nuqs
- Created `useSelectedWorkstreams` hook (URL+cache)
- Removed `useInsightsContext` from 6 containers

### 2026-02-18 -- InsightsContextProvider deleted

**Commits:** `366c723`, `87f32b1` (6 ahead of origin)
**tsc:** 555 -> 531 (-24)

- InsightsContextProvider fully removed
- Created `useFilterStore` hook (useSyncExternalStore + localStorage)
- Migrated all 9 remaining `useInsightsContext()` consumers
- Extracted SystemsBlockContainer, containerized ProcessMiningView
- Deleted 6 dead files (-3,356 lines)

### 2026-02-18 -- God component decomposition (4 components)

**Commits:** `a2fae10`..`bd14ce4` (15 commits)
**tsc:** 531 -> 429 (-102)
**Branch diff:** 264 files, +17,423/-23,124

- SystemsBlock: 1017 -> ~530 lines, 5 useEffects eliminated
- OpportunitiesV2Block: 500 -> 105 lines (DiscoverV5Block), zero hooks
- ProcessMiningView: 4655 -> ~1547 lines, 6 useEffects eliminated
- productivity.tsx: 5860 -> 1284 lines (78% reduction), 15 useEffects eliminated

### 2026-02-18 -- Phase 5 partial (3 commits)

**Commits:** `e36707d`, `2573361`, `083dfb7`
**tsc:** 429 -> ~360

- Dead code deletion (~8,500 lines)
- 5 real bug fixes
- localStorage consolidation, debug log removal

### 2026-02-18/19 -- Phase 6.1-6.4 (3 commits)

**Commits:** `fea6040`, `02c848e`, `5c32d86`
**tsc:** 360 -> 332 (-28)

- 6.1: 12 dead files, ~20 dead exports, 2 dead hooks, dead filter tree
- 6.2: 4 broken spec files fixed
- 6.3: 10 useEffects eliminated, 3 timer leaks fixed, `useHydrated()` hook
- 6.4: ~15 eslint-disable directives, ~20 console statements, `tsconfig.eslint.json`

### 2026-02-19 -- Template discipline codified

**No commits (skills repo, not app repo)**

- Added "Template least-power (JSX discipline)" to skills README (9 rules)
- Updated audit/refactor/build skills to enforce template discipline
- Created `/flatten-jsx-template` and `/extract-shared-presentational` skills

### 2026-02-19 -- Phase 7: Structural decomposition (6 commits)

**Commits:** `c253031`, `fe0ccb3`, `fa3dafe`, `54a2e31`, `671efad`, `818fe84`
**tsc:** 332 -> 292 (-40)

- 7.1: OpportunitiesV2Block 2388->1273 ln, 7 components extracted, 56 tests
- 7.2: CompanySwitchModal deleted (1537 lines dead code)
- 7.3: Systems feature -- SummaryStrip, SelectionSummary, formatNumber
- 7.4: ActivitiesTable -- template flatten + badge dedup
- 7.5: RealtimeFilters -- dead types + unused props
- 7.6: SignedInPageShell -- dead hooks + barrel exports

### 2026-02-19 -- Phase 8: Area-by-area DDAU (3 commits)

**Commits:** `0db96d8`, `2668313`, `82561ee`
**tsc:** 292 (unchanged)

- 8.1: teams/ -- FlyoutProvider eliminated, useRouter replaced with Link
- 8.2: users/ -- FlyoutProvider eliminated, circular import fixed
- 8.4: Account + OpportunitiesV2 -- useAuthState hoisted, useCompanyScope lifted

### 2026-02-19 -- Phase 9: Type safety + lint (3 commits)

**Commits:** `24cc8b0`, `3c38709`, `a6bf9fb`
**tsc:** 292 -> 246 (-46)

- 9.1: 43 unused variables/imports deleted (21 files)
- 9.2: 3 as-any casts replaced with type guards + enums (2 files)
- 9.3-9.4: ESLint auto-fix on 36 files (style-only)

### 2026-02-19 -- Phase 10: Effect + cast cleanup (1 commit)

**Commit:** `fec39ef`
**tsc:** 246 -> 245 (-1)

- 8 exhaustive-deps suppressions annotated with justifications
- 12 files: || [] -> ?? [] conversions
- Deferred: next/router migration, usePosthogClient singleton, registerCleanup

### 2026-02-20 -- Phase 11: Fix-all audit (109 items, 35+ commits)

**Baseline:** `0106416` (244 tsc errors)
**Final:** `764c0a3`
**tsc:** 244 -> 0 (-244)

- 109 audit findings fixed across 12 sub-phases (0: dead code, 1: shared utils,
  2: service hooks, 3: providers, 4: containers, 5: useEffects, 6: timers,
  7: DDAU leaves, 8: god components, 9: templates, 10: pattern extraction,
  11: debug cleanup, 12: storage/URL corrections)
- 3 items closed as no-ops (already clean or file removed)
- ~65 skill invocations + ~40 manual edits
- tsc reached zero for the first time in project history

### 2026-02-21 -- Phase 12: Type refactor (12 commits)

**Commits:** `cb317e6`..`9015438`
**tsc:** 0 (maintained)

- Track A: 16 domain modules in src/shared/types/, barrel index, all duplicates
  eliminated. insightsContext/types.ts decomposed (79+ types). 11 skills updated.
  4 sub-commits for Phase 2 (102+90+41+8 files)
- Track B: 115 `any` gone (productivity), catch clauses standardized, guards
  fixed (isApiError, isUser, isObjectType->hasKeys), ~81 non-null assertions
  eliminated (getOrCreate), trust boundary validation (fetchApi schema,
  typedStorage, queryParams)
- Track C: 4 branded IDs (UserId 155 calls, WorkstreamId 39, TeamId+OrgId 14),
  18 enums converted to as-const, zero enum in src/

### 2026-02-22 -- Phase 13: Remaining audit fixes (7 agents, 2 waves)

**Commits:** `7d5f071` (Agent 5), `bbc5ec8` (all others)
**tsc:** 0 (maintained)
**Files:** 50 changed, +2902/-2207

- Wave 1: Chat.tsx return 174->94, SystemsTab 1458->452, ActivitiesTable
  1050->476, analysis/ cleanup + MicroworkflowsBlockWrapper moved
- Wave 2: useAuthState lifted from 3 leaves, all server JSON.parse Zod-validated
  (.parse), all client JSON.parse Zod-validated (.safeParse/readStorage)
- 3 useEffects eliminated, 1 converted to useLayoutEffect
- flyoutContext.tsx deleted (dead code)

### 2026-02-22 -- Phase 12b: Production `any` sweep (8 agents, 2 waves)

**tsc:** 0 (maintained)

- Wave 1 (data layer): productivity data types, server API routes, explorer
  data, shared types/utilities. ~93 `any` eliminated across ~33 files.
- Wave 2 (UI consumers): productivity UI (echarts), analysis/filters,
  TanStack ColumnDef/Table, relay/teams/misc. ~85 `any` eliminated across ~24 files.
- Agent 3 recovery: explorer changes lost during parallel writes, re-ran.
- 2 justified `any` retained with eslint-disable + justification comments.
- 34 `any` remain in test/spec/mock files (Phase 15.2 scope).

### 2026-02-23 -- Phase 15.0: Fix failing tests + vitest hang

**tsc:** 0 (maintained)
**Tests:** 75/75 pass (was 54/75), exits in ~4s (was hanging indefinitely)
**ESLint:** 0 errors on all 7 touched files

- 21 test failures fixed across 6 spec files (5 root causes)
- Vitest hang resolved (fetchMocker cleanup + teardownTimeout)
- TableFilter.spec.tsx fully rewritten for new DDAU component API (10 tests)
- React 19 `expect.anything()` incompatibility discovered and fixed (6 sites)
- Infrastructure: tsconfig.eslint.json include fix, vitest.config.mts cleanup
- 1 `as any` in InsightsFilters.spec.tsx replaced with typed assertion

### 2026-02-23 -- Phase 15.5b: ESLint pre-commit hook restored

**tsc:** 0 (maintained)
**ESLint:** 0 errors, 394 warnings (pre-commit hook active)

- All 11 remaining ESLint errors resolved (see Phase 15.5 section)
- ESLint pre-commit hook re-enabled in `.husky/pre-commit`
- Hook blocks on errors, allows warnings
- `no-unsafe-*` rules downgraded to `warn` in `eslint.config.mjs`
- TODO: add `--max-warnings 0` once the `any` backlog reaches 0

### 2026-02-23 -- Phase 15.5: ESLint config cleanup

**tsc:** 0 (maintained)
**ESLint:** 454 errors -> 11 errors + 396 warnings

- Added `.next/**/*` to ESLint ignores (eliminates 4548 phantom build errors)
- Ran `--fix` on auto-fixable rules (32 errors fixed across ~15 files)
- Downgraded `no-unsafe-*` (6 rules) + `no-explicit-any` to `warn` (393 errors
  from untyped Supabase client cascade). Each rule has a TODO comment in
  `eslint.config.mjs` referencing `src/lib/supabase.ts` for revert once
  typed client is generated.
- 11 remaining errors are non-any issues requiring manual fixes

---

## Remaining Work

Deferred items collected from all phases. These should be addressed before
or during Phase 15 (PR readiness).

| Item | Source | Notes |
|------|--------|-------|
| ~~React 19 + Next.js 15~~ | ~~Dep updates (Step 3)~~ | DONE 2026-02-22. react 19.2.4, next 15.5.12. Both CVEs resolved. |
| ~~sonner swap (react-hot-toast)~~ | ~~Dep updates (Step 3)~~ | DONE 2026-02-22. sonner 2.0.7. |
| ~~react-flatpickr 4, next-themes 0.4.6~~ | ~~Dep updates (Step 3)~~ | DONE 2026-02-22. |
| ~~react-csv removal~~ | ~~Dep updates (Step 3)~~ | DONE 2026-02-22. Manual CSV blob + download. |
| Supabase typed client | Phase 12 (B5.1) | Needs DB schema access. TODO in `src/lib/supabase.ts`. Once generated, revert 10 `no-unsafe-*`/`no-explicit-any` rules from `warn` back to `error` in `eslint.config.mjs` (marked with TODO comments). |
| ~~ESLint pre-commit restore~~ | ~~Phase 15.5~~ | DONE 2026-02-23. Hook re-enabled: blocks on errors, allows warnings. 0 errors, 394 warnings (all `no-unsafe-*` backlog). `no-unsafe-*` rules downgraded to `warn` in `eslint.config.mjs`. |
| ~~ESLint remaining 11 errors~~ | ~~Phase 15.5b~~ | DONE 2026-02-23. All errors resolved. 394 warnings remain (all `no-unsafe-*`, downgraded to `warn`). TODO: add `--max-warnings 0` once `any` backlog reaches 0. |
| `next/router` -> `next/navigation` | Phase 10 | 9 files still using Pages Router API. Absorbed by Next.js 15 migration |
| `usePosthogClient` singleton | Phase 10 | Pattern improvement for PostHog client access |
| `registerCleanup` calls | Phase 10 | Remaining `localStorage.removeItem` calls outside cleanup registry |
| Mock type factories | Phase 15 (15.1) | Test infrastructure for `useFilterStore`, `useSelectedWorkstreams`, etc. |
| Browser testing | Phase 15 (15.3) | Per [ddau-refactor-testing.md](ddau-refactor-testing.md) |
| PR readiness | Phase 15 (15.7) | Squash commits, write description, QA notes |

---

## Ongoing

[ddau-codebase-audit.md](ddau-codebase-audit.md) is the iterative verification
tool. It is a repeatable runbook (not a plan with work items) that defines 10
sections of automated checks covering all architectural invariants: container
boundaries, useEffect classification, type safety, template discipline, service
hook purity, cross-domain coupling, dead code, timer cleanup, runtime validation,
and storage ownership.

**How to use:** Give the file as context to an agent. It runs all checks
(grep/glob/wc), classifies each finding, and produces a dated report in
`~/github/next-gen-atlassian/tmp-audits/YYYY-MM-DD-audit.md`. Fix findings,
re-run. The summary table is the convergence metric -- target is zero violations
across all sections.

**When to run:** After Phase 15 work completes, and iteratively until convergence.
Can also be run at any time to verify no regressions.
