# Postmortem Recommendations Implementation Plan

> Created: 2026-03-13
> Branch: sd/productionize
> Source: ~/postmortem/2026-03-13-audit-remediation-loop.md (16 recommendations)
> Status: COMPLETE
> Integration scope: none (process + skill infrastructure only)
> Cleanup file: ~/plans/pm-recs-26-03-13-cleanup.md

## Overview

Implements all 16 recommendations from the audit-remediation loop postmortem.
Changes span three domains: audit protocol (`~/audits/CLAUDE.md`), orchestration
protocol (`~/.claude/CLAUDE.md` + `orchestrate-audit-fixes` skill), and the
skill system (`.claude/skills/`). No production code changes -- this is
infrastructure only.

## Prerequisites

The working tree has 6 modified files that must be committed or stashed before
execution begins:

```
.claude/skills/README.md
CLAUDE.md
docs/integration-testing.md
scripts/run-integration.sh
src/shared/hooks/useFeatureFlags/utils/featureFlagsCache/featureFlagsCache.spec.ts
src/ui/page_blocks/dashboard/team/ProductivityContainer.tsx
```

## Dependencies

```
P00a (audit protocol)       -- standalone, no deps
P00b (orchestration protocol) -- standalone, no deps
     \
      \  both must complete before P01
       \
P01 (build-api-handler)    -- depends on P00a/P00b for updated protocol context
  |
P02 (refactor-api-handler) -- references P01 patterns
  |
P03 (AST verify all builds) -- must follow P01 so new skill gets same treatment
  |
P04 (rule additions + ESLint) -- independent of P03 content, but sequential for clean tree
  |
P05 (build-module)         -- standalone after P00b
  |
P06 (sync + verify)        -- must be last
```

P00a and P00b can run in parallel (different files, different directories).
All remaining prompts are strictly sequential (same working tree).

## Prompt Sequence

| #    | File                                   | Domain          | Recommendations | Est. Time |
| ---- | -------------------------------------- | --------------- | --------------- | --------- |
| P00a | pm-recs-P00a-audit-protocol.md         | ~/audits/       | A-1..A-6        | 45 min    |
| P00b | pm-recs-P00b-orchestration-protocol.md | ~/.claude/ + UF | O-1..O-6        | 45 min    |
| P01  | pm-recs-P01-build-api-handler.md       | UF skills       | S-1             | 2-3 hr    |
| P02  | pm-recs-P02-refactor-api-handler.md    | UF skills       | S-2             | 2 hr      |
| P03  | pm-recs-P03-ast-verify-build-skills.md | UF skills       | S-3             | 2-3 hr    |
| P04  | pm-recs-P04-rule-additions-eslint.md   | UF + config     | S-4..S-7        | 1.5 hr    |
| P05  | pm-recs-P05-build-module.md            | UF skills       | S-8             | 2 hr      |
| P06  | pm-recs-P06-sync-verify.md             | UF + ~/.claude/ | --              | 30 min    |

## Verification Commands

For P00a and P00b (no code, markdown only):

- Read the modified file and confirm all changes are present

For P01-P05 (UF repo, skill + config files):

```bash
pnpm tsc --noEmit          # skill files don't affect tsc, but verify no regressions
pnpm build                 # verify build still passes
npx eslint . --max-warnings 0   # P04 adds ESLint rule, must pass after
```

For P06 (sync + final):

```bash
pnpm tsc --noEmit && pnpm build && npx eslint . --max-warnings 0
diff -rq ~/github/user-frontend/.claude/skills/ ~/.claude/skills/ --exclude='.git'
```

## Verification Checklist

| #    | Agent Ran Verify?  | Orchestrator Ran Verify? | Results Match? | PASS/FAIL |
| ---- | ------------------ | ------------------------ | -------------- | --------- |
| P00a | Yes (all present)  | Yes (7/7 grep confirmed) | Yes            | PASS      |
| P00b | Yes (all present)  | Yes (8/8 grep confirmed) | Yes            | PASS      |
| P01  | Yes (all present)  | Yes (6/6 grep confirmed) | Yes            | PASS      |
| P02  | Yes (all present)  | Yes (4/4 grep confirmed) | Yes            | PASS      |
| P03  | Yes (10/10)        | Yes (10/10 grep confirm) | Yes            | PASS      |
| P04  | Yes (all present)  | Yes (tsc+eslint clean)   | Yes            | PASS      |
| P05  | Yes (all present)  | Yes (3/3 grep confirmed) | Yes            | PASS      |
| P06  | N/A (orchestrator) | Yes (all checks pass)    | N/A            | PASS      |

## Progress

| #    | Status | HEAD     | Notes                                                           |
| ---- | ------ | -------- | --------------------------------------------------------------- |
| P00a | PASS   | --       | 6 sections added to ~/audits/CLAUDE.md                          |
| P00b | PASS   | --       | 8 sections added across ~/.claude/CLAUDE.md + SKILL.md          |
| P01  | PASS   | 68db67da | 416-line SKILL.md, README + CLAUDE.md updated                   |
| P02  | PASS   | d58ecdb5 | 450-line SKILL.md, README + CLAUDE.md updated                   |
| P03  | PASS   | ddcd2829 | 9 skills modified, 10/10 have AST checks                        |
| P04  | PASS   | cca937c0 | 16 console violations fixed, no-console error, sg replaces grep |
| P05  | PASS   | 37bd17cc | 369-line SKILL.md + 8126a29c grep-to-sg fix                     |
| P06  | PASS   | 8126a29c | tsc+eslint clean, 11 build skills with AST, sync clean          |
