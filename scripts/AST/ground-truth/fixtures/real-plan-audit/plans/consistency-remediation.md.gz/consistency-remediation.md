# Consistency Remediation

> Created: 2026-03-08
> Branch: sd/productionize
> Status: COMPLETE
> Completed: 2026-03-08
> Integration scope: final-only
> HEAD: 1d2708eabb7ccd74b4e3f358aa737ac477bd88d0
> Final validation: 2026-03-08 -- 16/16 assertions PASS
> Integration tests: deferred to playwright-hardening sequence

Normalize the codebase so it reads like one person wrote it. Sixteen items
across seven prompts, targeting function style, naming, page structure,
service hooks, containers, JSDoc, and documentation.

## Items

| # | Item | Type | Files | Prompt | Status | Validated |
|---|------|------|-------|--------|--------|-----------|
| B1 | Function style: normalize to `export function` | migration | ~210 | 05 | done | PASS (17 remain, all branded type constructors -- intentional exception) |
| B2 | Directory naming: document convention, fix minor violations | docs | ~5 | 06 | done | PASS |
| B3 | Feature flag page guard: move from pages to containers | migration | ~8 | 03 | done | PASS |
| B4 | Mutation hook options forwarding: add options param | migration | ~5 | 04 | done | PASS |
| B5 | API path sourcing: remove registry helpers, hardcode in hooks | migration | ~6 | 04 | done | PASS |
| B6 | Context default values: throw on null (Layout, WebExtension) | bug-fix | ~4 | 01 | done | PASS |
| B7 | Container JSX: extract inline layout to Block components | structural | ~4 | 04 | done | PASS |
| B8 | urls_registry.ts -> urlsRegistry.ts | rename | ~40 | 02 | done | PASS |
| B9 | privaryPolicyUrl typo -> privacyPolicyUrl | bug-fix | ~3 | 01 | done | PASS |
| B10 | isNaN -> Number.isNaN in formatDuration | migration | ~1 | 01 | done | PASS |
| B11 | Misleading names: teamsContext -> teamsUtils, NewRelicProvider -> NewRelicRouteTracker | rename | ~8 | 02 | done | PASS |
| B12 | 404.tsx: use PosthogContext instead of direct posthog import | migration | ~1 | 01 | done | PASS |
| B13 | JSDoc density: strip outlier verbosity, add minimum to bare exports | docs | ~15 | 06 | done | PASS |
| B14 | Page `<Head>` nesting: normalize across all pages | migration | ~6 | 03 | done | PASS |
| B15 | MetadataDetailsContent: remove gratuitous default export | dead-code | ~1 | 01 | done | PASS |
| B16 | Loose files in shared/ui: move to directories or add to barrel | structural | ~8 | 02 | done | PASS |

## Dependency Graph

```
01 (cosmetic + provider fixes)
    |
    v
02 (naming + structural)
   / \
  v   v
03   04  (page structure | service + container -- independent)
  \ /
   v
05 (function style normalization)
    |
    v
06 (JSDoc + conventions documentation)
    |
    v
07 (final validation)
```

01 must precede 02: prompt 01 edits urls_registry.ts (typo), prompt 02 renames it.
02 must precede 03-04: prompt 02 renames files/directories, later prompts need stable paths.
03 and 04 are independent but both must precede 05.
05 must precede 06: function style must be final before documenting conventions and normalizing JSDoc.
07 validates the cumulative result.

## Prompt Sequence

| # | Prompt | Items | Prerequisite | Est. Files | Mode |
|---|--------|-------|-------------|------------|------|
| 01 | Cosmetic + provider fixes | B6, B9, B10, B12, B15 | none | ~10 | auto |
| 02 | Naming + structural normalization | B8, B11, B16 | 01 | ~55 | manual |
| 03 | Page structure normalization | B3, B14 | 02 | ~15 | auto |
| 04 | Service + container fixes | B4, B5, B7 | 02 | ~15 | manual |
| 05 | Function style normalization | B1 | 03, 04 | ~210 | manual |
| 06 | JSDoc + conventions documentation | B2, B13 | 05 | ~30 | auto |
| 07 | Final validation | all | 06 | 0 (read-only) | auto |

Prompt 05 is the largest. If the work agent runs out of context, split into
05a (shared/ + ui/components/ + ui/providers/) and 05b (ui/page_blocks/).

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| 01 | N/A (scope: none) | N/A | N/A | |
| 02 | | | | |
| 03 | | | | |
| 04 | | | | |
| 05 | | | | |
| 06 | | | | |
| 07 | | | | |
