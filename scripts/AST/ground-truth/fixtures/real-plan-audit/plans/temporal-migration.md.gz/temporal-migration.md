# Migration: Replace Date/dayjs with Temporal API

> Replace all Date/dayjs usage with the Temporal API (via temporal-polyfill).
> Eliminate the fake-UTC convention, replace numeric timezone offsets with
> IANA strings, expand the timezone dropdown to all IANA timezones, delete
> isDaylightTime/getNthSundayOfMonth, and add timezone support to the 5
> UTC-only domains.
>
> Created: 2026-03-16
> Branch: sd/productionize
> Complexity: D7 S8 Z8 = 7.7
> Duration: F5 C3 = 17h (9-24h)
> Nearest: Selection Migration (#9, 8.0), UF Phase 2: Service Hooks (#19, 6.7)
> Integration scope: final-only (production code changes; PW intercept audit needed for timezone param format change)
> Pre-flight: CONDITIONAL 2026-03-16 by pre-flight-plan-audit
> Pre-flight findings: 0 blockers, 1 warning (annotated in P03: systemLatency.ts -> systems.ts)
> Pre-flight history: CONDITIONAL (2026-03-16) -- F3 fixed (P04 logic file paths), F1 fixed (Mode column added).
> Revised: 2026-03-16 -- added P-pre (green baseline specs) and P00.5 (red tests). 8 -> 10 prompts. Independent estimate: 14h center + 3h for new prompts = 17h.

## Current State

dayjs (with UTC plugin) is the sole date library. 27 files import dayjs,
62 raw `new Date()` calls in production code. Timezone is modeled as a
numeric hour offset in the UI, converted to minutes for the BFF. DST
detection is hardcoded to US rules. 5 domains have no timezone support.

```bash
# dayjs imports
rg "from 'dayjs'" src/ --type ts -l | wc -l
# Current: ~27

# Raw Date usage
rg 'new Date\(' src/ --type ts -l | grep -v '\.spec\.' | grep -v '__tests__' | wc -l
# Current: ~39

# Timezone type is number
rg 'timezone.*number' src/shared/types/filterFormStates.ts
# Current: 3 interfaces with timezone: number

# isDaylightTime exists
ls src/shared/utils/date/isDaylightTime/isDaylightTime.ts
# Current: exists
```

## Target State

All date/time handling uses Temporal (via temporal-polyfill). dayjs is
removed from dependencies. Timezone dropdown uses IANA strings with full
timezone list. All 10 insight domains support timezone. The fake-UTC
convention is eliminated.

```bash
# After migration:
rg "from 'dayjs'" src/ --type ts -l | wc -l
# Target: 0

rg "from 'temporal-polyfill'" src/ --type ts -l | wc -l
# Target: >0 (shared module re-exports)

rg 'timezone.*number' src/shared/types/filterFormStates.ts
# Target: 0 (all timezone: string)

ls src/shared/utils/date/isDaylightTime/ 2>&1
# Target: "No such file or directory"

rg 'formatTimezone|formatDateWithOffset' src/ --type ts -l | wc -l
# Target: 0
```

## Inventory

### Phase 0a: Green baseline specs (P-pre)

| # | Spec file to create | Tests for | Complexity |
|---|---------------------|-----------|-----------|
| 1 | src/server/productivity/applyTimezone.spec.ts | chTimestampToUtc, applyTimezone, toOffsetISOString | mechanical |
| 2 | src/server/productivity/getFormattedDates.spec.ts | getFormattedDates | mechanical |
| 3 | src/server/productivity/processRealtimeEvents.spec.ts | processRealtimeEvents (8 scenarios) | contextual |
| 4 | src/server/handlers/.../getDayStats.logic.spec.ts | classifyAndShiftSpans, computeTtm, computeAuxStats, buildOutputSpans | contextual |
| 5 | src/server/handlers/.../getTtmForDays.logic.spec.ts | spanDateKey, convertDaysToClickHouseFormat, mergeSpanResults | contextual |
| 6 | src/shared/constants/filters.spec.ts | getTimezoneItems (winter, summer, no-arg) | mechanical |

### Phase 0b: Foundation (P00)

| # | File | What | Complexity |
|---|------|------|-----------|
| 1 | package.json | Add temporal-polyfill | mechanical |
| 2 | src/shared/utils/temporal/index.ts | Create shared Temporal module | contextual |
| 3 | src/shared/utils/temporal/temporal.spec.ts | Tests for helpers | mechanical |

### Phase 0c: Red tests (P00.5)

| # | Spec file | What | Complexity |
|---|-----------|------|-----------|
| 1 | calculatePeriodEnds.spec.ts | Add DST transition it.fails() | mechanical |
| 2 | applyTimezone.spec.ts | Add it.fails() for IANA input, toWallClock | mechanical |
| 3 | processRealtimeEvents.spec.ts | Add it.fails() for IANA timezone | mechanical |
| 4 | filters.spec.ts | Add it.fails() for IANA values, full list | mechanical |
| 5 | getNearestTimezoneValue.spec.ts | Add it.fails() for IANA return | mechanical |
| 6 | insightsQueryParams.spec.ts | Add it.fails() for IANA timezone output | mechanical |
| 7 | temporal.spec.ts | Add test.todo() stubs for toJSDate, migrateNumericTz | mechanical |

### Phase 1: Centralized date utilities (P01)

| # | File | What | Complexity |
|---|------|------|-----------|
| 1 | src/shared/utils/date/formatDate/formatDate.ts | dayjs -> Temporal | contextual |
| 2 | src/shared/utils/date/getDaysDiff/getDaysDiff.ts | dayjs -> Temporal | mechanical |
| 3 | src/shared/utils/date/getStartEndTimes/getStartEndTimes.ts | dayjs -> Temporal | contextual |
| 4 | src/shared/utils/date/validateDateRange/validateDateRange.ts | dayjs -> Temporal | mechanical |
| 5 | src/shared/utils/table/createDateSorter/createDateSorter.ts | dayjs -> Temporal | mechanical |
| 6 | src/ui/components/8flow/charts/utils/time/time.ts | dayjs -> Temporal | contextual |

### Phase 2: Timezone model (P02)

| # | File | What | Complexity |
|---|------|------|-----------|
| 1 | src/shared/constants/filters.ts | IANA dropdown with Intl.supportedValuesOf | contextual |
| 2 | src/shared/types/filterFormStates.ts | timezone: number -> string | mechanical |
| 3 | src/shared/url-params.ts | parseAsFloat -> parseAsString for tz | mechanical |
| 4 | src/shared/utils/timezone/ | Rewrite getNearestTimezoneValue for IANA | contextual |
| 5 | src/shared/utils/date/isDaylightTime/ | DELETE entire directory | mechanical |
| 6 | src/shared/utils/date/getNthSundayOfMonth/ | DELETE entire directory | mechanical |
| 7 | src/shared/utils/insightsQueryParams/shared.ts | Delete formatTimezone | mechanical |

### Phase 3: Date pipeline (P03)

| # | File | What | Complexity |
|---|------|------|-----------|
| 1 | src/shared/utils/calculatePeriodEnds/calculatePeriodEnds.ts | Rewrite with Temporal + timezone param | contextual |
| 2 | src/shared/utils/calculatePeriodEnds/calculatePeriodEnds.spec.ts | Convert it.fails() to passing | contextual |
| 3 | src/shared/utils/insightsQueryParams/*.ts | Update all param builders for IANA tz | mechanical |

### Phase 4: BFF handlers (P04)

| # | File | What | Complexity |
|---|------|------|-----------|
| 1 | src/server/productivity/applyTimezone.ts | Rewrite/simplify with Temporal | contextual |
| 2 | src/server/productivity/getFormattedDates.ts | Temporal for day iteration | mechanical |
| 3 | src/server/productivity/processRealtimeEvents.ts | Temporal for timestamp handling | contextual |
| 4 | src/pages/api/users/data-api/productivity/getTeamRealtimeStats.ts | Accept IANA tz | contextual |
| 5 | src/pages/api/users/data-api/productivity/getHostTime.ts | Accept IANA tz | contextual |
| 6 | src/pages/api/users/data-api/productivity/getTtmForDays.ts | Accept IANA tz | contextual |
| 7 | src/pages/api/users/data-api/productivity/getDayStats.ts | Accept IANA tz | contextual |

### Phase 5: UTC-only domains get timezone (P05)

| # | Domain | Files | Complexity |
|---|--------|-------|-----------|
| 1 | Workstream Analyzer | query params + container | contextual |
| 2 | Systems Analysis | query params + container | contextual |
| 3 | Relay Usage | query params + container | contextual |
| 4 | Favorite Usage | query params + container | contextual |
| 5 | Opportunities | query params + container | contextual |

### Phase 6: Remaining cleanup (P06)

| # | Category | Count | Complexity |
|---|----------|-------|-----------|
| 1 | Remaining new Date() in CRUD routes | ~14 | mechanical |
| 2 | Remaining dayjs imports | ~15 | mechanical |
| 3 | Remove dayjs from package.json | 1 | mechanical |

### Phase 7: Verification and docs (P07)

| # | Task | Complexity |
|---|------|-----------|
| 1 | Full test suite run | mechanical |
| 2 | Update timezone-handling.md | contextual |
| 3 | Dead code pass (standing element) | mechanical |
| 4 | Docs grep (standing element) | mechanical |
| 5 | PW intercept audit (standing element) | contextual |

## Migration Phases

| # | Phase | Prompt | Mode | What | Status |
|---|-------|--------|------|------|--------|
| 0a | Green baseline | P-pre | Auto | Specs for untested BFF code and filters | complete (732d15e9) |
| 0b | Foundation | P00 | Auto | Install polyfill, create shared module | complete (1e1e6974) |
| 0c | Red tests | P00.5 | Auto | it.fails() for target Temporal behavior | complete (59f0eed0) |
| 1 | Date utilities | P01 | Auto | Replace dayjs in centralized utils | complete (7f22b65b) |
| 2 | Timezone model | P02 | Manual | IANA dropdown, types, URL params | complete (63211e55) |
| 3 | Date pipeline | P03 | Auto | Rewrite calculatePeriodEnds, query params | complete (13605718) |
| 4 | BFF handlers | P04 | Auto | Accept IANA tz, rewrite applyTimezone | complete (36192f4d) |
| 5 | UTC-only domains | P05 | Auto | Add timezone to 5 domains | complete (e2a52b41) |
| 6 | Remaining cleanup | P06 | Manual | Replace remaining Date/dayjs, remove dep | complete (2c15d6ea..4689c03e) |
| 7 | Verification | P07 | Manual | Tests, docs, dead code, PW audit | complete (320cb6a0..27b78ec3) |

## Red Test Verification

Each migration prompt (P01-P07) must check whether it turns any
`it.fails()` tests green. When a red test starts passing, change
`it.fails()` to `it()` and remove any `@ts-expect-error` annotations.
See the mapping table in the P00.5 prompt for which tests correspond
to which prompt.

## Dependency Graph

```
P-pre (green baseline) ──┐
                          ├──> P00.5 (red tests)
P00 (foundation) ────────┘        |
                                  v
                          P01 (date utilities)
                                  |
                                  v
                          P02 (timezone model)
                                  |
                                  v
                          P03 (date pipeline)
                                  |
                                  v
                          P04 (BFF handlers)
                                  |
                            +-----+-----+
                            |           |
                            v           v
                          P05         P06 (independent after P04)
                            |           |
                            +-----+-----+
                                  |
                                  v
                          P07 (verification + docs)
```

Note: P-pre and P00 are independent of each other and could run in
parallel. P00.5 depends on both (needs P-pre's spec files and P00's
Temporal module for assertions).

## Standing Elements

| Element | Triggered? | Placement |
|---------|-----------|-----------|
| TYPE SAFETY SWEEP | No | -- |
| DEAD CODE PASS | Yes (migration) | P07 |
| IMPORT BOUNDARY CHECK | Yes (cross-domain) | P00 (pre-check) |
| NUQS AUDIT | Yes (P02 changes tz URL param) | P02 |
| TEST INFRA PREP | No | -- |
| DOCS GREP | Yes (migration) | P07 |
| FLAKY TEST INVENTORY | No | -- |
| TEST GAP INVENTORY | No | -- |
| PW INTERCEPT AUDIT | Yes (BFF timezone param format change) | P07 |

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| P-pre | | | | |
| P00 | | | | |
| P00.5 | | | | |
| P01 | | | | |
| P02 | | | | |
| P03 | | | | |
| P04 | | | | |
| P05 | | | | |
| P06 | | | | |
| P07 | | | | |
