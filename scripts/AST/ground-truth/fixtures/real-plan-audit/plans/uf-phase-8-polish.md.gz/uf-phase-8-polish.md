# Phase 8: Polish + Ship

> Production-ready. Visually matches current production. Dependencies
> upgraded to NGA parity.

## Prerequisites

- Phase 7 complete (60%+ coverage, all tests passing, E2E green)

## Exit Criteria

- `pnpm build` clean
- `pnpm tsc --noEmit` clean
- `pnpm test` -- 0 failures
- `pnpm e2e:test:local` passes
- All shared features match production visually (verified by bug bash)
- React 19 + Next.js 15 + all breaking dep upgrades complete
- PR ready for review

## Skill Protocol

- `/migrate-npm-package` for each breaking dep upgrade (steps 8.1-8.4)
- `/audit-npm-deps` to identify dead or misplaced deps (step 8.6)
- `/migrate-page-to-ssr` when SSR migration is unblocked (step 8.11, deferred)
- Exception: next.config.js changes, documentation consolidation, and bug bash are manual

## Upgrade Strategy

> **Caveat**: UF is not NGA. NGA's dep upgrade plan (`archive/ddau-dependency-updates.md`)
> used a 5-tier system: (1) dead deps, (2) in-range patches, (3) minimal-change
> upgrades, (4) substantial migrations. UF should follow the same tier approach
> rather than upgrading everything at once. Run `/audit-npm-deps` first to get
> UF's actual dep tree, then tier-classify before starting.
>
> NGA also verified React 19 compatibility for 12+ third-party libraries before
> upgrading. UF needs the same verification -- check that ECharts, Headless UI,
> react-hook-form, TanStack Query/Table, nuqs, reactflow, and Storybook all
> have React 19 compatible versions.

### Deferred upgrades -- PROMOTED to Phase 8.13 (ALL DONE)

**DONE** (2026-03-02). 5 commits, HEAD `de4594fb`. 180 specs, 2281 tests, 0 tsc errors, 0 ESLint warnings.

| Package | From | To | Status |
|---------|------|----|--------|
| ESLint | 9.32.0 | 10.0.2 | **DONE**. typescript-eslint 8.56.1, eslint-plugin-react-hooks 7.0.1, eslint-plugin-jest 29.15.0, eslint-plugin-unused-imports 4.4.1, eslint-plugin-storybook 10.2.14. Removed dead eslint-plugin-vitest. |
| Vite | 6.4.1 | 7.3.1 | **DONE**. @vitejs/plugin-react 4.5.0->5.1.4. |
| Vitest | 3.1.4 | 4.0.18 | **DONE**. @vitest/coverage-v8 3.1.4->4.0.18. |
| ECharts | 5.6.0 | 6.0.0 | **DONE**. echarts-for-react 3.0.2->3.0.6. |
| Storybook | 9.0.18 | 10.2.14 | **DONE**. @storybook/nextjs->@storybook/nextjs-vite automigration. @chromatic-com/storybook 4->5. |
| Tailwind CSS | 3.4.17 | 4.2.1 | **DONE**. autoprefixer removed, @tailwindcss/postcss added. |
| ~~reactflow~~ | -- | -- | **REMOVED** in 8.6 (zero imports). No upgrade needed. |

## 8.0: Audit Gap Items

> Source: Two full codebase audits (2026-03-01 14:36 and 21:05). See
> `~/plans/uf-audit-gap-addendum.md` for full analysis. Items numbered
> 8.0a-8.0g in the master roadmap. These are all mechanical cleanup
> that de-risks the main Phase 8 work (dep upgrades, bug bash).

| Item | Status | Summary |
|------|--------|---------|
| 8.0a | **DONE** (2026-03-02) | Dead code sweep. 7 commits, ~1900 lines deleted. |
| 8.0-pre | **DONE** (2026-03-02) | Fix 5 bugs: 2 ghost-state (try/finally), 1 missing try/catch (AddTeamForm + onError handler), 2 cache invalidation (teams + users query keys). |
| 8.0b | **DONE** (2026-03-02) | Mock handler: schema fixes, delay removal, 18 query + 15 mutation routes added. 411 lines, 38 routes. |
| 8.0c | **DONE** (2026-03-02) | Cross-domain coupling fixes. 6 commits. 25 -> 9 remaining (3 provider->page_blocks + 4 shared->providers infra hooks + 2 components->page_blocks SignedInPageShell exception). Fixed: Header.tsx, insightsContext imports, getStartEndTimes, MetadataPopupContent, handleClickGlossary, getCommonGroupIds, CSV_FILENAME_PREFIX, e2e constants, CSS typo N1, createTeam cache invalidation N2, removeRelatedInsights N3. |
| 8.0d | **DONE** (2026-03-02) | localStorage migration: 25 raw calls migrated to typedStorage, 4 exempt (featureFlagsCache AES-GCM). Constants moved to shared. Trust boundaries fixed: useChatApi (Zod on all paths), router.query.id (proper union handling), Role[] (isRole guard). Remaining: storage.ts permissive schema (8.0g), mapUserOccurrences (LOW). Provider->page_blocks coupling 3 -> 1 (timezoneItems only). |
| 8.0e | **DONE** (2026-03-02) | Auth type consolidation. 4 commits. Deleted legacy auth/types.ts (6 duplicate types). 17 consumer imports redirected to @/shared/types/auth. LogOutOptions drift fixed (macAppRedirect added to canonical). RoleSchema created (z.enum), replaced 2 pass-through casts + 1 z.nativeEnum + 1 fake role schema. 3 fake z.unknown() schemas replaced with real UserInfoSchema/TenantWithProvidersSchema. AuthProvider[] double cast replaced with explicit .transform(). 2 branded-type gaps fixed (logout.tsx UserId, useLoginActions.tsx OrganizationId). |
| 8.0f | **DONE** (2026-03-02) | Re-export shim elimination. 1 commit (`7090acd3`), 234 files changed, net -209 lines. Migrated ~200 consumer files from provider type re-exports to canonical @/shared/types/* modules. Removed all re-export blocks from 5 provider type files (insightsContext, teamsContext, usersContext, urlClassification, bpoProjectsContext). Deleted bpoProjectsContext/types.ts (100% re-exports, zero local types) + empty directory. Cleaned teamsContext barrel Team re-export. Fixed usersContext barrel to use relative paths. Fixed UrlsClassificationProvider import after re-export removal. Fixed queryParams.spec.ts broken relative import. Fixed 9 duplicate import ESLint errors. Tests: 181 specs, 2289 passed, 2 todo (stable). 0 type re-exports remaining. |
| 8.0g | **DONE** (2026-03-02) | 10 commits. Non-null assertions: 76 eliminated (67 URL helpers via RouteUrl/HrefUrl return types + 9 accessor lookups via getAccessorHeader utility). Dead code: ~1275 lines deleted (73 dead fixture exports un-exported, 41 truly dead functions deleted, 3 dead files removed, EDIT_TEAM_MODAL_NAME un-exported). Type safety: initalRole typo fixed, `as Role` replaced with RoleSchema.parse, z.nativeEnum replaced with z.enum for ClassificationCategories. Structural: MutationOpts extracted to shared type (8 BPO hooks), GroupsAssignments.tsx renamed, mapWorkstreamsTimingInfo deep import fixed, 'use client' removed from RequireLoginMaybe.tsx, unused _params removed from useTeamsListQuery. Feature flags: 24h TTL added to encrypted cache. Typos: TEAMA_TABLE_PAGE_SIZE fixed. Coupling: timezoneItems moved to shared/constants/filters (provider->page_blocks now 0). DDAU exceptions documented (TenantLogin, LoginForm/useLoginActions, ProfileMenu). Build fix: isDaylightTime barrel import replaced with direct path to prevent SSG leak. **Deferred**: N18 Table sorting useEffect, superseded filter specs (container specs don't exist). |
| 8.0g-deferred | **DONE** (2026-03-02) | 9 commits. Prop grouping: shared ModalState<T> + TableSelection<T> types, BPO 22->9 props, Project 22->9, ClassificationUrls 18->16, Users 17->14, Teams 15->9. N17: UserPanelDetails extracted from 90-line nested render fn. Chained ternaries: 5 files flattened to named variables, SystemAnalysis redundant guard removed. N11: csvMapper as-casts justified (CSVValueMapper receives unknown by design). |
| **Audit 3** | **DONE** (2026-03-02) | Pre-upgrade gate audit. 29 agents, 7 types. 28 net-new findings. Report: `~/audits/26-03-02-15-45--user-frontend--complete-audit.md`. Diff: `~/audits/net-new--diff--26-03-01-21-05--26-03-02-15-45.md`. |
| 8.0h | **DONE** (2026-03-02) | 5 commits. P0 bugs: N1 getTtmForDays mock returns Record (was array), N2 `as never` replaced with isRole guard, N3 `e as Error` replaced with instanceof pattern. Mock schemas: N6 users/groups POST returns single Group, N7 classification URLs PUT returns ModifyClassificationUrlResponse. N13 monitorApiCall double-call fixed (apiCall() before NR setup), N19 id_token stripped from NR attributes. Dead code: N8 4 dead MetadataPopupContent copies deleted (specs moved to canonical), N9 874L mocks.ts deleted, N15 dead dayjs imports removed. N25 createColumnHelper moved to module scope in 5 files. Tests 2291, specs 181, 0 tsc errors, 0 ESLint warnings. HEAD `49bd1583`. |
| nuqs | **DONE** (2026-03-03) | 7 commits (`3626cc5c`..`9c83cf58`). Filter state migrated from localStorage to URL params. url-params.ts created, NuqsAdapter in _app.tsx, 4 filter containers migrated, MicroworkflowsContainer migrated, storage.ts deleted, NEW_INSIGHTS_FILTERS_KEY removed. Tests 2281, specs 180. |

### Dead npm dependencies (fold into 8.6)

Audit2 found 10 dead deps + 2 misplaced:

| Package | Type | Action |
|---------|------|--------|
| @heroicons/react | prod | Remove (zero imports) |
| @vercel/analytics | prod | Remove (zero imports) |
| chartjs-adapter-moment | prod | Remove (chart.js already removed in 4.7) |
| nuqs | prod | Remove (installed Phase 1, never adopted; nuqs migration deferred) |
| react-markdown | prod | Remove (zero imports) |
| reactflow | prod | Remove (zero imports) |
| remark-gfm | prod | Remove (zero imports) |
| sharp | prod | Remove (zero imports) |
| @storybook/addon-controls | dev | Remove (not in storybook config) |
| @vitest/browser | dev | Remove (not in vitest config) |
| @8flowinc/eslint-plugin | dev | Remove (not in eslint.config.mjs) -- Audit 3 N10 |
| @tanstack/eslint-plugin-query | dev | Remove (not in eslint.config.mjs) -- Audit 3 N10 |
| sonner | prod | Remove (zero imports, peer dep conflict) -- Audit 3 N11 |
| playwright-extra | prod -> dev | Move (only imported in e2e/fixture.ts) |
| puppeteer-extra-plugin-stealth | prod -> dev | Move (only imported in e2e/fixture.ts) |
| @types/node | prod -> dev | Move (type-only, should be devDep) -- Audit 3 N12 |
| @types/react | prod -> dev | Move (type-only, should be devDep) -- Audit 3 N12 |
| @types/react-dom | prod -> dev | Move (type-only, should be devDep) -- Audit 3 N12 |
| typescript | prod -> dev | Move (compiler, should be devDep) -- Audit 3 N12 |

### Security vulnerabilities (fold into 8.2/8.4)

| Vulnerability | Package | Fix | Severity |
|---------------|---------|-----|----------|
| DoS with Server Components (3 CVEs) | next | 14.2.35+ | HIGH/CRITICAL |
| JSON VNode Injection | preact via posthog-js | posthog-js 1.357.0 | HIGH |

### React 19 blockers (affects 8.1-8.3)

| Library | Current | Needs | Blocker? |
|---------|---------|-------|----------|
| next | 14.x | 15+ for React 19 peerDep | Yes |
| next-themes | 0.3.x | 0.4+ | Yes |
| react-flatpickr | 3.x | 4.x (peerDep <=19 in latest) | Marginal |

### Structural duplication (backlog)

BPO and Project settings blocks are 95% structurally identical: containers,
presentationals, column hooks, constants, and specs. Strongest DRY extraction
candidate in the codebase. Not blocking ship but should be addressed eventually
via `/extract-shared-presentational`.

---

## Work Items

### 8.1+8.2: Upgrade Next.js 14 -> 15 + React 18 -> 19

**DONE** (2026-03-02). 5 commits (`7bfbb3cc`..`e97b40f4`).

Upgrade order: Next.js 15 first (on React 18), then React 19 + peer deps.

| Commit | Description |
|--------|-------------|
| `7bfbb3cc` | Next.js 14.2.32 -> 15.5.12. Config: `eslint.dirs: []` -> `ignoreDuringBuilds: true`. |
| `3f63ca64` | React 18.3.1 -> 19.2.4 + @types. MutableRefObject -> RefObject, nullable ref widening, 6 spec assertions for React 19 FC calling convention. |
| `6b2654cb` | next-themes 0.3.0 -> 0.4.6 (React 19 peer dep). Drop-in, no API changes. |
| `190a9edd` | react-flatpickr 3.10.13 -> 4.0.11 + @types/react-flatpickr removed. Ref type: InstanceType -> DateTimePickerHandle. Fixed 2 global JSX namespace references (React 19 scopes JSX under React.JSX). |
| `e97b40f4` | Migrated all 6 forwardRef sites to React 19 ref-as-prop. Zero forwardRef remaining. Fixed pre-existing unbound-method ESLint error in FilterSelect (onChange via rest spread). |

All third-party libraries verified React 19 compatible: echarts-for-react, @headlessui/react 2.2.4, react-hook-form 7.56.1, @tanstack/react-query 5.66.0, @tanstack/react-table 8.20.6, reactflow 11.11.4, nuqs 2.8.8, @testing-library/react 16.2.0, posthog-js. Zero peer dep conflicts.

### 8.3: Upgrade react-flatpickr 3 -> 4

**DONE** -- folded into 8.1+8.2 commit `190a9edd` (see above).

### 8.4: Upgrade remaining deps

**DONE** (2026-03-02). 3 commits.

| Package | From | To | Notes |
|---------|------|-----|-------|
| `posthog-js` | 1.304.0 | 1.357.1 | Patches last production CVE (preact VNode injection). Commit `4932ee69`. |
| `jsdom` | 24.1.3 | 28.1.0 | Dev dep. 4 major versions, no breaking changes for our surface. Commit `cbf90835`. |
| `concurrently` | 8.2.2 | 9.2.1 | Dev dep. CLI flags unchanged. Commit `19700f38`. |
| `dotenv` | 16.5.0 | 17.3.1 | Dev dep. dotenv.config() API unchanged. Commit `19700f38`. |
| `sharp` | 0.33.5 | -- | Dead dep (zero imports) -- folded into 8.6 removal. |

### 8.5: Align next.config.js

**DONE** -- folded into 8.1+8.2 commit `7bfbb3cc`. `eslint.dirs: []` replaced with `ignoreDuringBuilds: true`. `typescript.ignoreBuildErrors` not needed (tsc passes clean).

| Setting | Current | Target | Status |
|---------|---------|--------|--------|
| `output` | `'export'` | Keep | Done |
| `distDir` | `'dist'` | Keep | Done |
| `eslint.ignoreDuringBuilds` | `true` | Keep | Done |
| webpack TerserPlugin | Present | Assess | Deferred |

### 8.6: Remove dead deps

**DONE** (2026-03-02). 3 commits.

| Action | Packages | Commit |
|--------|----------|--------|
| Remove dead prod (8) | @heroicons/react, @vercel/analytics, chartjs-adapter-moment, nuqs, react-markdown, reactflow, remark-gfm, sharp | `f0c15adc` |
| Remove dead dev (5) | @storybook/addon-controls, @vitest/browser, @8flowinc/eslint-plugin, @tanstack/eslint-plugin-query, lint-staged | `3e889a01` |
| Move misplaced to dev (4) | playwright-extra, puppeteer-extra-plugin-stealth, @types/node, typescript | `d2600d26` |

**Deviation**: `sonner` was listed as dead in audits but is actively used by `Toast.tsx` (imported across 15+ files). NOT removed.

**Side effects**: @types/node upgraded 20.17.50 -> 25.3.3, typescript upgraded 5.8.3 -> 5.9.3 (within existing `^` semver ranges, resolved to latest during move). typescript-eslint has a non-blocking peer dep warning for TS 5.9 (wants <5.9.0).

Final dep counts: Prod 23, Dev 55.

### 8.7-8.8: Browser bug bash -- BLOCKED on Firebase emulator

**Status**: BLOCKED (2026-03-03). Firebase auth blocks automated browser
testing. `NEXT_PUBLIC_LOCAL=true` only switches the data layer, not auth.

**Decision (2026-03-03):** Use Firebase emulator (Option B). One-time setup
is pre-work inside the bug bash prompt itself. The prompt is reusable -- run
it for as many rounds as needed.

**Prompt**: `~/plans/prompts/backlog-06-bug-bash.md`

**Tracking**: PR BLOCKER. Do not merge `sd/productionize` into `production`
without completing at least 1 bug bash round.

### 8.9: Fix Storybook stories -- DONE

**DONE** (2026-03-03). 2 commits (`cd30e13e`, `51ca4ba3`). HEAD `d5ca7483`.

All 13 story files verified against production component APIs. Only 1 fix
needed: ProfileMenu story imported InsightsPageIds from `@/root/e2e/constants`
(excluded by tsconfig) -- switched to `@/constants/testIds`.

tsconfig modernized: `moduleResolution` upgraded from `"node"` to `"bundler"`
to support modern package `exports` fields (Storybook 10, etc.). Story
exclusions removed from tsconfig -- all 13 stories now pass `pnpm tsc --noEmit`.
Path mapping added for `@headlessui/react/dist/internal/floating` (not in
package exports). Storybook 10 dev server starts cleanly.

Storybook warnings noted (non-blocking):
- `actions.argTypesRegex` deprecated in favor of `fn` spies (cosmetic)
- No `.mdx` story files found (pattern mismatch, cosmetic)

### 8.10: Consolidate documentation -- DONE

**DONE** (2026-03-03). 1 commit (`d5ca7483`).

README.md stack versions updated (ECharts 5->6, Storybook 8->10, added
Tailwind CSS 4). CLAUDE.md already current. All 4 docs/ files verified
clean -- no stale references to removed packages or old APIs.

### 8.11: DDAU Exception Elimination -- DONE

**DONE** (2026-03-03). 4 commits (`ca8c6f73`..`e75d9a25`). HEAD `e75d9a25`.

Eliminated 5 DDAU exceptions. 3 form container extractions, 1 prop injection,
1 parameter injection, 1 pathname prop, 1 assessment closed as permanent.

| Item | Status | Summary |
|------|--------|---------|
| 8.11a | **DONE** | 3 form containers created: AddTeamFormContainer, AddUserFormContainer, EditURLsFormContainer. Forms now presentational. |
| 8.11b | **DONE** | EditUserModal receives selectedUser as prop from Users.tsx. useUsers() removed. Mutations stay (react-hook-form exception). |
| 8.11c | **CLOSED** | TenantLogin + LoginForm/useLoginActions reclassified as permanent auth-boundary exceptions. Pre-login boundary, no container benefit. |
| 8.11d | **DONE** | useChatApi accepts getIdToken parameter. useAuthState removed. ChatContainer passes token getter. |
| 8.11e | **DONE** | SettingsNavigation receives pathname as prop from SignedInPageShell. usePathname removed. |

Post-nuqs gate check: all 7 flyout coordination files still have violations
(separate migration needed for selection state to URL params).

Tests: 180 specs, 2281 passed, 2 todo. 0 tsc errors. 0 ESLint warnings. Build clean.

### ~~8.12: Port db/ directory~~ -- SKIP

**NGA-only.** These are Supabase database scripts. UF has no database --
it talks to UB. Comes when UB is ported into UF (if ever needed).

### 8.12: SSR migration (DEFERRED)

**Use `/migrate-page-to-ssr`** on each page when this is unblocked.

**Dependency chain** (each step unblocks the next):
```
nuqs filter migration (IN PROGRESS)
  -> BFF Phase 1.2: auth cookie plumbing (HttpOnly cookie + Firebase Admin SDK)
    -> SSR migration: getServerSideProps reads cookie + URL params
```

With nuqs providing URL-backed filter state and the BFF using same-origin
`HttpOnly` cookies (Vercel Enterprise decision), `getServerSideProps` can:
1. Verify the auth cookie server-side (Firebase Admin SDK)
2. Read filter params from the request URL (nuqs serialization)
3. Pre-fetch the correct data and hydrate TanStack Query cache

This eliminates the client-side loading waterfall (render shell -> auth check
-> fetch data -> render content) and replaces it with server-side data
fetching (verify auth + fetch data -> render full page).

**Blocked by**: BFF Phase 1.2 (auth cookie infrastructure). The BFF plan
(`~/plans/uf-bff-plan.md`) covers this in Phase 1.2. SSR migration cannot
start until the auth cookie is in place.

When unblocked:
- Remove `output: 'export'`
- Add `getServerSideProps` to each page
- Bootstrap server-side auth (read cookie, verify with Firebase Admin)
- Mock handler becomes unnecessary (real BFF handlers serve data)

See `~/plans/archive/idiomatic-nextjs-migration.md` for the full plan.

**Bundle / tree-shaking note (verified 2026-03-02):** The codebase has 320 barrel
files (index.ts). Verified that barrels are NOT inflating the bundle: per-page
chunks are 0.3-22 KB, total JS is 3.2 MB across 48 chunks, 71% of which is
Firebase (1.3 MB) and ECharts (1.0 MB). Webpack is tree-shaking barrel re-exports
correctly under `output: 'export'`.

However, when `output: 'export'` is removed for SSR, per-route code splitting
becomes real and barrel imports could pull in unnecessary transitive deps. At
that point:
1. Add `"sideEffects": false` to package.json
2. Add `experimental.optimizePackageImports` to next.config.js for large libs
3. Re-run the build and compare per-page First Load JS before/after
4. If any page regresses, convert its imports from barrel to direct file imports

## Confidence Level

**Low but well-scoped.** The dep upgrades are enumerated and the breaking
changes are documented. The bug bash scope is predictable from NGA experience
(20+ fixes across 2 rounds). The unknowns are the specific bugs, which by
definition cannot be predicted.

## NGA Commit History Reference

- `868f921d`: Close 5 visual parity gaps with main3
- `6917624c`: Match systems card/detail visual fidelity
- `e55ab3f5`, `b6361c1d`, `8b6b2fdc`, `e59dd2d1`: Bug bash fix commits
- `7c4f7289`, `5490bde8`: Round 2 bug bash fixes
- `2626cdae`: Remove hardcoded GitHub Packages token from .npmrc
- `afcf9d75`: Remove dead root files, storybook setup, unused deps
