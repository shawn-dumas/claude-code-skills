# Migration: FE Mapper Functions to BFF Handlers

> Absorb client-side data transformations into BFF route handlers, then
> delete the mapper files. Eliminates unnecessary client-side processing
> where the server already has the data in hand.
>
> Created: 2026-03-14
> Branch: sd/productionize
> Complexity: D5 S5 Z5 = 5.0
> Duration: F3 C3 = 12h (6-24h)
> Nearest: DDAU Exception Elimination (6.0, F3 C3), AST Tools (5.7, F3 C1)
> Integration scope: per-prompt (all 4 handlers have Vitest API integration tests)
> Playwright scope: dedicated prompt (14 page.route() intercepts across 5 PW specs need code changes)
> Pre-flight: CERTIFIED 2026-03-15 by pre-flight-plan-audit
> Pre-flight findings: 0 blockers, 0 warnings

> Report: ~/plans/fe-to-bff-transformation-report.md

**Scoring rationale:** D5: moderate -- most risks caught by tsc/tests,
but PW intercept failures are runtime-only (Zod rejects at runtime, not
compile time) and workstream flattening requires judgment. S5: touches
BFF handlers, shared types, mock routes, query hooks, PW specs, and
integration fixtures across 3 layers. Z5: 7 prompts (6 + cleanup),
~40 files. F3: peak ~8 files per prompt, targeted edits, no mass
pattern replacement. C3: two sessions over 1-2 days (3 auto + 3 manual

- cleanup).

## Key Context and Discoveries

- **14 Playwright `page.route()` intercepts** serve fixture data in the
  current response shape. Changing BFF response schemas without updating
  these intercepts causes silent failures (Zod rejection at runtime, not
  compile time). This was the biggest gap found by adversarial review.

- **mapRealtimeStats uses `...stats` spread** (line 9) which passes
  through ALL raw `RealtimeStats` fields into the output. The renamed
  fields override the spread. The BFF must do the same -- omitting the
  spread drops fields like `lastEvent` that UI consumers access.

- **Mock routes serve data from `buildStandardScenario()`**. Changing
  the scenario type has high blast radius. All prompts instruct work
  agents to map inline in the mock route rather than changing
  `StandardScenario`.

- **Workstream flattening in mapUserStats** is the hardest decision.
  The mapper uses `Object.fromEntries` to spread dynamic workstream keys
  into the user object, creating an intersection type with
  `[key: string]: number | string`. This is hard to express in Zod.
  Prompt 05 documents two approaches (flatten or keep nested) and
  instructs the work agent to document the decision.

- **`docs/missing-api-routes.md` was not found in the repo.** Step 2 of
  prompt 01 (marking rows 22-25 as implemented) was skipped. The file
  was referenced in the original plan but does not exist.

- **The report** at `~/plans/fe-to-bff-transformation-report.md` has a
  stale status table -- prompt 01 fixes it.

## Relevant Files

**Mapper files** (to be deleted by prompts 02-05):

- `src/ui/services/hooks/queries/users/useUsersListQuery/mapUsers.ts`
- `src/ui/services/hooks/queries/insights/useTTMForDaysQuery/mapTtmForDays.ts`
- `src/ui/services/hooks/queries/insights/useTeamRealtimeStatsQuery/mapRealtimeStats.ts`
- `src/ui/services/hooks/queries/insights/useTeamsHostTimeQuery/mapUserStats.ts`

**BFF handlers** (to be modified):

- `src/pages/api/users/user-data.ts`
- `src/pages/api/users/data-api/productivity/getTtmForDays.ts`
- `src/pages/api/users/data-api/productivity/getTeamRealtimeStats.ts`
- `src/pages/api/users/data-api/productivity/getHostTime.ts`

**Playwright specs with route intercepts** (to be updated by prompt 06):

- `integration/tests/realtime.spec.ts` (7 intercepts)
- `integration/tests/user-productivity.spec.ts` (3 intercepts)
- `integration/tests/export.spec.ts` (3 intercepts)
- `integration/tests/components.spec.ts` (2 intercepts)
- `integration/tests/url-params.spec.ts` (1 intercept)

## Pre-Execution Verification

```bash
# Confirm plan files exist
ls ~/plans/fe-to-bff-mapper-migration.md \
   ~/plans/fe-to-bff-mapper-migration-cleanup.md \
   ~/plans/prompts/fe-to-bff-mapper-migration-0*.md

# Confirm all 4 mapper files still exist
ls src/ui/services/hooks/queries/users/useUsersListQuery/mapUsers.ts \
   src/ui/services/hooks/queries/insights/useTTMForDaysQuery/mapTtmForDays.ts \
   src/ui/services/hooks/queries/insights/useTeamRealtimeStatsQuery/mapRealtimeStats.ts \
   src/ui/services/hooks/queries/insights/useTeamsHostTimeQuery/mapUserStats.ts

# Confirm 4 BFF routes exist
ls src/pages/api/users/user-data.ts \
   src/pages/api/users/data-api/productivity/getTtmForDays.ts \
   src/pages/api/users/data-api/productivity/getTeamRealtimeStats.ts \
   src/pages/api/users/data-api/productivity/getHostTime.ts

# Confirm PW intercepts exist
rg 'getTeamRealtimeStats|getHostTime|getTtmForDays' \
   integration/tests/ --type ts -c

# Confirm tsc passes
pnpm tsc --noEmit
```

## Prompt Dispatch Guide

| #   | Prompt           | Auto/Manual        | Notes                                                      |
| --- | ---------------- | ------------------ | ---------------------------------------------------------- |
| 01  | docs             | auto               | Doc-only, no production code                               |
| 02  | mapUsers         | auto               | Includes import boundary check                             |
| 03  | mapTtmForDays    | auto               | Simplest migration (4 lines)                               |
| 04  | mapRealtimeStats | manual recommended | Complex field mapping with `...stats` pass-through         |
| 05  | mapUserStats     | manual recommended | Workstream flattening decision; dead code pass + docs grep |
| 06  | playwright       | manual recommended | 14 intercepts across 5 spec files                          |

## Current State

17 mapper files in `src/ui/services/hooks/queries/` transform API
responses client-side before the UI renders them. These exist because
legacy API endpoints return shapes that don't match UI expectations
(string numbers from ClickHouse, keyed records instead of arrays,
unnormalized field names, fractions instead of percentages).

4 of these mappers now have corresponding BFF route handlers. The BFF
already has the data -- it should return the right shape and eliminate
the client-side mapper.

```bash
# All mapper files (excluding specs)
ls src/ui/services/hooks/queries/*/use*/map*.ts \
   src/ui/services/hooks/queries/*/*/use*/map*.ts 2>/dev/null \
   | grep -v '.spec.' | wc -l
# Current count: 17
```

## Target State

The 4 mappers with BFF routes are deleted. Their transformations are
absorbed into the BFF handler. The query hooks receive the correct shape
directly from the API (no `select` transform needed). Response Zod
schemas enforce the UI-ready shape. The remaining 13 mappers stay
untouched until their BFF routes are implemented.

```bash
# After migration, mapper count should be:
ls src/ui/services/hooks/queries/*/use*/map*.ts \
   src/ui/services/hooks/queries/*/*/use*/map*.ts 2>/dev/null \
   | grep -v '.spec.' | wc -l
# Target: 13
```

## Inventory

| #   | Mapper           | Domain             | BFF Handler             | Schema File            | Complexity | Prompt | Status  |
| --- | ---------------- | ------------------ | ----------------------- | ---------------------- | ---------- | ------ | ------- |
| 1   | mapUsers         | users              | user-data.ts            | users.schema.ts        | mechanical | 02     | done |
| 2   | mapTtmForDays    | insights/TTM       | getTtmForDays.ts        | productivity.schema.ts | mechanical | 03     | done |
| 3   | mapRealtimeStats | insights/realtime  | getTeamRealtimeStats.ts | realtime.schema.ts     | contextual | 04     | done |
| 4   | mapUserStats     | insights/host-time | getHostTime.ts          | productivity.schema.ts | contextual | 05     | done |

### Not in scope (13 mappers, no BFF route)

| Mapper                    | Endpoint                              | Blocked on                      |
| ------------------------- | ------------------------------------- | ------------------------------- |
| mapOperationalHours       | productivity/getOperationalAnalysis   | BFF route implementation        |
| mapSystemsOverview        | systems/overview                      | BFF route implementation        |
| mapSystemPages            | systems/[systemId]/pages              | BFF route implementation        |
| mapActivitiesByUser       | systems/.../activities-by-user        | BFF route implementation        |
| mapUserOccurrences        | systems/.../occurrences               | BFF route implementation        |
| mapWorkstreamsTimingInfo  | workstream-analysis/getTimingInfo     | BFF route implementation        |
| mapWorkstreams            | workstream-analysis/getWorkstreamList | BFF route implementation        |
| mapAvgLatencyByHost       | system-latency/getAvgLoadTimesByHost  | BFF route implementation        |
| mapTopUsedHosts           | system-latency/getTopUsed             | BFF route implementation        |
| mapTimeByHost             | system-latency/getUserLoadTimeByHost  | BFF route implementation        |
| mapMicroworkflows         | opportunities/microworkflows          | BFF route implementation        |
| mapActivityTimeline       | analyzer/activity-timeline            | Tier 3 -- keep in FE regardless |
| mapClassificationUrlItems | classification/site-urls/\*           | BFF route implementation        |

## Migration Phases

| #   | Phase            | Prompt  | What                                                                         | Files | Status  |
| --- | ---------------- | ------- | ---------------------------------------------------------------------------- | ----- | ------- |
| 1   | Docs             | 01      | Update stale docs + report status table                                      | 3     | done    |
| 2   | mapUsers         | 02      | Absorb groupAssignment split into user-data.ts                               | ~8    | done    |
| 3   | mapTtmForDays    | 03      | Absorb record-to-array into getTtmForDays.ts                                 | ~7    | done    |
| 4   | mapRealtimeStats | 04      | Absorb record-to-array + field rename + flatten into getTeamRealtimeStats.ts | ~7    | done    |
| 5   | mapUserStats     | 05      | Absorb fraction-to-percent + coercion + group split into getHostTime.ts      | ~8    | done    |
| 6   | Playwright       | 06      | Update 14 page.route() intercepts + integration fixtures for new shapes      | ~8    | done    |
| 7   | Cleanup          | cleanup | Final verification, mapper count, doc audit                                  | -     | done    |

## Dependency Graph

```
Prompt 01 (docs -- no code changes)
|
v
Prompt 02 (mapUsers -- Postgres, establishes groupAssignment split pattern)
|
+-------+-------+
|               |
v               v
Prompt 03       Prompt 04
(mapTtmForDays) (mapRealtimeStats)
|               |
+-------+-------+
        |
        v
Prompt 05 (mapUserStats -- reuses group split from 02, shares productivity.schema.ts with 03)
|
v
Prompt 06 (Playwright -- updates all 14 page.route() intercepts for new response shapes)
|
v
Cleanup
```

Prompts 03 and 04 are independent (different schema files). Prompt 05
depends on 02 (group split pattern) and should follow 03 (both touch
productivity.schema.ts). Prompt 06 depends on all BFF prompts (03-05)
completing first -- the PW intercepts must match the final response shapes.

## Per-Mapper Migration Pattern

Every mapper migration follows the same steps:

1. **Read** the mapper, handler, schema, mock route, query hook, and
   their test files
2. **Define the new response shape** as a Zod schema (absorbing the
   mapper's transformations)
3. **Modify the BFF handler** to compute the mapped shape before
   returning
4. **Update the response Zod schema** to validate the new shape
5. **Update the mock route** to return data matching the new schema
6. **Update the query hook**: remove `select`, update the fetchApi
   schema reference, update type parameters
7. **Delete** the mapper file and its spec file
8. **Update tests**: API integration tests (new assertions on response
   shape), unit tests (query hook spec may need updated mocks)
9. **Verify**: tsc, unit tests, API integration tests, build, eslint

## Playwright Impact

These Playwright specs intercept the affected BFF endpoints via
`page.route()` and serve fixture data in the current (pre-migration)
response shape. After migration, the intercepts must serve the new shape.

| Endpoint             | PW Spec                                                                           | Intercept Count |
| -------------------- | --------------------------------------------------------------------------------- | --------------- |
| getHostTime          | components.spec.ts, export.spec.ts, user-productivity.spec.ts, url-params.spec.ts | 5               |
| getTeamRealtimeStats | realtime.spec.ts                                                                  | 7               |
| getTtmForDays        | export.spec.ts, user-productivity.spec.ts                                         | 2               |

Total: 14 intercepts across 5 spec files. The integration fixtures in
`integration/fixtures/user-productivity.ts` explicitly note they match the
API response shape (not the post-mapping shape). All must be updated.

Playwright verification runs after the final production-code prompt
(prompt 05) as a regression check.

## Verification Checklist

| #   | Prompt              | Agent Ran API Tests? | Orchestrator Ran API Tests? | Results Match? | PASS/FAIL |
| --- | ------------------- | -------------------- | --------------------------- | -------------- | --------- |
| 1   | 01-docs             | N/A (doc only)       | N/A                         | N/A            | PASS      |
| 2   | 02-mapUsers         | not run (no Docker)  | not run (no Docker)         | N/A            | PASS*     |
| 3   | 03-mapTtmForDays    | not run (no Docker)  | not run (no Docker)         | N/A            | PASS*     |
| 4   | 04-mapRealtimeStats | not run (no Docker)  | not run (no Docker)         | N/A            | PASS*     |
| 5   | 05-mapUserStats     | not run (no Docker)  | not run (no Docker)         | N/A            | PASS*     |
| 6   | 06-playwright       | not run (no Docker)  | not run (no Docker)         | N/A            | PASS*     |
| 7   | cleanup             | N/A                  | tsc clean                   | N/A            | PASS      |

*PASS = tsc + unit tests + build + eslint all clean. Integration tests not run (Docker/emulator unavailable).

### Playwright Verification (final-only)

| Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
| ------------- | -------------------- | -------------- | --------- |
| not run       | not run              | N/A            | DEFERRED  |

PW specs need to be run when Firebase emulator is available. See cleanup file for commands.
