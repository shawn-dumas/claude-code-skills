# Flyout Coordination DDAU Elimination Plan

> **STATUS: DONE** (2026-03-03). 3 commits. HEAD see git log.
>
> Eliminate the remaining flyout-coordination DDAU exceptions in user-frontend.
> Corresponds to the 7 flyout files (items 5-11) from the exception elimination plan.
> Created: 2026-03-03.
>
> Prerequisite: 8.11 complete. All non-flyout exceptions eliminated.

---

## Problem Statement

Two feature areas use React context for flyout coordination: the **Users**
domain and the **URL Classification** domain. In both, leaf components
(table rows, detail panels, cell components) reach into context to read
or write flyout state, violating DDAU. The containers that wrap
`FlyoutProvider` already exist -- they just don't own the state yet.

Three micro-contexts are involved:

| Context | Shape | Scope |
|---------|-------|-------|
| `FlyoutContext` | `{ flyoutOpen: boolean, setFlyoutOpen }` | Container-scoped (UsersContainer, ClassificationUrlsContainer) |
| `UsersContext` | `{ selectedUser: User \| null, setSelectedUser }` | Global (Providers.tsx) |
| `UrlsClassificationContext` | `{ selectedHost: ClassificationUrlItem \| null, setSelectedHost }` | Page-scoped (urls.tsx, TeamBlock.tsx) |

The fix: lift the ephemeral state (flyoutOpen, selectedUser, selectedHost)
from context reads into the containers as local `useState`. Pass state +
callbacks down as props. Leaf components become presentational. No nuqs
needed -- this is transient UI state that correctly resets on navigation.

---

## Current State: 7 Exception Files

| # | File | Context Reads | What It Does |
|---|------|--------------|-------------|
| 1 | `UsersTable.tsx` (102L) | `useFlyoutContext().setFlyoutOpen`, `useUsers().setSelectedUser` | Row click opens flyout + selects user |
| 2 | `UserRoleSelect.tsx` (86L) | `useFlyoutContext().setFlyoutOpen` | Cell component; closes flyout when role changed to admin |
| 3 | `UserPanel.tsx` (85L) | `useFlyoutContext().{flyoutOpen, setFlyoutOpen}`, `useUsers().selectedUser` | Flyout panel; reads open state + selected user, closes on click-away/escape |
| 4 | `Users.tsx` (168L) | `useFlyoutContext().setFlyoutOpen`, `useUsers().selectedUser` | Orchestrator; reads selectedUser for modals, closes flyout after assignment |
| 5 | `TeamUsersActions.tsx` (126L) | `useRemoveUsersFromTeamMutation` (service hook) | Carry-forward; mutation in leaf |
| 6 | `ClassificationUrlsBlock.tsx` (158L) | `useFlyoutContext().setFlyoutOpen`, `useUrlsClassification().setSelectedHost` | Row click opens flyout + selects host |
| 7 | `OrgHostDetailsPanel.tsx` (93L) | `useFlyoutContext().{flyoutOpen, setFlyoutOpen}`, `useUrlsClassification().selectedHost` | Flyout panel; reads open state + selected host, closes on click-away/escape |

---

## Target State

After this work:
- 0 leaf components call `useFlyoutContext()`, `useUsers()`, or `useUrlsClassification()`
- `UsersContainer` owns `selectedUser` + `flyoutOpen` as local state, passes via props
- `ClassificationUrlsContainer` owns `selectedHost` + `flyoutOpen` as local state, passes via props
- `FlyoutContext` can be deleted entirely (replaced by container-owned state)
- `UsersContext` can be deleted entirely (only consumer was the users feature area)
- `UrlsClassificationContext` can be deleted or reduced (only consumer was the URLs feature area)
- `TeamUsersActions` mutation lifted to container or parent
- `UserRoleSelect` receives a callback prop instead of reading context

---

## Execution Plan

### Phase A: Users Domain (5 files, ~1.5 sessions)

**A1: Lift flyout + selection state to UsersContainer**

`UsersContainer` already wraps `<FlyoutProvider>` around `<Users />`. Replace
the provider wrapping with local state:

```typescript
// UsersContainer -- add these
const [selectedUser, setSelectedUser] = useState<User | null>(null);
const [flyoutOpen, setFlyoutOpen] = useState(false);

const handleUserClick = useCallback((user: User) => {
  setSelectedUser(user);
  setFlyoutOpen(true);
}, []);

const handleCloseFlyout = useCallback(() => {
  setFlyoutOpen(false);
}, []);
```

Pass to `<Users />` as new props:
- `selectedUser`, `onUserClick`, `flyoutOpen`, `onCloseFlyout`

**A2: Update Users.tsx**

Remove:
- `const { selectedUser } = useUsers();`
- `const { setFlyoutOpen } = useFlyoutContext();`

Accept new props: `selectedUser`, `onUserClick`, `flyoutOpen`, `onCloseFlyout`

Thread `onUserClick` to `UsersTable`. Thread `selectedUser`, `flyoutOpen`,
`onCloseFlyout` to `UserPanel`. Replace `setFlyoutOpen(false)` in
`handleEditAssignments` with `onCloseFlyout()`.

**A3: Update UsersTable.tsx**

Remove:
- `const { setFlyoutOpen } = useFlyoutContext();`
- `const { setSelectedUser } = useUsers();`

Accept new prop: `onUserClick: (user: User) => void`

Replace `handleUserClick` (which called setFlyoutOpen + setSelectedUser)
with the prop callback. Also needs to thread a callback to `UserRoleSelect`
for the admin-promotion flyout close.

**A4: Update UserRoleSelect.tsx**

Remove:
- `const { setFlyoutOpen } = useFlyoutContext();`

Accept new prop: `onFlyoutClose?: () => void`

Replace `setFlyoutOpen(false)` in `onUserRoleChangeForTeam` with
`onFlyoutClose?.()`.

**Threading through TanStack Table**: The column hook (`useUsersTableColumns`)
renders `UserRoleSelect` as a cell component. The column hook itself does
NOT call context -- it creates column definitions. The `onFlyoutClose`
callback needs to flow through:
1. `UsersContainer` passes `onCloseFlyout` to `Users`
2. `Users` passes it to `UsersTable`
3. `UsersTable` passes it to `useUsersTableColumns` as a parameter
4. The column definition for the role cell renders `<UserRoleSelect onFlyoutClose={onFlyoutClose} />`

This is the trickiest part. Read `useUsersTableColumns.tsx` carefully to
understand how cell components receive props.

**A5: Update UserPanel.tsx**

Remove:
- `const { flyoutOpen, setFlyoutOpen } = useFlyoutContext();`
- `const { selectedUser } = useUsers();`

Accept new props: `isOpen: boolean`, `selectedUser: User | null`, `onClose: () => void`

Replace all `flyoutOpen` reads with `isOpen`. Replace all
`setFlyoutOpen(false)` calls with `onClose()`. Keep `useClickAway` and
`useEscapeKey` (ambient hooks, allowed).

**A6: Lift TeamUsersActions mutation**

`TeamUsersActions` holds `useRemoveUsersFromTeamMutation` in a leaf.
Either:
- (a) Lift to UsersContainer and pass `onRemoveUsers` callback, or
- (b) Create a thin `TeamUsersActionsContainer` (same pattern as the form
  containers from 8.11a)

Option (a) is preferred since UsersContainer already owns the users query
and can handle cache invalidation.

**A7: Remove FlyoutProvider from UsersContainer**

After all children are prop-driven, remove the `<FlyoutProvider>` wrapper.
The context is no longer consumed.

**A8: Eliminate UsersContext**

After the lift, no component calls `useUsers()`. Check:
```bash
grep -rn "useUsers()" src/ --include="*.ts" --include="*.tsx" | grep -v "spec\." | grep -v "node_modules"
```

If zero results: delete `UsersProvider` from `Providers.tsx`, delete the
`usersContext/` directory.

### Phase B: URL Classification Domain (2 files, ~0.5 session)

**B1: Lift flyout + selection state to ClassificationUrlsContainer**

Same pattern as A1. `ClassificationUrlsContainer` already wraps `<FlyoutProvider>`.
Add local state:

```typescript
const [selectedHost, setSelectedHost] = useState<ClassificationUrlItem | null>(null);
const [flyoutOpen, setFlyoutOpen] = useState(false);

const handleRowSelect = useCallback((host: ClassificationUrlItem) => {
  setSelectedHost(host);
  setFlyoutOpen(true);
}, []);

const handleCloseFlyout = useCallback(() => {
  setFlyoutOpen(false);
}, []);
```

Pass new props to `ClassificationUrlsBlock`.

**B2: Update ClassificationUrlsBlock.tsx**

Remove:
- `const { setFlyoutOpen } = useFlyoutContext();`
- `const { setSelectedHost } = useUrlsClassification();`

Accept new props: `onRowSelect: (host: ClassificationUrlItem) => void`

Replace `handleRowClick` internals with `onRowSelect(teamUrlData)`.

Also pass flyout props to `OrgHostDetailsPanel`:
- `isOpen={flyoutOpen}`, `selectedHost={selectedHost}`, `onClose={onCloseFlyout}`

**B3: Update OrgHostDetailsPanel.tsx**

Remove:
- `const { flyoutOpen, setFlyoutOpen } = useFlyoutContext();`
- `const { selectedHost } = useUrlsClassification();`

Accept new props: `isOpen: boolean`, `selectedHost: ClassificationUrlItem | null`, `onClose: () => void`

Same pattern as UserPanel (A5).

**B4: Remove FlyoutProvider from ClassificationUrlsContainer**

After all children are prop-driven, remove the `<FlyoutProvider>` wrapper.

**B5: Evaluate UrlsClassificationContext**

After B2-B3, check if `useUrlsClassification()` has any remaining consumers:
```bash
grep -rn "useUrlsClassification()" src/ --include="*.ts" --include="*.tsx" | grep -v "spec\." | grep -v "node_modules"
```

If zero: delete the provider + context. If other consumers exist (TeamBlock?),
document and keep.

### Phase C: Cleanup (0.25 session)

**C1: Delete FlyoutContext**

After both domains are migrated, `useFlyoutContext()` should have zero consumers.
Verify and delete `src/ui/providers/context/flyoutContext.tsx`.

**C2: Update CLAUDE.md exception list**

Remove all flyout-coordination exceptions. The remaining exceptions should
be only:
- Layout shells (DashboardLayout, SignedInPageShell, Sidebar, ProfileMenu)
- Auth boundary (TenantLogin, LoginForm/useLoginActions)
- Auth guards (RequireRoles, RequireLoginMaybe, Redirect)
- EditUserModal (react-hook-form exception -- mutations stay)

**C3: Update specs**

- `UsersContainer.spec.tsx` (442L): May need mock adjustments for the new
  state/callbacks. The 2 existing `it.todo` stubs may become testable once
  the container owns the state.
- `ClassificationUrlsContainer.spec.tsx` (249L): May need mock adjustments.
  Remove `UrlsClassificationProvider` wrapping if the context is deleted.

---

## Dependencies

| Phase | Depends on |
|-------|-----------|
| A (Users) | Nothing |
| B (URLs) | Nothing (independent of A) |
| C (Cleanup) | A + B both complete |

A and B can run in any order or in parallel.

---

## Effort Summary

| Phase | Sessions | Risk |
|-------|----------|------|
| A (Users domain) | 1.5 | Medium -- TanStack Table column threading for UserRoleSelect |
| B (URLs domain) | 0.5 | Low -- straightforward prop-passing |
| C (Cleanup) | 0.25 | Low -- deletion + docs |
| **Total** | **~2.25** | |

---

## Exit Criteria

- 0 leaf components call `useFlyoutContext()`, `useUsers()`, or `useUrlsClassification()`
- `FlyoutContext` deleted (zero consumers)
- `UsersContext` deleted (zero consumers)
- `UrlsClassificationContext` deleted or reduced (verify)
- `TeamUsersActions` mutation lifted to container
- Container specs updated and passing
- tsc clean, tests pass, build passes, ESLint clean
- CLAUDE.md exception list updated

---

## NOT in Scope

- InsightsContext selection state (selectedUser: MappedUserStats, selectedWorkstreams,
  selectedMicroworkflow, etc.) -- that is a completely different migration
  involving analytics drill-down state across the dashboard domain. Different
  types, different files, different contexts. Do not conflate.
- URL-param backing for flyout state -- flyout open/close is ephemeral UI
  state that correctly resets on navigation. No nuqs needed.
- BPO/Project structural duplication -- backlog item, not blocking.
