# DDAU Exception Elimination Plan

> Detail plan for removing documented DDAU exceptions in user-frontend.
> Corresponds to roadmap item 8.11 in `uf-phase-8-polish.md`.
> Created: 2026-03-03.
>
> Prerequisite: nuqs filter migration must be complete. The flyout coordination
> exceptions (7 files) are expected to be resolved by nuqs URL-backed state
> replacing FlyoutProvider-based coordination. Verify post-nuqs before starting.

---

## Current State: 13 Documented Exceptions

| # | File | Hook | Category | Planned Fix |
|---|------|------|----------|-------------|
| 1 | DashboardLayout.tsx | useAuthState, usePosthogContext, useLayout | Layout shell | Permanent |
| 2 | SignedInPageShell.tsx | usePathname, usePosthogContext, useLayout | Layout shell | Permanent |
| 3 | Sidebar.tsx | useAuthState, usePosthogContext, useLayout | Layout shell | Permanent |
| 4 | ProfileMenu.tsx | useAuthState | Layout shell | Permanent |
| 5 | UsersTable.tsx | useFlyoutContext, useUsers | Flyout coordination | nuqs migration |
| 6 | UserRoleSelect.tsx | useFlyoutContext, useUsers | Flyout coordination | nuqs migration |
| 7 | UserPanel.tsx | useFlyoutContext, useUsers | Flyout coordination | nuqs migration |
| 8 | Users.tsx | useUsers, useFlyoutContext, mutations | Flyout coordination | nuqs migration |
| 9 | TeamUsersActions.tsx | useRemoveUsersFromTeamMutation | Flyout coordination | nuqs migration |
| 10 | ClassificationUrlsBlock.tsx | useFlyoutContext, useUrlsClassification | Flyout coordination | nuqs migration |
| 11 | OrgHostDetailsPanel.tsx | useFlyoutContext, useUrlsClassification | Flyout coordination | nuqs migration |
| 12 | AddTeamForm.tsx | 3 mutations + 1 query | Form hooks | 8.11a |
| 13 | AddUserForm.tsx | 1 mutation + 1 query | Form hooks | 8.11a |
| 14 | EditURLsForm.tsx | 2 mutations | Form hooks | 8.11a |
| 15 | EditUserModal.tsx | 2 mutations + 1 query + useUsers | Form hooks + context | 8.11b |
| 16 | TenantLogin.tsx | useAuthState, useRouter | Auth boundary | 8.11c |
| 17 | LoginForm.tsx / useLoginActions.ts | useAuthState | Auth boundary | 8.11c |
| 18 | useChatApi.ts | useAuthState | Composite hook | 8.11d |
| 19 | SettingsNavigation.tsx | usePathname | Nav shell | 8.11e |

Target: 4 permanent exceptions remaining (items 1-4). All others eliminated.

---

## Post-nuqs Verification (GATE before starting 8.11)

Before executing any 8.11 work, verify the nuqs migration resolved the
flyout coordination exceptions. Run:

```bash
# Check if FlyoutProvider / useFlyoutContext still consumed by leaf components
grep -rn "useFlyoutContext\|FlyoutProvider" src/ui/page_blocks/ --include="*.ts" --include="*.tsx" | grep -v "spec\." | grep -v "Container"

# Check if useUsers context still consumed by leaf components
grep -rn "useUsers()" src/ui/page_blocks/ --include="*.ts" --include="*.tsx" | grep -v "spec\." | grep -v "Container"
```

If these return zero results for the 7 flyout files, nuqs resolved them.
If any remain, document what is left and adjust scope.

---

## 8.11a: Form Container Extraction (3 files)

### AddTeamForm.tsx

**File**: `src/ui/page_blocks/teams/AddTeamForm/AddTeamForm.tsx`

**Hooks to lift to container**:
- `useCreateTeamMutation` -- team creation
- `useAddTeamOwnersMutation` -- assign owners after creation
- `useAddUsersToTeamMutation` -- assign users after creation
- `useAssignableUsersQuery` -- populates user dropdown

**Decision: new container or absorb into TeamsListContainer?**
TeamsListContainer already manages teams list + search + remove mutation.
Adding 3 more mutations + 1 query to it is feasible but makes it wide.
Recommend: create `AddTeamFormContainer.tsx` as a sibling to TeamsListContainer
inside TeamsBlock. TeamsBlock renders both.

**Presentational form props** (after extraction):
```typescript
interface AddTeamFormProps {
  onCancel: () => void;
  onSubmit: (data: TeamFormData) => Promise<void>;
  isSubmitting: boolean;
  assignableUsers: User[];
  isLoadingUsers: boolean;
}
```

**Spec impact**: 0 dedicated specs. TeamsListContainer.spec.tsx may need
updates if it currently tests the add-team flow through rendered children.

**Skill**: `/refactor-react-component`

### AddUserForm.tsx

**File**: `src/ui/page_blocks/users/AddUserForm/AddUserForm.tsx`

**Hooks to lift**:
- `useAddUsersToTeamMutation` -- user assignment
- `useAssignableUsersQuery` -- populates user dropdown

**Decision**: Create `AddUserFormContainer.tsx` or absorb into UsersContainer?
UsersContainer is already wide (17 props after grouping). Recommend: create
a small container. TeamUsersActions (current parent) becomes presentational.

**Presentational form props**:
```typescript
interface AddUserFormProps {
  onCancel: () => void;
  onSubmit: (data: AddUserData) => Promise<void>;
  isSubmitting: boolean;
  assignableUsers: User[];
  isLoadingUsers: boolean;
  teamId: number;
  existingUsers: User[];
}
```

**Spec impact**: 0 dedicated specs.

### EditURLsForm.tsx

**File**: `src/ui/page_blocks/settings/Urls/EditURLsForm/EditURLsForm.tsx`

**Hooks to lift**:
- `useUpdateClassificationUrlsForTeamMutation`
- `useUpdateClassificationUrlsForOrgMutation`

**Decision**: ClassificationUrlsContainer already owns the read queries.
Adding 2 mutations to it is natural and keeps the container as the single
orchestration point. Recommend: absorb into ClassificationUrlsContainer
rather than creating a new container.

**Presentational form props**:
```typescript
interface EditURLsFormProps {
  organizationId: number;
  teamId: number | null;
  knownHosts: string[];
  unknownHosts: UnknownHostsShape;
  onCancel: () => void;
  onUpdate: (data: EditURLsData) => Promise<void>;
  isSubmitting: boolean;
}
```

**Spec impact**: 0 dedicated specs.

**Effort**: 1 session for all 3 forms. Mechanical -- the pattern is
identical each time.

---

## 8.11b: EditUserModal selectedUser Prop (1 file)

**File**: `src/ui/page_blocks/users/EditUserModal/EditUserModal.tsx`

**Context access**: `const { selectedUser } = useUsers()` (line 28)

**Hooks to lift** (in addition to selectedUser):
- `useUpdateUserMutation`
- `useAssignUsersMutation`
- `useTeamsListQuery`

**Decision**: selectedUser comes from UsersContext. After nuqs migration,
if useUsers is eliminated from the flyout coordination files, the context
may be simplified or removed. Check post-nuqs whether UsersContext still
exists and whether selectedUser is still provided by it.

If selectedUser is still in context: pass it as a prop from Users.tsx.
If UsersContext is gone: selectedUser lives in URL params (nuqs) and the
container reads it directly.

**Mutations**: These follow the react-hook-form exception pattern. The
prompt for 8.11b should decide whether to lift them to a container or
leave them (with a justification comment) since react-hook-form's onSubmit
needs direct mutation access for setError/isSubmitting integration.

**Spec impact**: 1 spec (EditUserModal.spec.tsx).

**Dependency**: Soft dependency on nuqs -- easier to scope after seeing
what nuqs changed in the Users domain.

**Effort**: 0.5 session.

---

## 8.11c: Auth Page Containers (3 files)

**Files**:
- `src/ui/components/8flow/TenantLogin/TenantLogin.tsx`
- `src/ui/components/8flow/LoginForm/LoginForm.tsx`
- `src/ui/components/8flow/LoginForm/useLoginActions.tsx`

**useAuthState consumption**:
- TenantLogin: `logInWithSamlProvider`, `logInWithGoogle`
- useLoginActions: `getTenantByEmail`, `getTenantByCompany`, `logInWithSamlProvider`

**Routing**: Both render on `/signin` (LoginForm is the parent, TenantLogin
renders conditionally when a tenant is selected). Single route = single
container opportunity.

**Assessment**: These operate at the pre-login boundary. Creating a
`LoginPageContainer` would:
- Own `useAuthState` and pass auth methods as props
- Own `useRouter` (currently in TenantLogin for post-login navigation)
- Pass tenant resolution methods to LoginForm
- Pass sign-in methods to TenantLogin

The question is whether this adds clarity. The current code is compact
and self-contained. Adding a container splits orchestration across files
for consistency but does not fix a bug or improve testability (the auth
methods are already tested via useAuthState's own tests).

**Recommendation**: Assess during implementation. If the container simplifies
testing or makes the auth flow more traceable, do it. If it just adds a file
with no behavioral benefit, document TenantLogin and LoginForm as permanent
auth-boundary exceptions (same category as the layout shells) and close.

**Spec impact**: 1 spec (TenantLogin.spec.tsx). LoginForm has 0 specs.

**Dependency**: None.

**Effort**: 1 session (includes assessment time).

---

## 8.11d: useChatApi Parameter Injection (1 file)

**File**: `src/ui/page_blocks/dashboard/chat/useChatApi.ts`

**useAuthState usage**: `auth.user?.getIdToken()` -- needs the user object
to obtain a Firebase ID token for API calls.

**Fix**: ChatContainer already calls `useAuthState`. Pass the user (or a
token getter) to useChatApi as a parameter:

```typescript
// ChatContainer
const { user } = useAuthState();
const { getChatResponse } = useChatApi({ getIdToken: () => user?.getIdToken() });
```

**Parameter interface**: Simple -- one function `getIdToken: () => Promise<string> | undefined`.

**Spec impact**: 0 dedicated specs for useChatApi. ChatContainer.spec.tsx
may need minor mock adjustment.

**Dependency**: None.

**Effort**: 0.25 session.

---

## 8.11e: SettingsNavigation Pathname Prop (1 file)

**File**: `src/ui/page_blocks/settings/ui/SettingsNavigation/SettingsNavigation.tsx`

**usePathname usage**: Reads pathname, passes to NavigationMenu component.

**Fix**: SignedInPageShell already reads `usePathname()` (line 17). It
conditionally renders SettingsNavigation (line 28). Pass pathname as a prop:

```typescript
// SignedInPageShell
{isSettingsPage && <SettingsNavigation pathname={pathname} />}

// SettingsNavigation
export function SettingsNavigation({ pathname }: { pathname: string }) {
  // remove usePathname() call
  return <NavigationMenu items={settingsPages} pathname={pathname} />;
}
```

**Spec impact**: 0 dedicated specs.

**Dependency**: None.

**Effort**: 0.1 session (2-line change).

---

## Dependencies

| Category | Depends on nuqs? | Depends on BFF? | Depends on other 8.11 items? |
|----------|------------------|-----------------|------------------------------|
| 8.11a (forms) | No | No | No |
| 8.11b (EditUserModal) | Soft -- easier after nuqs shows what happened to useUsers | No | No |
| 8.11c (auth) | No | No | No |
| 8.11d (useChatApi) | No | No | No |
| 8.11e (SettingsNavigation) | No | No | No |

All categories are independent of each other. 8.11a, 8.11c, 8.11d, 8.11e
can run in parallel or in any order. 8.11b benefits from running after nuqs
but is not blocked by it.

---

## Execution Order (recommended)

1. **8.11e** (SettingsNavigation) -- trivial, do first as warmup -- **DONE**
2. **8.11d** (useChatApi) -- small, quick win -- **DONE**
3. **8.11a** (form containers) -- largest, mechanical -- **DONE**
4. **8.11b** (EditUserModal) -- after nuqs verification -- **DONE**
5. **8.11c** (auth pages) -- assess last, may close as permanent -- **CLOSED as permanent**

---

## Effort Summary

| Item | Sessions | Risk | Status |
|------|----------|------|--------|
| 8.11a | 1 | Low (mechanical pattern) | **DONE** |
| 8.11b | 0.5 | Medium (depends on nuqs outcome for useUsers) | **DONE** |
| 8.11c | 1 | Low (may close as permanent) | **CLOSED** -- permanent auth-boundary exception |
| 8.11d | 0.25 | Low | **DONE** |
| 8.11e | 0.1 | None | **DONE** |
| **Total** | **~3** | | **Completed in 1 session** |

---

## Completion Summary (2026-03-03)

4 commits:
- `ca8c6f73`: 8.11e -- SettingsNavigation pathname prop
- `ccb5d5a2`: 8.11d -- useChatApi getIdToken parameter injection
- `d4f470ff`: 8.11a -- 3 form container extractions
- `e75d9a25`: 8.11b -- EditUserModal selectedUser prop

Post-nuqs gate check: all 7 flyout coordination files (items 5-11) still
have violations. Separate migration needed for selection state to URL params.

8.11c closed as permanent auth-boundary exception: TenantLogin, LoginForm,
useLoginActions operate at the pre-login boundary. No authenticated container
can wrap them. Creating a LoginPageContainer would shuffle hooks up one level
with no testability or clarity improvement.

---

## Exit Criteria -- ALL MET

- 4 permanent layout exceptions remain (DashboardLayout, SignedInPageShell,
  Sidebar, ProfileMenu) -- YES
- 0 eliminable exceptions remain -- YES (auth pages reclassified as permanent)
- Auth pages explicitly reclassified as permanent auth-boundary exceptions
  with documented justification -- YES
- All forms are container-presentational pairs -- YES (3 containers created)
- useChatApi takes auth values as parameters -- YES (getIdToken injection)
- SettingsNavigation receives pathname as prop -- YES
- tsc clean, tests pass, build passes, ESLint clean -- YES
- CLAUDE.md exceptions list updated to reflect final state -- YES
