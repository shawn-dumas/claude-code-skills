# Phase 3: Provider Stripping

> Reduce all context providers to narrow, stable UI state. No provider
> should fetch data, show toasts, navigate, or touch storage.

## Prerequisites

- Phase 2 complete (all data-fetching extracted to service hooks)

**If working domain-at-a-time**: complete Phase 2 for a domain before
starting Phase 3 for that domain. Verify these service hooks exist:

| Domain | Required hooks from Phase 2 |
|--------|---------------------------|
| Teams | `useTeamsQuery`, `useTeamUsersQuery`, team mutation hooks |
| Users | `useUsersQuery`, `useAssignableUsersQuery`, user mutation hooks |
| BPO/Projects | `useGetAllGroupsQuery`, BPO mutation hooks |
| URL Classification | `useClassificationUrlsQuery`, classification mutation hooks |
| Company | `useCompanyStatusQuery` |
| Company Data | 11 query hooks (events, spans, kpis, microworkflows, etc.) |
| Insights | 10 query hooks (getHostTime, getOperationalAnalysis, etc.) |
| Filter infrastructure | `useFilterStore` (nuqs-backed), `useSelectedWorkstreams` |

## Skill Protocol

All build and refactor work uses `.claude/skills/`. Do not do this work manually.

- **Before stripping any provider**: run `/audit-react-feature` on its directory
- `/refactor-react-provider` for each provider being stripped (steps 3.2-3.5)
- Exception: deletion of empty provider directories after extraction is manual

## Exit Criteria

- No provider calls service hooks, shows toasts, navigates, or touches storage
- Each surviving provider holds at most 2-3 pieces of stable UI state
- `pnpm tsc --noEmit` clean
- Run `/audit-react-feature` on each provider directory -- zero violations

## Provider Inventory (from NGA experience)

NGA stripped or deleted these providers. UF has the same ones plus extras.

### Providers to DELETE entirely

| Provider | UF location | What replaces it |
|----------|-------------|------------------|
| InsightsContextProvider | `context/insightsContext/` | `useFilterStore` (nuqs-backed) + standalone service hooks. This is the biggest provider and the hardest to strip. |
| BpoProjectProvider | `context/bpoProjectsContext/` | Service hooks from Phase 2 |
| TeamsContextProvider | `context/teamsContext/` | Service hooks from Phase 2 |
| UrlClassificationProvider | `context/urlClassification/` | Deleted in Phase 2.11 (should already be gone) |
| UsersContextProvider | `context/usersContext/` | Deleted in Phase 2.10 (should already be gone) |
| FlyoutProvider | `context/flyoutContext.tsx` | Local `useState` in teams/users containers (NGA deleted this) |
| SelectedItemsProvider | (if present) | Dead code -- mounted but hook never called (NGA deleted this) |

### Providers to KEEP but STRIP

| Provider | UF location | What stays | What gets removed |
|----------|-------------|------------|-------------------|
| CompanyScopeProvider | `context/companyContext/` | `selectedCompany`, `setSelectedCompany` | Any data-fetching, any status queries |
| AuthStateProvider | `providers/auth/` | Firebase auth state, user info, role | Any redundant useEffects, dead code |
| PosthogProvider | `providers/posthogProvider.tsx` | PostHog init + identify | Should already be clean |
| QueryClientProvider | `providers/queryClient.tsx` | TanStack Query client | Should already be clean |
| ThemeProvider | `providers/theme.tsx` | Theme state | Should already be clean |

### Providers to ASSESS (UF-only, NGA did not have these)

| Provider | UF location | Decision criteria |
|----------|-------------|-------------------|
| GlobalUiProvider | `context/globalUi.tsx` | If it holds sidebar/modal state, keep as thin UI provider. If it fetches or has effects, strip/delete. |
| LayoutProvider | `context/layout/` (6 files) | If DashboardLayout container can own this state, delete. If it's genuinely cross-cutting UI state (sidebar collapsed, breakpoint), keep. |

## Execution Order

### 3.1: Audit remaining providers

Run `/audit-react-feature` on `src/ui/providers/`. Classify each provider
by what it still owns:
- Data fetching (useQuery/useMutation calls)
- Toast calls
- Router/navigation calls
- Storage access (localStorage/sessionStorage)
- Pure UI state

This audit drives the rest of the phase.

### 3.2: Strip InsightsContext (LARGEST ITEM)

**Use `/refactor-react-provider`** on InsightsContextProvider.

This was the hardest provider to strip in NGA. It likely owns:
- Filter state (teams, dates, workstreams, exclusions)
- Multiple useQuery calls
- Adapter functions that transform API data
- usePagesStateReducer (7 files of reducer logic)
- Cross-domain state (selected tab, selected system, etc.)

**NGA's approach**:
1. Created `useFilterStore` backed by nuqs (URL params)
2. Moved each data query to a standalone service hook
3. Moved adapter logic to `src/ui/utils/` pure functions
4. Deleted the entire provider + its utils/adapters/ directory
5. Each consumer (container) calls service hooks directly

**Files to delete after stripping**:
```
context/insightsContext/InsightsContext.tsx
context/insightsContext/usePagesStateReducer/  (7 files)
context/insightsContext/utils/adapters/  (many sub-modules)
context/insightsContext/utils/refreshTeamsInFilters/
context/insightsContext/constants.ts
context/insightsContext/types.ts
context/insightsContext/index.ts
```

### 3.3: Strip TeamsContext

**Use `/refactor-react-provider`** if TeamsContextProvider still exists.
Move any remaining data-fetching to service hooks. If TeamsContextProvider
still exists after Phase 2, delete it. Team data comes from
`useTeamsQuery()` called in containers.

### 3.4: Strip BpoProjectsContext

**Use `/refactor-react-provider`** if it still exists after Phase 2. Delete it.

### 3.5: Assess and resolve UF-only providers

Run `/audit-react-feature` on each before deciding. Use `/refactor-react-provider`
to strip any that need it.

**GlobalUiProvider**: Read the file. If it's just `{sidebarOpen, setSidebarOpen}`,
keep it. If it has effects or fetching, strip.

**LayoutProvider** (6 files): This likely manages dashboard layout state
(selected tab, filter collapse, sidebar). In NGA, this was absorbed into
`DashboardLayout` container + `useFilterCollapse` hook. Same approach here:
move the state into the layout container in Phase 4, then delete this provider.

### 3.6: Run convergence audit

Run `/audit-react-feature` on `src/ui/providers/` again. Verify:
- Zero data-fetching calls
- Zero toast calls
- Zero navigation calls
- Zero storage access
- Each provider's context value is a plain object with 2-3 fields max

## NGA Commit History Reference

- `ab28cfa1`: Strip InsightsContextProvider, replace with useFilterStore + standalone hooks
- `366c7237`: Remove useInsightsContext from 6 containers, extract useSelectedWorkstreams
- `30554ee5`: selectedUser to URL, slim InsightsContext filter state
- `26e836ca`: Phase 3: Provider and context cleanup
- `eb9c93c6`: Clean up AuthStateProvider dead code and redundant useEffect
- `488dd626`: Delete dead SelectedItemsProvider
