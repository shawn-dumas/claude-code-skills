# user-frontend DDAU Refactor Roadmap

> Porting the next-gen-atlassian (NGA) architecture into user-frontend (UF).
> Starting from scratch on `~/github/user-frontend` branch `sd/productionize`.
>
> Created: 2026-02-26. Updated: 2026-03-05 (Bug bash Round 1 DONE. HEAD `34997ed8`).
> Addendum: 2026-03-01 -- Full codebase audit (6 audit types, 28 agents). Gap items folded into Phase 7 pre-work + Phase 8. See `~/plans/uf-audit-gap-addendum.md` for full analysis.
> Second audit: 2026-03-01 21:05 (7 audit types, 29 agents). Post-Session-6 re-audit. Report: `~/audits/26-03-01-21-05--user-frontend--complete-audit.md`. Supersedes first audit for current state. Found 5 new bugs, 4 production CVEs, 10 dead npm deps, 47 dead fixture exports.
> Source: 22 archived plans + structural diff of both repos (see `archive/`).
> Selected ordering: **Option A (Architecture First)**.

## Progress Dashboard

<!-- Regenerated after each reconciliation. Metrics from live repo checks. -->

```
Phase 1: Foundation                    [##########] 100%  COMPLETE
Phase 2: Service Hook Extraction       [##########] 100%  COMPLETE
Schema Derivation                      [##########] 100%  COMPLETE
Phase 3: Provider Stripping            [##########] 100%  COMPLETE
Phase 4: Container Boundaries          [##########] 100%  COMPLETE
  4.1 Route containers (22)            DONE
  4.2 DashboardLayout split            DONE
  4.4 Filter containers (4)            DONE
  4.5 useQueryClient residual          DONE
  4.6 Props-only leaf audit            DONE
  4.10 Domain merges (3)               DONE
  4.7 ECharts migration                DONE
  4.8 papaparse migration              DONE
Phase 5: God Component Decomposition   [##########] 100%  COMPLETE
  5.1-5.5 (god components)              N/A (Phase 4 eliminated all targets)
  5.6 JSX flattening (3 files)          DONE (TableFilter 51L, InsightsFilters 27L, Sidebar 33L)
  5.A Icons.tsx split                   DONE (630L -> 3L barrel + 3 sub-files)
  5.E Table type extraction             DONE (358L -> 274L + 96L types file)
Phase 6: Type Safety + Cleanup         [##########] 100%  COMPLETE
  6.1 any elimination (3+8 SVG casts)  DONE  (Session 2: 3 explicit + 8 SVG casts)
  6.2 Enum conversion                  PASS (0 enums, converged since Phase 1)
  6.3 useEffect elimination (15/20)    DONE  (Session 4: 9 eliminated + Session 4b: 6 consolidated)
  6.4 Catch clause annotation (32)     DONE  (Session 2: 32 across 17 files)
  6.5 Trust boundaries (4 mandatory)   DONE  (Session 3: 4 JSON.parse + Zod)
  6.6 Console cleanup                  DONE  (Session 5: 3 calls converted/removed)
  6.7-6.8 Convergence audit            DONE  (Session 5: 14/14 dashboard/settings/teams, 13/14 users pre-existing)
  6.x ESLint 0 warnings                DONE  (Session 2: --max-warnings 0 passes)
  6.x eslint-disable review            DONE  (Session 5: all disables justified or narrowed)
  6.x File-level eslint-disable        DONE  (Session 2: useKeepRowsSelection.tsx)
  6.x Exception documentation          DONE  (Session 2: CLAUDE.md updated)
  Convergence: 14/14
Phase 7: Test Suite                    [#######   ]  65%  PAUSED (Sessions 2-6 done, 7-9 deferred post-Phase 8. 26/26 containers + 17/17 mappers + infra tested)
Phase 8: Polish + Ship                 [##########] 100%  COMPLETE (8.0a-8.0h + 8.1-8.6 + 8.7 bug bash + 8.9-8.11 + 8.13 + nuqs + cross-page nav DONE)

Overall                                [######### ]  97%

Build + Quality
  tsc: 0 errors | ESLint: 0 err / 0 warn | Build: PASSES
  Tests: 2345 pass | Specs: 192 | Coverage: ~58%

Architecture
  Containers: 29 (29/29 tested) | Convergence: 14/14
  Contexts: 3 remaining (auth, posthog, teams) | Selection contexts: 0
  DDAU violations: 1 (TeamUsersActions carry-forward)
  useEffects: 24 | Non-null assertions: 0
  Cross-domain coupling: ~10 | Type re-exports: 0
  Raw localStorage: 4 (featureFlagsCache exempt) | Enums: 0
  Files >500L: 0 | JSX >100L: 0 | forwardRef: 0

Stack
  Next.js 15.5.12 | React 19.2.4 | TypeScript 5.9.3
  ESLint 10.0.2 | Vite 7.3.1 | Vitest 4.0.18
  Tailwind CSS 4.2.1 | ECharts 6.0.0 | Storybook 10.2.14
  next-themes 0.4.6 | react-flatpickr 4.0.11 | posthog-js 1.357.1
  jsdom 28.1.0 | concurrently 9.2.1 | dotenv 17.3.1

Dependencies
  Prod: 22 | Dev: 56
  Dead deps removed: 13 (8 prod + 5 dev)
  Misplaced deps moved to dev: 5 (+react-query-devtools)

Security
  4/4 CVEs patched. All resolved.
  - 3 Next.js DoS CVEs: FIXED (15.5.12, done in 8.1)
  - posthog-js VNode injection: FIXED (1.357.1, done in 8.4)
  - N19 auth token to NR: FIXED (8.0h)

Remaining Debt
  Dead exports: ~91
  any: 4 (2 justified, 1 reducible, 1 Storybook)

PR Blockers
  Browser bug bash: DONE (Round 1, 2026-03-05). 14/20 routes passed.
    6 feature-flag-gated routes untested (PostHog returns false for emulator user).
    Prompt: ~/plans/prompts/backlog-06-bug-bash.md (reusable for Round 2+).
  Remaining: B10 (coverage gap fill), integration tests (e2e-04 through e2e-06).

HEAD: 34997ed8
```

## Current Status

### Completed Phases

| Phase | Summary |
|-------|---------|
| **1. Foundation** | Types, utils, hooks, fixtures, fetchApi, skills, config. tsc + build clean. |
| **2. Service Hooks** | 105 hooks / 200 files in per-directory format. Zero useQuery/useMutation in providers or page_blocks. Factories deleted. react-hot-toast replaced with sonner. |
| **Schema Derivation** | ~120 types derived from Zod schemas. Zero hand-written API interfaces. |
| **Provider Type Consolidation** | insightsContext, usersContext, urlClassification types consolidated. Provider types.ts files reduced to re-exports. |
| **3. Provider Stripping** | All providers state-only. Adapters co-located with service hooks. Dead code deleted. |
| **4. Container Boundaries** | 26 containers. All leaves props-only. Detail below. |
| **5. God Component Decomposition** | Icons.tsx split (630L -> 3 sub-files + barrel). 3 JSX flattenings (TableFilter 51L, InsightsFilters 27L, Sidebar 33L). Table type extraction (274L + 96L types). Files >500L: 0. JSX >100L: 0. |

### Phase 4 Breakdown

| Item | Status | Key outcome |
|------|--------|-------------|
| 4.1 Route containers | DONE | 22 containers (Groups A-E: 12 dashboard + 7 non-dashboard + 3 renamed) |
| 4.2 DashboardLayout | DONE | Container + presentational split, filter routing via resolveFilterComponent |
| 4.3 AnalysisLayout | N/A | No analysis pages in UF |
| 4.4 Filter containers | DONE | 4 containers (Insights, Opportunities, Workstreams, Realtime) |
| 4.5 useQueryClient | DONE | Lifted from 3 page_blocks + InsightsContext. refreshData eliminated. |
| 4.6 Props-only audit | DONE | DashboardNavigation lifted, Users tree lifted, 4 sub-containers renamed |
| 4.7 ECharts | DONE | PieChart rewritten, 17 dead files deleted, recharts + chart.js removed |
| 4.8 papaparse | DONE | CSVButton rewritten, react-csv removed |
| 4.9 Missing page blocks | DONE | Merged into 4.1 |
| 4.10 Domain merges | DONE | classificationUrls -> settings/Urls, opportunity -> opportunities, workstreams-analyzer -> workstream-analysis/analyzer |

Sub-plan: `~/plans/uf-phase-4-container-boundaries.md`

### Documented Exceptions (not violations)

| File | Hook | Reason | Planned Fix |
|------|------|--------|-------------|
| DashboardLayout.tsx, SignedInPageShell.tsx, Sidebar.tsx | useAuthState, usePosthogContext, useLayout | Layout shell -- no parent container exists | Permanent |
| ProfileMenu.tsx | useAuthState | Layout-adjacent -- auth-driven identity display + logout | Permanent |
| SettingsNavigation.tsx | usePathname | Navigation-shell | 8.11e (2-line prop pass) |
| useChatApi.ts | useAuthState | Composite hook, consumed only by ChatContainer | 8.11d (parameter injection) |
| UsersTable.tsx, UserRoleSelect.tsx, UserPanel.tsx | useFlyoutContext, useUsers | Flyout-coordination | nuqs migration (URL-backed selection) |
| Users.tsx | useUsers, useFlyoutContext, useAssignUsersMutation, useAssignUsersToProjectsMutation | FlyoutProvider scope | nuqs migration |
| TeamUsersActions.tsx | useRemoveUsersFromTeamMutation | Carry-forward | nuqs migration |
| ClassificationUrlsBlock.tsx | useFlyoutContext, useUrlsClassification | Provider scope constraint | nuqs migration |
| OrgHostDetailsPanel.tsx | useFlyoutContext, useUrlsClassification | Provider scope constraint | nuqs migration |
| AddTeamForm.tsx, AddUserForm.tsx, EditURLsForm.tsx | query/mutation hooks | react-hook-form -- forms own their mutations | 8.11a (container extraction) |
| EditUserModal.tsx | query/mutation hooks, useUsers | react-hook-form + useUsers | 8.11b (selectedUser prop) |
| TenantLogin.tsx | useAuthState, useRouter | Auth page -- no container boundary pre-login | 8.11c (assess) |
| LoginForm.tsx / useLoginActions.ts | useAuthState, mutations | Auth orchestration | 8.11c (assess) |

Removed from exceptions (verified compliant, no hook calls):
- ~~AccessDenied.tsx~~ -- receives `onLogOut` as prop (fixed in 8.0-pre)
- ~~EditAssignmentModal.tsx~~ -- receives all data as props (fixed in 8.0-pre)
- ~~SidebarLink.tsx~~ -- receives `isActive` as prop (fixed in 8.0-pre)

### Reconciliation Cadence

Run after each session group (every 2-3 sessions). Checks: commit coverage, numeric accuracy, DDAU boundary sweep, tsc/test/build green, orphaned containers.

## Progress Log

All work on branch `sd/productionize`, diverging from `production` at `cfca1ab5`.

| Commits (chronological) | Roadmap items | Summary |
|--------------------------|---------------|---------|
| `c322f025` | 1.0a | Port CLAUDE.md from NGA |
| `a16734ad` | 1.0b | Port .claude/skills/ (31 skills + README), delete commands/ |
| `ba44b943` | 1.0d | Port tsconfig.eslint.json, align ESLint config and pre-commit |
| `4efc223e` | 1.0e | Add path aliases (@/fixtures, @/services, @/hooks, @/utils, @/constants/testIds) |
| `d9387697` | 1.0f | Align vitest config (pool: forks, worker limits, teardownTimeout, coverage) |
| `725e4ef2`, `9406665e`, `8f6c75c2` | 1.0g | Port AGENTS.md (symlink to CLAUDE.md), add LLM instruction symlinks |
| `2cd9a348` | 1.0h | Delete 9 dead root files |
| `81e49fa6` | 1.1a | Port src/shared/types/ (44 files, grew to 47 during schema derivation) with type reconciliation |
| `2ca0f6b9` | 1.1b | Port shared utils (typedStorage, queryParams, map, metadata, time, date) |
| `839ab3c8` | 1.1c | Port shared navigation (4 files) and cleanup-registry |
| `b27dee58` | 1.1d | Port shared hooks (5 hooks) |
| `3d30d216` | 1.1e | Port shared UI components (5 components) |
| `02748d6b` | 1.1g | Port src/ui/constants/testIds.ts |
| `38bac270` | 1.1i | Replace src/shared/mocks/ with src/shared/test-utils/ (13 files) |
| `ca95047d`, `bcf04658` | 1.x fix | Polyfill localStorage for Node 22+, fix 8 test failures |
| `730c0de9` | 1.2a | Install new deps (@faker-js/faker, nuqs, reactflow, papaparse, sonner, etc.) |
| `e47b454a` | 1.2b | Port src/fixtures/ (19 files: 15 domains + brand, identity-pool, scenario, index) |
| `db960cd0`, `e6809185` | 1.2d | Reconcile fetchApi with NGA architecture, make schema required |
| `5aaea51a` | 1.2c | Port mock handler (pages/api/mock/[...endpoint].ts) |
| `d73497c1` | 1.0c | Disable Chromatic CI on sd/productionize during DDAU refactor |
| `bb46e5ba` | 1.0 bonus | Delete .ai/ directory (Cursor/Windsurf rules no longer used) |
| `ab8f0e29` | 1.1h | Assess companyContext -- not needed for UF |
| `fc00bb02` | 1.3 | Port UF-relevant docs from NGA (2 files) |
| `21994a5b` | 2.2 + 2.5 | Create service hooks directory structure and query key modules (5 key files) |
| `7e773012`, `92e25abc` | 2.3 | Extract query hooks: users, teams, bpo-projects, url-classification, 27 insights queries |
| `9a248cb8` | 2.4 | Extract 19 mutation hooks across 4 domains |
| `6bbeed4b` | 2.7 | Replace react-hot-toast with sonner |
| `2c9dbc32` | 2.8 bonus | Replace isRequesting with isFetching across all consumers |
| `064bf216` | 2.8 | Delete createQueryFactory/createMutationFactory and utils/api/ |
| `1a5d0a94` | 2.10 | Strip usersContext to state-only, rewire 9 consumers to service hooks |
| `041aae8e` | 2.11 | Strip urlClassification to state-only, rewire 3 consumers |
| `36f81a74`..`7322ef3e` | R1 (post-2) | Restructure all 5 domains' hooks to per-directory format |
| `1ca24a59` | R2 (post-2) | Replace z.unknown() with real Zod schemas in insight query hooks |
| `516fa760`, `63e1fb7e` | R3 (post-2) | Rewire consumers to import from service layer directly, strip 44 hook pass-throughs from providers |
| `92bd52f2` | 6.5 partial | Remove .passthrough() from all 139 Zod schema calls (16 files) |
| `389d869e`..`48b3ca27` | 1.1a + 6.5 | Derive ~110 types from Zod schemas across 12 domains, eliminate all `as ZodType` casts |
| `4f73dcd6` | 1.1a + 6.5 | Widen fetchApi schema parameter to decouple input/output types |
| `4e8540b7`..`5fc92825` | 1.1a + 6.5 | Derive remaining domain types (Team, Group, auth, classification, UserRoles, WorkstreamData) |
| `eecc3d9c` | 1.1a + 6.5 | Derive UserTeamData (isTeamOwner: nullable -> boolean normalization) |
| `996a3c44` | 1.1a + 6.5 | Derive User from UserSchema, remove as-casts |
| `b433b09e` | 1.1a + 6.5 | Derive analyzer domain (9 types, was skipped in earlier pass) |
| `10069d34` | cwb 4a | Consolidate insightsContext types into shared layer re-exports (~700L moved, types.ts -> ~299L) |
| `39a5b5ce` | cwb 4b (partial) | Consolidate usersContext types: delete 6 dead types, re-export 6 shared, delete constants.ts |
| `71dd350d` | cwb 4c (partial) | Consolidate urlClassification types: re-export shared, delete constants.ts |
| `c3e82280` | cwb 4b (complete) | Branded MappedUpdateUserParams, co-locate mapUsers with useUsersListQuery |
| `850d7d42` | cwb 4c (complete) | Move UNCLASSIFIED_CATEGORY + MappedClassificationUrlItem to shared, co-locate mapClassificationUrlItems |
| `83728b18` | 3.1 + 3.3 | Strip teamsContext: types.ts to re-export shim, delete constants.ts, add branded constructors at form boundaries |
| `f63be29d` | 3.1 + 3.4 | Strip bpoProjectsContext: delete dead provider (zero consumers), types.ts to re-export shim, remove wrapper from 4 files |
| `2fc7b6d1` | 3.1 + 3.5 | Assess layout/flyout/globalUi: already compliant. Delete dead globalUi.tsx, remove 'use client' from flyoutContext |
| `eaa985dd` | 3.2 | Delete dead insightsContext constants.ts (Routes + duplicate insightsQueryKeys). 116L deleted. |
| `5df23844` | 3.2 | Strip InsightsContextProvider: remove localStorage read/write, teams sync useEffect, refreshTeamsInFilters |
| `a0cd6f18` | 3.2 | Co-locate 15 adapter functions with sole service hook consumers (48 files changed) |
| `ba39cd8d` | 3.2 | Delete dead refreshTeamsInFilters/ (3 files) after provider strip. 1,397L deleted. |
| `bda82496` | 3.2 fix | Restore queryParams testUtils.ts (erroneously deleted -- consumed by queryParams.spec.ts) |
| `1f26bfbb` | 4.2 | Split DashboardLayout into container (EightFlowDashboardLayout) + presentational (DashboardContent). Filter routing via resolveFilterComponent with TypeScript narrowing. |
| `a1357691` | 4.4.1 | Extract InsightsFiltersContainer. Lift useInsightsContext, useTeamsListQuery, useAuthState, usePosthogContext, useDashboardFiltersState, localStorage, analytics into container. |
| `a4bfc67f`, `96613007` | 4.4.2 | Extract OpportunitiesFiltersContainer. Same pattern as 4.4.1 for opportunities/systems variant. |
| `00dbd3ee` | 4.4.3 | Extract WorkstreamsFiltersContainer. Lift useInsightsContext, useUsersListQuery, useDashboardFiltersState, localStorage, analytics. |
| `3cf5090d`, `984d89ce` | 4.4.4 | Extract RealtimeFiltersContainer. Lift useInsightsContext, useTeamsListQuery, localStorage, analytics. Update spec import. |
| `a0c996be` | punch list | Fix ESLint non-nullable-type-assertion-style in getDashboardNavItems spec. Delete src/types.ts bridge, rewire 4 consumers. |
| `4eb12f92` | punch list | Move src/ui/constants.ts into src/ui/constants/index.ts (resolve file/directory collision). |
| `c8715fea` | punch list | Migrate 4 storage files to typedStorage (useCheckExpirationInterval, useSorting, Table, TenantLogin). |
| `6c1b1870` | punch list | Migrate dashboard/utils/storage.ts to typedStorage. |
| `7cc4a818` | punch list | Fix all test failures: storage migration breakage (schema/error-handling/mock) + 3 filter specs (add vi.mock for useTeamsListQuery). 0 failures, 1899 tests pass. |
| `6df769e8` | 4.1.1 | Create FavoriteUsageContainer. Lift useInsightsContext + 3 service hooks from Block/SystemAggregate/UserDetails into container. Block + children converted to props-only. Barrel alias preserves public API. |
| `c1114eb4` | 4.1.2 | Create RelayUsageContainer. Same pattern as 4.1.1 for relay domain. Lift useInsightsContext + 3 relay service hooks into container. Block + children converted to props-only. |
| `e52993b9` | 4.1.3 | Create TeamProductivityContainer. Absorb useInsightsContext (isHours + filters.teamProductivity) + useOperationalAnalysisQuery from page file. Thread isHours as prop to OperationalHoursTable + OperationalHoursBy. Page reduced to thin wrapper. |
| `382336a6` | 4.1.3 fix | Add deviation comment to TeamProductivityContainer (OperationalHoursBy keeps own service hooks per sub-plan, not absorbed into container). |
| `b2c798ea` | 4.1.5 | Create ProductivityContainer. Absorb useInsightsContext (isHours, filters, selectedUser, setSelectedUser) + useTeamsHostTimeQuery + useMaintainSelection. Thread isHours + userProductivityFilters as props through 7 child components. Barrel alias preserves public API. |
| `62effd6f` | 4.1.6 | Create MicroworkflowsContainer. Absorb useInsightsContext (5 selections + filters.opportunities) + useMicroworkflowsQuery + useRouter + usePosthogContext + useLayout. Extract cross-domain onNavigateToWorkstreamAnalyzer callback. MicroworkflowDetailsTable props made optional for SystemsOccurrences compatibility. |
| `bc1bd1d5` | 4.1.7 | Create WorkstreamsAnalyzerContainer. Absorb useInsightsContext (filters.workstreamAnalyzer + selectedAnalyzerWorkstream) + useAnalyzerWorkstreamsQuery + auto-select useEffect. Block + children converted to props-only. |
| `8dbee2cd` | 4.1.8 | Create WorkstreamAnalysisContainer. Lift all context + service hooks from WorkstreamsTable, WorkstreamDetails, SystemAnalysis, ActionsTable into container. Eliminates onLoading callback bridge. Page reduced to thin wrapper. |
| `9ab5c568` | 4.1.9 | Create ChatContainer. Lift usePosthogContext, useRouter, useChatApi, feature flag redirect useEffect from page + Chat into container. Chat receives getChatResponse as prop. |
| `8031a9bf` | 4.1.10 | Create RealtimeActivityContainer. Move all page logic (~100L) into container: useInsightsContext, useTeamRealtimeStatsQuery, useFeatureFlagPageGuard, timer countdown, filter toggle, data filtering, date derivation. |
| `52d77b7e` | 4.1.11 | Create SystemLatencyContainer. Lift all 3 service hooks (useTopUsedQuery, useAvgLatencyByHostQuery, useTimeByHostQuery) + useInsightsContext + selection state into container. Flatten 3-level drill-down. AvgLoadTime + LoadTimeByUser props-only. |
| `408f84e6` | 4.1.12 | Create SystemsContainer. Deepest hierarchy -- lifts usePagesStateReducer, useInsightsContext, useSystemPagesQuery, feature flag redirect, 6 selection states. 3-level drill-down (Systems > Pages > Users) passed as props. |
| `44c2c3a3` | 4.1.13 | Create TeamsListContainer. Absorb useTeamsListQuery, useRemoveTeamsMutation, useKeepRowsSelection, search + modal state. TODO(4.5) on AddTeamForm useQueryClient. |
| `598c2d7d` | 4.1.14 | Create TeamDetailContainer. Absorb useRouter (teamId), useTeamsListQuery, useUpdateTeamMutation, edit modal state, PostHog tracking. |
| `62a27ed7` | 4.1.15 | Create UsersContainer. Wraps FlyoutProvider, absorbs useAuthState + 3 query hooks + useKeepRowsSelection + search. Users.tsx keeps mutations (need FlyoutProvider scope). Delete dead UsersBlock.tsx. |
| `a159c32b` | 4.1.16 | Create AccountContainer. Trivial -- extract useAuthState, pass userInfo as prop. |
| `f768631b` | 4.1.17 | Create ProjectContainer. Absorb useGetAllProjects + 3 mutation hooks + useKeepRowsSelection + search + 3 modal states. |
| `73b693ea` | 4.1.18 | Create BPOContainer. Same pattern as ProjectContainer for BPO domain. |
| `7cc5216b` | 4.1.19 | Create ClassificationUrlsContainer. Absorb useRouter + useAuthState + useClassificationUrlsQuery + data-sync useEffect + useKeepRowsSelection + filters. Block keeps useFlyoutContext + useUrlsClassification + useQueryClient (TODO 4.5). |
| `71157a9e` | 4.5.1 | Lift useQueryClient from AddTeamForm into TeamsListContainer. |
| `08808480` | 4.5.2 | Lift useQueryClient from AddUserForm into UsersContainer. |
| `20a3aebc` | 4.5.3 | Lift useQueryClient from ClassificationUrlsBlock to ClassificationUrlsContainer. Block now receives onCategoriesUpdate callback prop. |
| `ec6aa479` | 4.5.4 | Remove useQueryClient from InsightsContext provider. refreshData eliminated. Cache invalidation moved to 4 filter containers + WorkstreamAnalysisContainer. 12 files changed. |
| `7221f8cd` | 4.6.1 | Make DashboardNavigation props-only: lift usePathname + usePosthogContext to Header.tsx, pass pathname + featureFlags as props. |
| `1455b328` | 4.6.2 | Make users leaf components props-only: lift useRouter, useAuthState, usePosthogContext, useUsersListQuery from TeamUsersActions, UserPanel, UserRoleSelect, UsersTable into UsersContainer. 7 files, +72/-32. |
| `242ab75b` | 4.6.3 | Rename 4 dashboard leaf data-fetchers to *Container: ActivityTimelineTable, MicroworkflowsByUserTable, MicroworkflowDetails, ProductivityByDate. 10 files, mechanical rename + barrel/import updates. |
| `746c24c4` | 4.10.1 | Move classificationUrls/ to settings/Urls/. Update 2 import sites (urls.tsx page, TeamBlock.tsx). 31 files. |
| `ded67484` | 4.10.2 | Rename opportunity/ to opportunities/. Update 10 import sites across dashboard barrel, DashboardLayout, systems, workstreams-analyzer, insightsContext types/queryParams. 48 files. |
| `f27df503` | 4.10.3 | Merge workstreams-analyzer/ into workstream-analysis/analyzer/. Update dashboard barrel to source through workstream-analysis/. Fix relative import for dashboard constants. 14 files. |
| `a89cc661` | 4.7.1 | Rewrite PieChart from recharts to echarts-for-react. Same PieChartProps<T> interface preserved. Fix ProductivityByDateContainer barrel orphan in team/index.ts. |
| `17a86f9c` | 4.7.2 | Delete 17 dead files: PieChart sub-components (ActiveShape, CustomizedLabel, PieChartCustomTooltip), CustomLegend, WorkstreamChart (zero consumers), legend utils, types.ts, dead constants. 402L deleted. |
| `7f1aa328` | 4.7.3 | Remove recharts + chart.js from package.json. 17 transitive packages removed. Zero imports remain. |
| `295e63c2` | 4.8.1 | Replace react-csv with papaparse in CSVButton. Papa.unparse() + Blob URL download replaces CSVLink. TableHeader updated to local CSVHeaders type. |
| `eb5a571d` | 4.8.2 | Remove react-csv + @types/react-csv from package.json. Zero react-csv imports remain. Phase 4 100% complete. |
| `b9001d0d` | 5.A | Split Icons.tsx (630L) into 3 domain-grouped sub-files (NavIcons 204L, TableIcons 143L, UIIcons 282L) + 3L barrel re-export. Zero import site changes. |
| `a3ae729f` | 5.B | Flatten TableFilter.tsx JSX: extract filterRows + actionBar as named variables. JSX 127L -> 51L. |
| `001bbbfb` | 5.C | Flatten InsightsFilters.tsx JSX: extract 7 field variables + glossaryAndControls. JSX 124L -> 27L. |
| `5c46869e` | 5.D | Flatten Sidebar.tsx JSX: deduplicate closeButton, extract sidebarHeader + navLinks + expandCollapseButton. JSX 127L -> 33L. |
| `2934d8a8` | 5.E | Extract Table.tsx type definitions (BaseTableProps, ClickableRowProps, SelectionRowProps, ColumnsVisibilityProps, ExpandingProps, HeightProps, TableProps) to Table.types.ts. 358L -> 274L + 96L types file. Phase 5 100% complete. |
| `90371a00` | 6.1 | Cast SVG imports to StaticImageData (5 files, 8 warnings resolved). SVG .d.ts approach failed due to Next.js any override. |
| `ca0e8f97` | 6.1 | Eliminate 3 unjustified any types (PieChart, getTableColorsSet, getFetchMock) + clean newrelic-mock (7 any, file-level eslint-disable removed). |
| `205681fe` | 6.4 | Annotate 32 catch clauses with explicit `: unknown` across 17 files. |
| `d1946cbf` | 6.x | Fix remaining ESLint warnings (zodResolver, 4 test mock casts, stale directive) + remove file-level eslint-disable from useKeepRowsSelection.tsx. 0 errors, 0 warnings. |
| `8ddb6762` | 6.x | Document 4 container boundary exception groups in CLAUDE.md (SettingsNavigation, UsersTable/UserRoleSelect/UserPanel, AddTeamForm/AddUserForm/EditURLsForm, EditUserModal). |
| `8bc878c3` | 6.5 | Add Zod validation to feature flag trust boundaries: FeatureFlagsShapeSchema (types.ts), CachedFeatureFlagsDataSchema (featureFlagsCache.ts), z.string() input/output validation (fetchFeatureFlags.ts). z.coerce.number() for date-range string/number mismatch. Fix null-payload test assertions. |
| `e11e0e5b` | 6.5 | Add Zod validation to logout.tsx (z.boolean().catch(false)) and useChatApi.ts (GetChatResponseSchema + safeParse). 4/4 JSON.parse gaps closed. Convergence 12/14 -> 13/14. |
| `0568b4a5` | chore | Add dist/ + root config files (playwright.config.ts, vitest.config.mts, env.d.ts) to ESLint ignores. Gitignore .claude/launch.json and .claude/start-dev.sh. `npx eslint . --max-warnings 0` now fully clean. |
| `cae00161` | 6.3 | Eliminate 9 useEffects across 8 files. Render-time state adjustment pattern (Table, SystemLatency, ClassificationUrls), useMemo derivation (WorkstreamGanttChart, ProductivityByDate), early-return redirect (ChatContainer). 11 reclassified as KEEP. Convergence 13/14 -> 14/14. |
| `36a8c7bc` | 6.3 | Eliminate 6 more useEffects (round 2): AuthStateProvider callback wrapper, LayoutProvider/InsightsContext/WorkstreamsAnalyzerContainer/ProductivityByDateContainer useMemo, DashboardLayout ref tracking. Total: 15 eliminated, 30 remain. |
| `6c2a82cf` | 6.3b | Consolidate 6 click-outside/ESC inline useEffect pairs into useClickAway + useEscapeKey shared hooks. Add `enabled` param to useClickAway. Export useEscapeKey from barrel (was dead code). Eliminate deprecated keyCode. useEffect count 30 -> 24. |
| `9a92bed2` | 8.0a | Delete 10 dead files + 2 dead directories (navigation/, providers/context/utils/). Remove barrel re-exports. -291L. |
| `51e69884` | 8.0a | Delete 24 dead type exports: explorer.ts (10), insights.ts (4), filterFormStates.ts/schema.ts (4), company.ts (6), events.ts (2), relay (1). -326L. |
| `60cc2fac` | 8.0a | Delete 4 FilterControllers types (zero consumers) + RealtimeDashboardFormState (unformatted, zero consumers). -39L. |
| `d72d1369` | 8.0a | Delete 5 dead test-utils, 5 dead utils (+ 6 specs), 2 duplicate compare dirs, 1 dead fetchApi export. -705L. Tests 2352->2288, specs 187->181. |
| `5ce52796` | 8.0a | Remove 34 dead mock handler routes. Mock handler 688->153L (-535L). All api/company-data/* + 14 bare entity routes. |
| `00edc7f8` | 8.0a | Fixture fixes: Identity.email string (26 casts removed), nextGroupId->faker, Seconds() constructor, remove 'use client' from theme.tsx. |
| `2d090e6d` | 8.0a | Fix missed 'as string' cast in microworkflows.fixture.ts (ESLint no-unnecessary-type-assertion). |
| `d94252ac` | 8.0-pre | Fix 5 audit2 bugs: UserRoleSelect/TeamUsersActions ghost-state (try/finally), AddTeamForm error handling (onError handler + toast), useAddTeamOwnersMutation/useAddUsersToTeamMutation cache invalidation. Tests 2286->2287. |
| `f8a213d6` | 8.0b | Fix mock handler schema mismatches: getTimingInfo returns 3 valid WorkstreamsTimingInfo, getUserLoadTimeByHost returns valid {workstreamEvents, workstreamSpans}. |
| `f815551c` | 8.0b | Remove artificial delay from mock handler. Handler now synchronous (async keyword removed). |
| `2c9b2141` | 8.0b | Add 18 missing query mock routes: relay-usage (3), favorite-usage (3), system-latency (3), microworkflows (3), analyzer (2), systems overview + 4 dynamic page routes. |
| `1ca8fb4b` | 8.0b | Add 15 missing mutation mock routes: role changes, user/team CRUD, BPO/project CRUD. Mock handler 153->411L, 38 routes total. |
| `867384d5`, `35dfad4c`, `db17370f`, `a9b8c682`, `fbda702f`, `498f1f2c` | 8.0c | Cross-domain coupling fixes. 25 -> 9 remaining. C1-C7 (Header, insightsContext types/imports, MetadataPopupContent, handleClickGlossary, getCommonGroupIds, queryParams constants). N1 (CSS typo), N2 (createTeam cache invalidation), N3 (removeRelatedInsights), N8 (CSV_FILENAME_PREFIX), N9 (e2e constants). 181 specs, 2289 tests. |
| `61ef917b` | 8.0d | Move NEW_INSIGHTS_FILTERS_KEY, GLOBAL_TIMEZONE_STORAGE_KEY, unassignedUserItem to shared/constants. Eliminates 2 of 3 provider->page_blocks coupling sites. |
| `7bcfc1b9`, `ba33d681` | 8.0d | Migrate auth provider localStorage to typedStorage (firebase.ts, login.ts, AuthStateProvider.tsx, useAuthBusinessLogic.ts, useSessionModal.ts). Zod schemas: z.string().email(), z.boolean(). |
| `dc8ee348` | 8.0d | Migrate webExtension provider localStorage to typedStorage. 8 raw calls replaced. z.string() schema for login attempt timestamps. |
| `2d77e090` | 8.0d | Migrate 4 filter container writes + posthog.ts read to typedStorage. writeStorage replaces localStorage.setItem + JSON.stringify. |
| `873a6818`, `35a65b0d` | 8.0d | Trust boundary fixes: D3 (router.query.id validation), D4 (useChatApi Zod validation on all paths), D5 (Role[] runtime validation with isRole guard). |
| `62472e2c` | 8.0d | Fix empty catch block ESLint error from comment cleanup. |
| `7c5c861e` | 8.0e | Fix LogOutOptions drift: add macAppRedirect to canonical definition. |
| `222f8771` | 8.0e | Delete legacy auth/types.ts, redirect 17 consumer imports to @/shared/types/auth. Fix 2 branded-type gaps (logout.tsx UserId, useLoginActions.tsx OrganizationId). |
| `466a85f0` | 8.0e | Create RoleSchema (z.enum), replace 2 pass-through casts in users.schema.ts + 1 fake role schema in auth.schema.ts + 1 z.nativeEnum in EditUserModal/validation.ts. |
| `2286c494` | 8.0e | Replace 3 fake z.unknown() schemas with real UserInfoSchema/TenantWithProvidersSchema. Fix AuthProvider[] double cast with explicit .transform(). |
| `7090acd3` | 8.0f | Re-export shim elimination. 234 files changed, net -209 lines. Migrated ~200 consumer files from provider type re-exports to canonical @/shared/types/*. Removed all re-export blocks from 5 provider type files. Deleted bpoProjectsContext/types.ts + empty dir. Fixed UrlsClassificationProvider import, queryParams.spec.ts import, 9 duplicate import ESLint errors. 181 specs, 2289 tests, 0 type re-exports remaining. |
| `368407aa` | 8.0g-post | N32 flag type fix, N35 toggleIsHours, N36/N38/N39 render-time to useEffect conversions, N37 stability comments. |
| `b57945c3` | 8.0g-post | N32 coerce fix for feature flag string/number mismatch. |
| `5f244922` | 8.0g-def | Add shared ModalState<T> and TableSelection<T> UI types in src/shared/types/ui.ts. |
| `169cbaec` | 8.0g-def | Refactor BPOBlock props: 22 flat -> 10 grouped (3x ModalState + 1x TableSelection). Dead searchValue prop removed. |
| `10fa6af4` | 8.0g-def | Refactor ProjectBlock props: same pattern as BPO (22 -> 10). Dead searchValue prop removed. |
| `84a28871` | 8.0g-def | Refactor ClassificationUrlsBlock props: 18 -> 16 (1x TableSelection). |
| `e3bb32f1` | 8.0g-def | Refactor Users props: 17 -> 14 (1x TableSelection with clear). |
| `b0ab12d7` | 8.0g-def | Refactor TeamsBlock props: 15 -> 9 (1x ModalState + 1x TableSelection). |
| `57620ca4` | 8.0g-def | Extract UserPanelDetails from 90-line nested render function in UserPanel.tsx. |
| `70c9d658` | 8.0g-def | Flatten chained ternaries in 5 files to named variables. SystemAnalysis redundant guard removed. |
| `f58b2e1a` | 8.0g-def | Add justification comments for 2 csvMapper as-casts (CSVValueMapper receives unknown by design). |
| `3831c81c` | 8.0h | Fix 3 P0 bugs: N1 getTtmForDays mock returns Record (was array), N2 `as never` replaced with isRole guard, N3 `e as Error` replaced with instanceof pattern. |
| `8d77d45b` | 8.0h | Mock handler schema mismatches: N6 users/groups POST returns single Group, N7 classification URLs PUT returns ModifyClassificationUrlResponse. |
| `9fb8a933` | 8.0h | N13 monitorApiCall double-call fixed (apiCall() before NR setup), N19 id_token stripped from NR attributes. |
| `09d7724d` | 8.0h | Dead code: N8 4 dead MetadataPopupContent copies deleted (specs moved to canonical), N9 874L mocks.ts deleted, N15 dead dayjs imports removed. |
| `49bd1583` | 8.0h | N25 createColumnHelper moved to module scope in 5 team/ files (fixes memoization defeat). |
| `7bfbb3cc` | 8.1+8.2 | Next.js 14.2.32 -> 15.5.12. Config: eslint.dirs -> ignoreDuringBuilds. Patches 3 DoS CVEs. |
| `3f63ca64` | 8.1+8.2 | React 18.3.1 -> 19.2.4 + @types. MutableRefObject -> RefObject, nullable ref widening, 6 spec assertion fixes. |
| `6b2654cb` | 8.1+8.2 | next-themes 0.3.0 -> 0.4.6 (React 19 peer dep). Drop-in. |
| `190a9edd` | 8.1+8.2+8.3 | react-flatpickr 3.10.13 -> 4.0.11. @types/react-flatpickr removed. Ref type update. 2 global JSX namespace fixes. |
| `e97b40f4` | 8.1+8.2 | Migrated all 6 forwardRef sites to ref-as-prop. Zero forwardRef/MutableRefObject remaining. FilterSelect ESLint fix (onChange rest spread). |
| `cbd91647`, `e01b512b` | 8.1+8.2 | Update CLAUDE.md and README.md stack versions (Next.js 15, React 19). |
| `4932ee69` | 8.4 | Upgrade posthog-js 1.304.0 -> 1.357.1. Patches last production CVE (preact VNode injection). |
| `cbf90835` | 8.4 | Upgrade jsdom 24.1.3 -> 28.1.0 (dev dep, vitest DOM environment). |
| `19700f38` | 8.4 | Upgrade concurrently 8.2.2 -> 9.2.1, dotenv 16.5.0 -> 17.3.1 (dev deps, E2E scripts). |
| `f0c15adc` | 8.6 | Remove 8 dead production deps: @heroicons/react, @vercel/analytics, chartjs-adapter-moment, nuqs, react-markdown, reactflow, remark-gfm, sharp. |
| `3e889a01` | 8.6 | Remove 5 dead dev deps: @storybook/addon-controls, @vitest/browser, @8flowinc/eslint-plugin, @tanstack/eslint-plugin-query, lint-staged. |
| `d2600d26` | 8.6 | Move 4 misplaced deps to devDependencies: playwright-extra, puppeteer-extra-plugin-stealth, @types/node, typescript. Also upgrades @types/node 20->25, typescript 5.8->5.9. |

**Detail plan**: `~/.claude/plans/cuddly-wobbling-boot.md` (covers schema derivation sessions + Phase 4 provider type consolidation).
**Phase 4 detail plan**: `~/plans/uf-phase-4-container-boundaries.md` (all 10 items broken into ~30 specific commits with files/deps/ordering).

**Schema derivation summary**: All schema-backed types now derive via `z.infer` from Zod schemas in `src/shared/types/*.schema.ts`. Zero hand-written duplicate interfaces remain for API response types. 16 schema files, ~120 derived types, 21 branded field fixes (`uid` -> `UserId`, `teamId` -> `TeamId`, `organizationId` -> `OrganizationId`). 3 files added during derivation (automationSuggestion.ts, workstreamQueryParams.ts, filterFormStates.schema.ts + filterFormStates.ts), bringing total from 44 to 47. Provider type systems now resolved -- all three provider `types.ts` files are re-export shims pointing at shared branded types.

**Provider type consolidation (cuddly-wobbling-boot Phase 4)**: ALL DONE.
- **4a** (insightsContext) `10069d34`: Moved query param types, mapped types to `@/shared/types/`. insightsContext/types.ts reduced from ~990L to ~299L, now 90% re-exports.
- **4b** (usersContext) `39a5b5ce` + `c3e82280`: Deleted 6 dead mutation param types, re-exported 7 shared types (including branded `MappedUpdateUserParams` with `UserId`/`OrganizationId`/`TeamId`). Co-located `mapUsers` with sole consumer `useUsersListQuery`. Deleted `constants.ts` and `utils/` directory. `types.ts` now 17L (re-exports + `UsersContextProps`).
- **4c** (urlClassification) `71dd350d` + `850d7d42`: Moved `UNCLASSIFIED_CATEGORY` and `MappedClassificationUrlItem` to shared. Deleted dead `ClassificationUrlsGetQueryParams`/`MappedClassificationUrlsGetQueryParams` (zero consumers). Co-located `mapClassificationUrlItems` with sole consumer `useClassificationUrlsQuery`. Deleted `constants.ts` and `utils/` directory. `types.ts` now 18L (re-exports + `UrlClassificationContextProps`).

**R1-R3 restructuring**: Done after Phase 2 extraction but before schema derivation. Restructured all service hooks from flat files to per-directory format (each hook in its own directory). Rewired all consumers to import from service layer instead of through provider pass-throughs. Stripped 44 hook pass-throughs from 4 provider contexts. This work bridges Phase 2 and Phase 3 -- it completed the "no provider re-exports service hooks" goal.

## Target Architecture

When complete, user-frontend will match next-gen-atlassian structurally:

- **DDAU component model**: containers own hooks/state/effects; leaves receive
  props only. Documented escape hatches for layout shells and ambient UI hooks.
- **Centralized types**: 47 files in `src/shared/types/` with Zod schemas,
  branded IDs (UserId, WorkstreamId, TeamId, OrganizationId), zero enums.
- **Unified data layer**: single `fetchApi` with required Zod schema as the
  sole point of contact to UB (user-backend). Mock handler serves fixture data
  in local mode. `useFetchApi` for all service hooks. `typedStorage` for all
  storage access. No `companyData.ts`, no `createQueryFactory`/`createMutationFactory`.
  When UB is eventually ported into UF, its handlers become `pages/api/` routes
  and `fetchApi` just changes its base URL -- trivial cutover.
- **Service hook layer**: 105 hooks across 200 files in `src/ui/services/hooks/`
  organized by domain (queries/, mutations/, keys/) in per-directory format
  (each hook in its own directory with barrel export + co-located mappers/adapters).
  No data fetching in components or providers.
- **Fixture system**: 19 files -- faker-backed builders, identity pool, 15 domain
  fixtures, scenario composers. Mock API handler serves fixture data in local mode.
- **API layer**: mock handler (`pages/api/mock/[...endpoint].ts`) for local dev
  only. Production traffic goes to UB via `fetchApi`. Real `pages/api/` routes
  come later when UB is ported into UF (out of scope for this refactor).
- **Contract-first tests**: 10 testing principles, fixture builders for test
  data, boundary mocking only, no internal mocking. 60%+ coverage.
- **Clean templates**: JSX returns under 100 lines, no inline transforms, no
  chained ternaries, extracted sub-components via props. No file over 500 lines.
- **Zero tsc errors, zero ESLint errors** (warnings allowed only for
  `no-unsafe-*` backlog during migration; aim for `--max-warnings 0`).
- **.claude/skills/**: 32 skills + README enforcing all conventions via agents.
- **Dependency parity**: React 19, Next.js 15, sonner (not react-hot-toast),
  ECharts (not chart.js/recharts), papaparse (not react-csv). Storybook stays
  (UF has 13 substantive stories + Chromatic CI integration).

## What We Learned (Lessons from next-gen-atlassian)

1. The fixture system and mock handler must be built early -- they unblock
   local development, E2E tests, and bug bashing simultaneously.
2. Type centralization before container extraction prevents massive rework.
   Get the types right first.
3. Convergence audits are essential. Run the codebase audit after each major
   phase and fix findings before moving on. Do not accumulate debt.
4. God component decomposition is the hardest work. Budget extra time for
   SystemsBlock, ProductivityPage, and ProcessMiningView equivalents.
5. The `any` sweep is tedious but mechanical. Parallelize with agents.
6. All data fetching must go through a single point of contact (`fetchApi`).
   In NGA this meant API route handlers with `NEXT_PUBLIC_LOCAL` early returns.
   In UF it's simpler: `fetchApi` talks to UB in production and the mock
   handler in local mode. No API proxy layer needed until UB is ported in.
7. Browser bug bashing against the production deployment catches layout,
   padding, missing column, and data flow bugs that tsc and lint miss entirely.
8. Module-level caches (e.g. `productivityDataCache`) survive HMR. Full dev
   server restart needed to clear stale entries during development.

## Structural Inventory (NGA has, UF lacks)

This is the complete delta. Every item here must be addressed by the end
of the refactor. Items are grouped by phase.

### Tooling + Project Config (Phase 1.0) -- ALL DONE

| Item | Action | Status |
|------|--------|--------|
| `CLAUDE.md` | Port from NGA (adapt paths) | **DONE** |
| `.claude/skills/` | Port 31 skills + README, delete commands/ | **DONE** |
| `.claude/launch.json` | Port | **DONE** (created during 8.7 pre-work: Firebase emulator setup) |
| `tsconfig.eslint.json` | Port | **DONE** |
| ESLint `no-unsafe-*` rules | Align to `warn` | **DONE** |
| ESLint ignores | Add `.next/`, `next-env.d.ts`, `postcss.config.js` | **DONE** |
| ESLint test file pattern | Fix `**/*.spec.tsx` | **DONE** |
| Pre-commit hook | Align to NGA | **DONE** |
| `@/fixtures` path alias | Add to tsconfig | **DONE** |
| `docs/` | Port UF-relevant files | **DONE** (2 files) |
| `AGENTS.md` | Port (symlink to CLAUDE.md) | **DONE** |
| Root dead files | Delete 9 files | **DONE** |
| `.npmrc` | Registry URL only, no auth token | **OK** (no token present) |
| `.ai/` directory | Assess | **DONE** (deleted -- Cursor/Windsurf no longer used) |
| `vite-imports.d.ts` | Port | **SKIP** (does not exist in NGA; UF uses Next.js image imports natively) |

### Source Directory Cleanup (Phase 1.0) -- REMAINING

| Item | Current state | Action | Status |
|------|---------------|--------|--------|
| `src/types.ts` | Deleted, 4 consumers rewired to `@/shared/types` | N/A | **DONE** (punch list) |
| `src/types/` | Gone | N/A | **DONE** (already absent) |
| `src/tests/` | Still exists (insights-dashboard/, testE2EUtils.spec.ts) | Delete orphaned directory (zero consumers, @/tests maps to src/ui/tests/) | **SCOPED** (Audit 4 Prompt B Fix 15) |
| `src/ui/constants.ts` | Moved into `src/ui/constants/index.ts` (import path `../types` fixed) | N/A | **DONE** (punch list) |
| `src/components/` | Gone | N/A | **DONE** (already absent) |
| `src/data/`, `src/hooks/` | Gone | N/A | **DONE** (already absent) |

### Work from NGA Commit History Not Covered Elsewhere

281 commits on NGA's `sd/productionize`. The commit log reveals work that
does not map to a single structural item but must happen during the refactor:

| Work item | Phase | Status |
|-----------|-------|--------|
| Delete ~8,500 lines of dead code (components, providers, hooks, modals) | 1.0 | **DONE** (8.0a deleted ~1900L, 8.0g deleted ~1275L, remaining dead exports in Audit 4 Prompt B Fix 14) |
| ~~Delete dead CompanySwitchModal~~ | 1.0 | **SKIP** (NGA-only; does not exist in UF) |
| ~~Remove standalone executive dashboard prototype~~ | 1.0 | **SKIP** (NGA-only) |
| ~~Remove hardcoded GitHub Packages token from `.npmrc`~~ | 1.0 | **OK** (UF .npmrc has registry URL only, no auth token) |
| Consolidate `src/constants/` into `src/ui/constants/` | 1.0 | **DONE** (punch list: moved `src/ui/constants.ts` into `src/ui/constants/index.ts`) |
| ~~Delete dead `src/components/` directory~~ | 1.0 | **DONE** (already absent in UF) |
| ~~Delete dead `shared/mockData/` directory~~ | 1.0 | **DONE** (already absent in UF) |
| Move `src/types.ts` to `src/shared/types/common.ts` | 1.1 | **DONE** (punch list: deleted bridge file, rewired 4 consumers to `@/shared/types`) |
| ~~Move `src/utils/companyDataStorage.ts` to `src/server/`~~ | -- | **SKIP** (NGA-only file) |
| Consolidate `shared/mocks/` into `shared/test-utils/` | 1.1 | **DONE** (`38bac270`) |
| Replace manual fetch useEffect with TanStack Query (relay-usage) | 2 | **DONE** (all queries extracted to service hooks) |
| nuqs URL-first migration for InsightsContext consumers | 2 | **DONE** (Phase 8 nuqs migration + selection state migration prompts 1-9) |
| Eliminate all raw localStorage/sessionStorage access (typedStorage) | 2 | **DONE** (8.0d migrated 25 calls. featureFlagsCache exempt: encrypted AES-GCM with own validation) |
| selectedUser to URL, slim InsightsContext filter state | 3-4 | **DONE** (selection state migration prompts 1-9. InsightsContext deleted. All selection in nuqs URL params) |
| Strip InsightsContextProvider to state-only (localStorage removed, adapters co-located, dead code deleted) | 3 | **DONE** `eaa985dd`..`bda82496` |
| Convert 15 useEffects to derived state in ProductivityPage | 5 | **DONE** (Phase 6 Session 4. 1 justified useEffect remains in ProductivityByDateContainer: auto-select on data arrival) |
| Replace `\|\|` with `??` across ~38 files (3 batches) | 6 | **DONE** (prefer-nullish-coalescing is `error` in eslint config, ESLint clean at --max-warnings 0) |
| Fix 88 `prefer-nullish-coalescing` violations | 6 | **DONE** (same as above) |
| Delete all unused variables and imports (43 errors) | 6 | **DONE** (eslint-plugin-unused-imports active, ESLint clean) |
| Fix non-any ESLint errors across 51 files | 6 | **DONE** (ESLint clean at --max-warnings 0) |
| ~~Hoist effect bridges from SystemsBlockWrapper/ExplorerBlockWrapper~~ | 4 | **SKIP** (NGA-only files; do not exist in UF) |
| Replace manual click-outside effects with useClickAway | 4 | **DONE** (Phase 6 Session 4b: 6 inline useEffect pairs consolidated into useClickAway + useEscapeKey) |
| ~~Close 5 visual parity gaps with production (systems cards)~~ | 8 | **SKIP** (NGA-only concept; UF is production) |
| ~~Add vite-imports.d.ts~~ | 1.0 | **SKIP** (not needed in UF) |
| ~~Decompose executiveSummaryDataProcessor (467L -> 13 sub-functions + 37 tests)~~ | 5 | **SKIP** (NGA server module; does not exist in UF) |
| ~~Decompose processMining.ts (654L -> 3 modules + 25 tests)~~ | 5 | **SKIP** (NGA server module; does not exist in UF) |
| ~~Decompose analyzerDataset (858L -> 5 modules + 46 tests)~~ | 5 | **SKIP** (NGA server module; does not exist in UF) |
| DST timezone computation fix (defer to call time, not module load) | 6 | **SCOPED** (Audit 4 Prompt B Fix 4) |
| Bug bash: expect 20+ fixes across 2+ rounds | 8 | **PENDING** (bug bash prompt ready at ~/plans/prompts/backlog-06-bug-bash.md) |

### next.config.js Alignment (Phase 8)

**Decision**: keep `output: 'export'` for now. Mock handler is dev-only.
Real API routes come when UB is ported in, at which point `output: 'export'`
is removed and UF switches to standard Next.js server mode (Vercel).

Full `next.config.js` alignment is a Phase 8 concern (done on the clean arch):

| Setting | UF | NGA | Action |
|---------|-----|-----|--------|
| `output` | `'export'` (static HTML) | Absent (server mode) | Keep for now. Remove when UB is ported in. |
| `distDir` | `'dist'` | Absent (default `.next/`) | Remove when switching to server mode |
| `eslint.dirs` | `[]` | N/A | Next 15 changes behavior: empty array no longer skips linting |
| `eslint.ignoreDuringBuilds` | Absent | `true` | Add in Phase 8 (replaces `eslint.dirs: []`) |
| `typescript.ignoreBuildErrors` | Absent (false) | `true` | Add in Phase 8 for Vercel deployment |
| webpack source map config | Custom TerserPlugin config | Absent | Assess in Phase 8 -- may not be needed |

### Vitest Config Alignment (Phase 1.0) -- ALL DONE

| Setting | Action | Status |
|---------|--------|--------|
| `pool` | Add `'forks'` (prevents test hangs) | **DONE** (`d9387697`) |
| `teardownTimeout` | Add `5000` | **DONE** |
| `poolOptions.forks` | Add `minForks: 1, maxForks: 2` (prevents OOM) | **DONE** |
| `setupFiles` | Update paths to `shared/test-utils/` | **DONE** |
| Missing aliases | Add `@/constants/testIds`, `@/services`, `@/hooks`, `@/utils`, `@/fixtures` | **DONE** (`4efc223e`) |
| `coverage.reporter` | Add `'text'` | **DONE** |

### Types + Shared Infrastructure (Phase 1.1) -- ALL DONE

| Item | Status |
|------|--------|
| `src/shared/types/` (47 files: 44 ported + 3 added during schema derivation. Types + Zod schemas + branded IDs) | **DONE** (`81e49fa6` + schema derivation) |
| `src/shared/utils/typedStorage.ts` (+ spec) | **DONE** (`2ca0f6b9`) |
| `src/shared/utils/queryParams.ts` (+ spec) | **DONE** |
| `src/shared/utils/map.ts` (+ spec) | **DONE** |
| `src/shared/utils/metadata.ts` (+ spec) | **DONE** |
| `src/shared/utils/time/formatSecondsHMS.ts` (+ spec) | **DONE** |
| `src/shared/utils/date/getStartEndTimes/` | **DONE** |
| ~~`src/shared/lib/supabase.ts`~~ | **SKIP** (NGA-only) |
| `src/shared/navigation/` (4 files) | **DONE** (`839ab3c8`) |
| `src/shared/cleanup-registry.ts` | **DONE** |
| `src/shared/test-utils/` (13 files, replaces `shared/mocks/`) | **DONE** (`38bac270`) |
| `src/shared/hooks/` (useContainerSize, useCountdown, useEscapeKey, useFilterCollapse, useHydrated) | **DONE** (`b27dee58`) |
| `src/shared/ui/` (ActivityTypeBadge, FilterSection, FloatingGlossaryHelp, MetadataDetailsContent, Spinner) | **DONE** (`3d30d216`) |
| ~~`src/ui/utils/companyData/`~~ (NGA-only disk-based company data processing) | **SKIP** (N/A for UF) |
| `src/ui/constants/testIds.ts` | **DONE** (`02748d6b`) |
| ~~`src/ui/providers/context/companyContext/`~~ (UF has no multi-company switching) | **SKIP** (`ab8f0e29`) |
| ~~`src/ui/providers/context/app.tsx`~~ | **SKIP** (assessed, not needed) |

### Fixture System + Mock Handler + fetchApi (Phase 1.2) -- ALL DONE

| Item | Status |
|------|--------|
| `src/fixtures/` (15 domain fixtures + brand, identity-pool, scenario, index) | **DONE** (`e47b454a`) |
| `src/pages/api/mock/[...endpoint].ts` (local dev only) | **DONE** (`5aaea51a`) |
| ~~`src/pages/api/` (35 real handlers)~~ | **SKIP** (UF talks to UB directly) |
| `fetchApi` (base URL = UB in prod, mock handler local; `schema` required) | **DONE** (`db960cd0` `e6809185`) |
| ~~`src/server/`~~ (NGA-only disk-based data processing) | **SKIP** (mock handler serves from `buildStandardScenario()`) |
| ~~`data/companies/`~~ | **SKIP** (UF has no disk-based company data) |

### Dependencies (Phase 1.3 install, Phase 8 upgrade)

**Add to UF:** ALL INSTALLED (`730c0de9`).

| Package | Purpose | Status |
|---------|---------|--------|
| `@faker-js/faker` | Fixture system | **INSTALLED** |
| `nuqs` | URL search params | **INSTALLED** (not yet wired) |
| `sonner` | Toast notifications | **INSTALLED + WIRED** (replaces react-hot-toast) |
| `reactflow` | Flow diagrams | **INSTALLED** |
| `react-markdown` + `remark-gfm` | Markdown rendering | **INSTALLED** |
| `@heroicons/react` | Icons | **INSTALLED** |
| `papaparse` + types | CSV parsing/export | **INSTALLED** |
| `@vercel/analytics` | Analytics | **INSTALLED** |

**NGA-only (do NOT add to UF):** `@supabase/supabase-js`,
`@anthropic-ai/sdk`, `@modelcontextprotocol/sdk`, `@react-pdf/renderer`,
`pg` + types, `formidable` + types, `tsx`.

**Remove from UF:**

| Package | Replaced by | Status |
|---------|-------------|--------|
| `react-hot-toast` | `sonner` | **DONE** (removed `6bbeed4b`) |
| `chart.js` + `chartjs-adapter-moment` | ECharts (already in UF) | **DONE** (removed `7f1aa328`) |
| `recharts` | ECharts (already in UF) | **DONE** (removed `7f1aa328`) |
| `react-csv` + types | `papaparse` | **DONE** (removed `eb5a571d`) |
| `@8flowinc/eslint-plugin` | Assess -- keep if useful | TODO (Phase 6) |
| `lint-staged` | Not used (husky direct) | TODO (Phase 6) |

**Upgrade later (Phase 8):**

| Package | UF version | NGA version | Notes |
|---------|-----------|-------------|-------|
| `next` | 14.2.32 | 15.5.12 | `eslint.dirs: []` -> `eslint.ignoreDuringBuilds: true` in next.config.js |
| `react` / `react-dom` | 18.3.1 | 19.2.4 | `MutableRefObject` -> `RefObject`, peer dep cascades |
| `@types/react` | 18.3.18 | 19.2.14 | |
| `react-flatpickr` | 3.10.13 | 4.0.11 | **Breaking**: class -> FC, ref type changes. Drop `@types/react-flatpickr` (v4 ships own types) |
| `next-themes` | 0.3.0 | 0.4.6 | React 19 peer dep resolution. Drop-in upgrade. |
| `sharp` | 0.33.5 | 0.34.5 | |
| `jsdom` | 24.1.3 | 28.1.0 | Dev dependency |
| `concurrently` | 8.2.2 | 9.x | Dev dependency |
| `dotenv` | 16.4.7 | 17.3.1 | |

### UF-Only Code to Remove or Restructure

| Item | Action | Status |
|------|--------|--------|
| `.storybook/` directory | Keep (13 stories + Chromatic CI active) | **KEEP** |
| All `*.stories.tsx` files | Keep; update as components change | **KEEP** |
| `.ai/` directory | Delete (Cursor/Windsurf no longer used) | **DONE** (`bb46e5ba`) |
| `src/shared/mocks/` (7 files) | Replace with `src/shared/test-utils/` | **DONE** (`38bac270`) |
| `src/ui/providers/context/utils/api/` | Delete (createQueryFactory/createMutationFactory) | **DONE** (`064bf216`) |
| `src/ui/providers/context/usersContext/` | Strip to state-only (data fetching moved to service hooks) | **DONE** (`1a5d0a94`) -- dir still exists with UI state provider |
| `src/ui/providers/context/urlClassification/` | Strip to state-only | **DONE** (`041aae8e`) -- dir still exists with UI state provider |
| `src/ui/providers/context/layout/` (6 files) | Assessed -- already Phase 3 compliant (UI state only). Merge into DashboardLayout deferred to Phase 4. | **COMPLIANT** `2fc7b6d1` |
| `src/ui/providers/context/flyoutContext.tsx` | Assessed -- already Phase 3 compliant (single boolean state). Removed spurious `'use client'` directive. | **COMPLIANT** `2fc7b6d1` |
| `src/ui/providers/context/globalUi.tsx` | Deleted -- completely dead code (useAppProvider zero consumers, sidebarOpen duplicates LayoutProvider) | **DONE** `2fc7b6d1` |
| `src/ui/providers/context/insightsContext/usePagesStateReducer/` (7 files) | Keep in place (pure state management with useReducer). Refactor into containers in Phase 4. | **KEPT** (Phase 3.2 assessed) |
| `src/ui/providers/context/insightsContext/utils/adapters/` | Co-located with sole service hook consumers | **DONE** `a0cd6f18` |
| `src/ui/page_blocks/classificationUrls/` | Merge into settings/ | TODO (Phase 4.10) |
| `src/ui/page_blocks/dashboard/opportunity/` | Merge into opportunities/ or opportunitiesV2/ | TODO (Phase 4.10) |
| `src/ui/page_blocks/dashboard/ui/` | Assess -- shared components or delete | TODO (Phase 4.10) |
| `src/ui/page_blocks/dashboard/workstreams-analyzer/` | Merge into workstream-analysis/ | TODO (Phase 4.10) |

### Page Blocks to Create (exist in NGA, missing in UF)

| Domain | Purpose |
|--------|---------|
| `dashboard/analysis/` | Analysis layout + sub-page containers |
| `dashboard/explorer/` | Explorer/workstream analysis UI |
| `dashboard/insights/` | Insights shared components |
| `dashboard/InsightsFilters/` | Filter bar components + containers |
| `dashboard/opportunities/` | Opportunities V1 |
| `dashboard/opportunitiesV2/` | Opportunities V2 (current) |
| `dashboard/productivity/` | Productivity page (containers + hooks + components) |

---

## Phases (Option A: Architecture First)

### Phase 1: Foundation

**Goal**: All infrastructure ported. `pnpm tsc --noEmit` clean.
`NEXT_PUBLIC_LOCAL=true pnpm dev` serves pages without 404s.

| # | Work item | Status |
|---|-----------|--------|
| 1.0a | Port `CLAUDE.md`, adapt for UF paths | **DONE** `c322f025` |
| 1.0b | Port `.claude/skills/` (31 skills + README), delete `commands/` | **DONE** `a16734ad` |
| 1.0c | Disable Chromatic CI on `sd/productionize` (stories break during Phases 2-7). Re-enable in Phase 8. | **DONE** `d73497c1` |
| 1.0d | Port `tsconfig.eslint.json`, align ESLint config, fix pre-commit | **DONE** `ba44b943` |
| 1.0e | Add `@/fixtures` path alias + new vitest aliases | **DONE** `4efc223e` |
| 1.0f | Align vitest config: pool forks, worker limits, teardownTimeout, coverage | **DONE** `d9387697` |
| 1.0g | Port `AGENTS.md` (symlink to CLAUDE.md), add LLM instruction symlinks. `vite-imports.d.ts` was in original plan but does not exist in NGA and is not needed (UF uses Next.js image imports natively). | **DONE** `725e4ef2` `9406665e` `8f6c75c2` |
| 1.0h | Delete 9 dead root files + `.ai/` directory | **DONE** `2cd9a348` `bb46e5ba` |
| 1.1a | Port `src/shared/types/` (44 files, grew to 47 during schema derivation: +automationSuggestion.ts, +workstreamQueryParams.ts, +filterFormStates.schema.ts/filterFormStates.ts) with type reconciliation. Schema type derivation complete (~120 API response types derive from Zod via `z.infer`, zero hand-written duplicates, 21 branded field fixes). Unbranded types in `insightsContext/types.ts` and `usersContext/types.ts` remain (Phase 3). | **DONE** `81e49fa6` + derivation commits `389d869e`..`b433b09e` |
| 1.1b | Port shared utils (typedStorage, queryParams, map, metadata, time, date) | **DONE** `2ca0f6b9` |
| 1.1c | Port shared navigation (4 files), cleanup-registry (skip supabase.ts) | **DONE** `839ab3c8` |
| 1.1d | Port shared hooks (5 new hooks) | **DONE** `b27dee58` |
| 1.1e | Port shared UI components (5 new components) | **DONE** `3d30d216` |
| 1.1f | ~~Assess + port `src/ui/utils/`~~ -- `src/ui/utils/companyData/` is NGA-only (disk-based company data processing). UF has no equivalent and neither mock handler nor UI imports these. | **SKIP** (N/A for UF) |
| 1.1g | Port `src/ui/constants/testIds.ts` | **DONE** `02748d6b` |
| 1.1h | Assess companyContext -- UF has no multi-company switching. Not needed. | **DONE** (assessed, skipped) `ab8f0e29` |
| 1.1i | Replace `src/shared/mocks/` with `src/shared/test-utils/` | **DONE** `38bac270` |
| 1.2a | Install new deps (@faker-js/faker, nuqs, reactflow, papaparse, sonner, etc.) | **DONE** `730c0de9` |
| 1.2b | Port `src/fixtures/` (15 domain fixtures + brand, identity-pool, scenario, index) | **DONE** `e47b454a` |
| 1.2c | Port mock handler (`pages/api/mock/[...endpoint].ts`) | **DONE** `5aaea51a` |
| 1.2d | Port + configure `fetchApi` (base URL = UB in prod, mock handler local; `schema` required at compile time) | **DONE** `db960cd0` `e6809185` |
| 1.2e | ~~Assess + port `src/server/`~~ -- NGA-only data processing modules for disk-based company data. UF mock handler serves from `buildStandardScenario()` via fixtures, no disk reads needed. | **SKIP** (N/A for UF) |
| 1.2f | ~~Port `data/companies/`~~ -- Skip (UF has no disk-based company data) | **SKIP** |
| 1.3 | Port docs (2 UF-relevant files: anonymization-reference, process-mining-tree-layout) | **DONE** `fc00bb02` |

**Exit criteria**: ALL MET. `pnpm tsc --noEmit` 0 errors. `pnpm build` clean.

### Phase 2: Service Hook Extraction

**Goal**: All data fetching lives in `src/ui/services/hooks/`. No component
or provider calls `useQuery`/`useMutation` directly.

| # | Work item | Status |
|---|-----------|--------|
| 2.1 | Inventory all useQuery/useMutation calls in components + providers | **DONE** (implicit in 2.3/2.4) |
| 2.2 | Create `src/ui/services/hooks/` directory structure (queries/, mutations/, keys/) | **DONE** `21994a5b` |
| 2.3 | Extract query hooks by domain (30 queries across 6 domains: insights 27, users 2, teams 1, bpo-projects 2, url-classification 1) | **DONE** `7e773012` `92e25abc` |
| 2.4 | Extract mutation hooks by domain (19 mutations across 4 domains: bpo-projects 8, teams 6, users 3, url-classification 2) | **DONE** `9a248cb8` |
| 2.5 | Create query key modules (5 files: insights, users, teams, bpo-projects, url-classification) | **DONE** (part of 2.2) |
| 2.6 | Wire all hooks through `useFetchApi` + Zod schemas | **DONE** (R2 `1ca24a59` replaced z.unknown() with real schemas) |
| 2.7 | Replace `react-hot-toast` with `sonner` | **DONE** `6bbeed4b` |
| 2.8 | Delete `createQueryFactory`/`createMutationFactory` and `context/utils/api/` | **DONE** `064bf216` (also `2c9dbc32`: replace isRequesting with isFetching) |
| 2.9 | ~~Delete `companyData.ts`~~ -- never existed in UF (NGA-only) | **SKIP** (N/A for UF) |
| 2.10 | Strip usersContext to state-only, rewire 9 consumers to service hooks | **DONE** `1a5d0a94` (provider directory still exists with UI state) |
| 2.11 | Strip urlClassification to state-only, rewire 3 consumers | **DONE** `041aae8e` (provider directory still exists with UI state) |
| R1 | Restructure all 5 domains' hooks to per-directory format (each hook in own dir) | **DONE** `36f81a74`..`7322ef3e` |
| R2 | Replace z.unknown() with real Zod schemas in insight query hooks | **DONE** `1ca24a59` |
| R3 | Rewire consumers to import from service layer directly, strip 44 hook pass-throughs from 4 provider contexts | **DONE** `516fa760` `63e1fb7e` |

**Exit criteria**: ALL MET. 105 hooks across 200 files in `src/ui/services/hooks/` (per-directory format with barrel exports + co-located mappers). Zero `useQuery()`/`useMutation()` calls in providers or page_blocks. Factories deleted. react-hot-toast removed.

**Note**: `useQueryClient()` for cache invalidation remains in 1 provider (insightsContext) and 3 page_blocks (AddTeamForm, AddUserForm, ClassificationUrlsBlock). These are Phase 4 scope -- cache invalidation moves to containers when container boundaries are established. (bpoProjectsContext `useQueryClient()` was dead code and was deleted with the provider in Phase 3.4.)

### Phase 3: Provider Stripping

**Goal**: Providers hold only narrow, stable UI state.

| # | Work item | Status |
|---|-----------|--------|
| 3.1 | Audit remaining providers for data-fetching, toasts, nav, storage | **DONE** (audited teamsContext, bpoProjectsContext, layout, flyoutContext, globalUi) |
| 3.2 | Strip insightsContext to state-only. Deleted constants.ts (dead), removed localStorage access, removed teams sync useEffect, co-located 15 adapters with service hooks, deleted refreshTeamsInFilters (dead after strip). `useQueryClient()` cache invalidation kept (Phase 4 scope). `usePagesStateReducer/` kept (pure state, Phase 4 scope). | **DONE** `eaa985dd`..`bda82496` (5 commits) |
| 3.3 | Strip teamsContext (TeamsProvider -> thin UI state or delete) | **DONE** `83728b18` -- provider kept (InsightsContext reads it), constants deleted (dead), types.ts -> re-export shim, 4 branded boundary fixes |
| 3.4 | Strip bpoProjectsContext (has `useQueryClient()` for cache invalidation) | **DONE** `f63be29d` -- provider deleted (zero consumers), constants deleted (dead), types.ts -> re-export shim, 1 branded boundary fix |
| 3.5 | Assess layout/ (6 files), flyoutContext.tsx, globalUi.tsx -- merge or delete | **DONE** `2fc7b6d1` -- layout already compliant (UI state only), flyoutContext already compliant (removed spurious 'use client'), globalUi deleted (completely dead) |
| 3.6 | Run `/audit-react-feature` on each provider directory | **DONE** (ran as part of 3.1) |

Remaining providers in `src/ui/providers/context/`: auth, flyoutContext.tsx, insightsContext, layout, queryClient.tsx, teamsContext, theme.tsx, urlClassification, usersContext, utils, webExtension.tsx. (`bpoProjectsContext` provider deleted, `globalUi.tsx` deleted.)

All non-infrastructure providers are now Phase 3 compliant (state-only): usersContext, urlClassification (Phase 2), teamsContext, layout, flyoutContext (Phase 3.1-3.5), insightsContext (Phase 3.2). Auth, queryClient, theme, and webExtension are infrastructure (not in scope for provider stripping).

**Exit criteria**: no provider calls service hooks, shows toasts, navigates,
or touches storage. Each provider holds at most 2-3 pieces of UI state.

### Phase 4: Container Boundaries

**Goal**: DDAU container layer established. All leaves are props-only.

| # | Work item | Status |
|---|-----------|--------|
| 4.1 | Create route containers (one per page, ~19 containers) | **DONE** -- 22 containers total. Groups A-D (12 dashboard): `6df769e8` `c1114eb4` `e52993b9` `b2c798ea` `62effd6f` `bc1bd1d5` `8dbee2cd` `9ab5c568` `8031a9bf` `52d77b7e` `408f84e6`. Group E (7 non-dashboard): `44c2c3a3` `598c2d7d` `62a27ed7` `a159c32b` `f768631b` `73b693ea` `7cc5216b`. Plus 5 filter containers from 4.4 and DashboardLayout from 4.2. |
| 4.2 | Create DashboardLayout container | **DONE** `1f26bfbb` -- split into container (EightFlowDashboardLayout, keeps hooks) + presentational (DashboardContent, props-only). Filter routing via resolveFilterComponent with TypeScript narrowing. |
| 4.3 | Create analysis sub-layout container (AnalysisLayoutContainer) | **N/A** -- UF has no `/insights/analysis/*` routes |
| 4.4 | Create InsightsFilters containers | **DONE** `a1357691` `a4bfc67f` `96613007` `00dbd3ee` `3cf5090d` `984d89ce` -- all 4 filter containers created (Insights, Opportunities, Workstreams, Realtime) |
| 4.5 | Move `useQueryClient()` into containers. Lifted from 3 page_blocks (AddTeamForm, AddUserForm, ClassificationUrlsBlock) + 1 provider (InsightsContext). refreshData eliminated. Cache invalidation inlined in 4 filter containers + WorkstreamAnalysisContainer. | **DONE** `71157a9e` `08808480` `20a3aebc` `ec6aa479` |
| 4.6 | Convert all page_blocks to props-only leaves. DashboardNavigation props-only. Users tree lifted (5 leaves). 4 dashboard sub-containers renamed. Remaining: form exceptions (AddTeamForm, AddUserForm, EditUserModal keep query hooks), FlyoutProvider scope exceptions documented. | **DONE** `7221f8cd` `1455b328` `242ab75b` |
| 4.7 | Replace chart.js/recharts usage with ECharts | **DONE** `a89cc661` `17a86f9c` `7f1aa328` -- PieChart rewritten to echarts-for-react, 17 dead files deleted, recharts + chart.js removed |
| 4.8 | Replace react-csv with papaparse | **DONE** `295e63c2` `eb5a571d` -- CSVButton rewritten to papaparse, react-csv + @types/react-csv removed |
| 4.9 | Create missing page blocks (analysis/, explorer/, insights/, etc.) | **Merged into 4.1** -- pages with inline logic (realtime, system-latency, workstream-analysis, chat) get extracted during container creation |
| 4.10 | Merge UF-only domains (classificationUrls -> settings, opportunity -> opportunitiesV2, workstreams-analyzer -> workstream-analysis) | **DONE** `746c24c4` `ded67484` `f27df503` |

**Exit criteria**: every leaf in `page_blocks/` and `components/` receives all
data as props. No leaf calls service hooks, context hooks, useRouter, storage.

### Phase 5: God Component Decomposition

**Goal**: No file over 500 lines. No JSX return over 100 lines.

| # | Work item | Status |
|---|-----------|--------|
| 5.1 | Decompose SystemsBlock | **N/A** -- deleted Phase 4, replaced by SystemsContainer (155L) |
| 5.2 | Decompose ProductivityPage | **N/A** -- decomposed into ProductivityContainer + children (Phase 4) |
| 5.3 | Decompose ProcessMiningView / ActivitiesTable | **N/A** -- restructured in 4.10, largest is column defs (209L) |
| 5.4 | Decompose OpportunitiesV2Block | **N/A** -- renamed to OpportunityBlock (120L) in 4.10 |
| 5.5 | Decompose InsightsContext consumers (chat, explorer) | **N/A** -- Chat 28L container + 104L leaf, no explorer |
| 5.6 | Flatten all JSX returns over 100 lines | **DONE** `a3ae729f` `001bbbfb` `5c46869e` -- TableFilter 51L, InsightsFilters 27L, Sidebar 33L |
| 5.A | Split Icons.tsx (630L -> barrel + sub-files) | **DONE** `b9001d0d` -- 3L barrel + NavIcons 204L, TableIcons 143L, UIIcons 282L |
| 5.E | Table.tsx type extraction (358L -> under 300L) | **DONE** `2934d8a8` -- 274L + Table.types.ts 96L |

**Revised scope**: Phase 4 container extraction eliminated all 5 original god component targets. Remaining work was JSX flattening (3 files) + Icons.tsx file split + Table type extraction. Completed in 1 session (Session 2).

**Detail plan**: `~/plans/uf-phase-5-god-components.md`

**Exit criteria**: ALL MET. `find src -name '*.tsx' | xargs wc -l | awk '$1 > 500'`
returns zero results. All JSX returns under 100 lines. Largest file: TableFilter 461L.

### Phase 6: Type Safety + Cleanup

**Goal**: Zero tsc errors, zero ESLint errors, convergence audit 14/14.

| # | Work item | Status |
|---|-----------|--------|
| 6.1 | Eliminate all `any` types in production code (parallelize with agents) | TODO |
| 6.2 | Convert all 18 enums to `as const` + union types | TODO |
| 6.3 | Eliminate unnecessary useEffects | TODO |
| 6.4 | Harden all catch clauses (typed error handling) | TODO |
| 6.5 | Add Zod validation at all trust boundaries. **Partial**: `fetchApi` `schema` required at compile time (`e6809185`); all ~120 response types derive from Zod schemas; `.passthrough()` removed from all 139 calls (`92bd52f2`); `fetchApi` schema parameter widened to decouple input/output types (`4f73dcd6`). Remaining: `typedStorage` per-key schema, `JSON.parse` Zod validation. | **PARTIAL** |
| 6.6 | Delete dead code, dead exports, dead files | **DONE** (moved to 8.0a, completed 2026-03-02) |
| 6.7 | Run convergence audit (`/audit-react-feature` on all domains), fix findings | TODO |
| 6.8 | Iterate audit until 14/14 convergence criteria met | TODO |

**Exit criteria**: `pnpm tsc --noEmit` 0 errors. `pnpm lint` 0 errors
(warnings allowed for `no-unsafe-*` backlog during migration only).
Convergence audit 14/14.

### Phase 7: Test Suite

**Goal**: 60%+ statement coverage. All tests contract-first compliant.

| # | Work item | Scope |
|---|-----------|-------|
| 7.0a | **[AUDIT GAP -- bugs]** DONE (Session 4, `87153ce4`). isUser guard, Chat try/finally, useSessionModal timer cleanup. | Small |
| 7.0b | **[AUDIT GAP -- infra]** DONE (Session 4, `4161d81f`). fetchApi content-type check, useFetchApi local-only mock-token. | Small |
| 7.0c | **[AUDIT GAP -- test infra]** DONE (Session 4 `72d99b41` + audit-fix `9f34ca25` + `7ccdcab8`). getMockedQuery centralized cast (eliminates ~53 consumer casts), deleted duplicate spec, buildMutationMock extracted to shared test-utils (4 files deduplicated), timer cleanup in 3 filter specs (afterAll vi.useRealTimers), UsersContainer weak assertions replaced with it.todo. clearAllMocks->restoreAllMocks DEFERRED (broke 55 tests, needs per-file spy audit). | Small |
| 7.0d | **[AUDIT GAP -- DDAU trivial]** DONE (Session 4, `817c52c6`). AccessDenied, EditAssignmentModal, SidebarLink converted to props-only. | Small |
| 7.1 | Port testing philosophy doc (10 principles) | Small |
| 7.2 | Audit all existing spec files with `/audit-react-test` | Medium |
| 7.3 | Delete tests scoring 4/10 or below | Medium |
| 7.4 | Rewrite surviving tests with `/refactor-react-test`. **[AUDIT]** Specific rewrite targets: RequireLoginMaybe (3/10), TenantLogin (4/10), useFeatureFlagPageGuard (4/10), useFeatureFlags (4/10), Combobox (5/10), validateDateRange (4/10), reactQueryIntegration (4/10). | Large |
| 7.5 | Build new tests with `/build-react-test` to close coverage gaps. **[AUDIT]** Add fetchApi.ts + useFetchApi.ts to scope (highest-risk untested infrastructure, not a service hook -- was missing from Session 6). | Large |
| 7.6 | Port E2E infrastructure from NGA: `e2e/fixture.ts`, Playwright config, page.route patterns for mock handler | Medium |
| 7.7 | Update UF's existing E2E specs (UF-to-UF, not NGA-to-UF): convert test-ids to kebab-case, replace inline mock data with fixture builders, update any changed routes/paths | Medium |
| 7.8 | Port `screenshot-tripwire.spec.ts` from NGA (32-line visual regression safety net) | Small |
| 7.9 | Update `e2e/constants.ts` for any test-id or column header changes from earlier phases | Small |

**Exit criteria**: 0 failing tests, 0 test regressions from prior phases,
60%+ statement coverage, all tests score 7+/10 on audit.
`pnpm e2e:test:local` passes.

**Lessons from Phase 4 (apply during Phase 7):**
- **Service hook mocking**: Container specs that test components calling
  service hooks directly MUST use `vi.mock('@/services/hooks/queries/<domain>')`
  at the module level. Passing hook mocks through `MockedProviders`
  `contextsOverrides` is dead code -- the `TeamsContextProps` type silently
  discards unknown keys. This caused 18 silent test failures in filter specs
  that were only caught during the punch list reconciliation. See commit
  `7cc4a818` for the fix pattern.
- **Prop completeness**: tsc catches missing required props, but optional
  props with defaults can silently receive `undefined` when a container
  forgets to pass them. Phase 7 audits should check for this pattern --
  a browser smoke test catches it faster than code review.
- **Fixture migration**: Replace `getMockedQuery({ data: mockedTeams })`
  inline mock shapes with fixture builders (`build()` / `buildMany()` from
  `src/fixtures/`). This ensures mock data matches production Zod schemas
  and catches shape drift between phases.

### Phase 8: Polish + Ship

**Goal**: Production-ready. Visually matches current production.

| # | Work item | Scope |
|---|-----------|-------|
| 8.0a | **[DONE]** Dead code sweep. 7 commits, ~1900 lines deleted. 14 dead files, 24 dead type exports, 34 dead mock routes, duplicate utils, fixture fixes. | DONE |
| 8.0-pre | **[AUDIT2 -- bugs]** Fix 5 bugs found by second audit: (1) UserRoleSelect ghost-state -- isUpdatingUserRole missing finally. (2) TeamUsersActions ghost-state -- isRemovingUsers missing finally. (3) AddTeamForm missing try/catch on handleTeamSubmit. (4) useAddTeamOwnersMutation missing teams/users list cache invalidation. (5) useAddUsersToTeamMutation missing cache invalidation. ~15 lines total. | Tiny (pre-work) |
| 8.0b | **[AUDIT GAP -- mock handler]** Fix getUserLoadTimeByHost schema mismatch (returns `{}`, client expects structured response). Fix getTimingInfo schema mismatch. Replace Math.random() with faker or remove delay. Dead routes already deleted in 8.0a (688L -> 153L, 16 alive routes). Optional: add skeleton routes for 37 unmocked production endpoints. | Small |
| 8.0c | **[DONE]** Cross-domain coupling fixes. 6 commits. 25 -> 9 remaining (3 provider->page_blocks + 4 shared->providers infra hooks + 2 components->page_blocks SignedInPageShell exception). Fixed C1-C7, N1, N2, N3, N8, N9. | DONE |
| 8.0d | **[DONE]** localStorage migration + trust boundary fixes. 25 raw calls migrated to typedStorage (4 exempt in featureFlagsCache). 2 storage key constants + unassignedUserItem moved to shared/constants. 3 trust boundary gaps fixed (useChatApi, router.query.id, Role[] cast). 2 remaining (storage.ts permissive schema deferred 8.0g, mapUserOccurrences LOW). Provider->page_blocks coupling 3 -> 1. | DONE |
| 8.0e | **[AUDIT GAP -- auth type consolidation]** Consolidate 11 duplicate type definitions (6 auth types highest drift risk). Migrate 12 consumer files from legacy `providers/context/auth/types.ts` to canonical `shared/types/auth.ts`. Fix `LogOutOptions` drift. | Small |
| 8.0f | **[AUDIT GAP -- re-export shim elimination]** Two categories. **Type shims** (Phase 2-3): Migrate 127 stale type imports from 5 provider context re-export files to canonical `@/shared/types/` paths. Mechanical find-and-replace across insightsContext (~60), bpoProjectsContext (~12), teamsContext (~10), usersContext (~12), urlClassification (~4), services (~64). Delete pure shim files (bpoProjectsContext/types.ts); shrink mixed files to native-only (InsightsContextProps, UsersContextProps, etc.). **Constant/util shims** (Phase 8.0c/8.0d): Migrate consumers and delete 7 re-export sites: dashboard/constants.ts (CSV_FILENAME_PREFIX, GLOSSARY_LINK_TEXT, storage keys, unassignedUserItem, reportLevelItems), OpportunityFilters/constants.ts (analyzingByItems), workstream-analysis/filters/constants.ts (analyzingByItems), operational-hours/utils.ts (getStartEndTimes), InsightsFilters/types.ts (FormattedFormState), LoginForm/types.ts (LoginStage, EnabledProviderType), ui/types/index.ts (Role, isRole, FirebaseTenantConfig). | Medium (1 session, parallelizable) |
| 8.0g | **[AUDIT GAP -- template + non-null + cleanup]** Fix 72 non-null assertions (67 from URL route helpers -- fix return type in one place). Fix 7 chained ternaries. Delete 2-3 remaining dead files + 47 dead fixture exports + 3 superseded OLD filter specs (954 lines) + `settings/Urls/types.ts`. Fix CSS typo `w=flex` in UserPanel.tsx (N1). Fix useCreateTeamMutation cache invalidation (N2). Extract `MutationOpts` shared type (8x duplication). Typo fixes (initalRole, TEAMA_TABLE_PAGE_SIZE). Type safety casts (N5, N6, N11, N12, N14). Remove `'use client'` from RequireLoginMaybe.tsx. Extract UserPanelDetails (~134L JSX). Eliminate Table.tsx sorting useEffect. See addendum "Audit 2 Detailed Findings" for full N1-N28 list. | Medium-Large |
| **Audit 3** | **DONE** (2026-03-02). 29 agents, 7 audit types. Report: `~/audits/26-03-02-15-45--user-frontend--complete-audit.md`. Diff: `~/audits/net-new--diff--26-03-01-21-05--26-03-02-15-45.md`. 28 net-new findings. 3 P0 bugs, 7 high-leverage fixes assigned to 8.0h. | DONE |
| 8.0h | **[AUDIT3 -- pre-upgrade fixes]** Fix 3 P0 bugs (getTtmForDays mock shape, `as never` webExtension, firebase `e as Error`). Fix N6 users/groups POST mock. Fix N13 monitorApiCall double-call. Fix N19 auth token to New Relic. Delete N8 dead MetadataPopupContent copies (188L) + N9 dead mocks.ts (874L). Remove N15 dead dayjs imports. Fix N25 columnHelper useMemo deps (5 files). | Small-Medium |
| 8.1 | Upgrade React 18 -> 19: fix `MutableRefObject` -> `RefObject`, resolve peer dep cascades | Large |
| 8.2 | Upgrade Next.js 14 -> 15: `eslint.dirs: []` -> `eslint.ignoreDuringBuilds: true`, route validator compliance | Large |
| 8.3 | Upgrade `react-flatpickr` 3 -> 4 (**breaking**: class -> FC, ref type, drop `@types/react-flatpickr`) | Medium |
| 8.4 | **DONE** (2026-03-02). Upgraded posthog-js 1.304.0->1.357.1 (patches last CVE), jsdom 24.1.3->28.1.0, concurrently 8.2.2->9.2.1, dotenv 16.5.0->17.3.1. sharp folded into 8.6 removal. next-themes already done in 8.2. | Medium |
| 8.5 | **DONE** -- folded into 8.1+8.2 commit `7bfbb3cc`. | Medium |
| 8.6 | **DONE** (2026-03-02). Removed 8 dead prod deps (@heroicons/react, @vercel/analytics, chartjs-adapter-moment, nuqs, react-markdown, reactflow, remark-gfm, sharp). Removed 5 dead dev deps (@storybook/addon-controls, @vitest/browser, @8flowinc/eslint-plugin, @tanstack/eslint-plugin-query, lint-staged). Moved 4 misplaced deps to dev (playwright-extra, puppeteer-extra-plugin-stealth, @types/node, typescript). sonner NOT removed (actively used by Toast.tsx, audit finding was wrong). Prod: 23, Dev: 55. | Small |
| 8.7 | ~~Browser bug bash round 1~~ | **SKIPPED** -- Firebase auth blocks local browser testing. Requires real credentials or emulator. Revisit when user can authenticate manually. |
| 8.8 | ~~Browser bug bash round 2~~ | **SKIPPED** -- depends on 8.7. |
| 8.9 | Consolidate all documentation into `docs/` | Small |
| 8.10 | Fix all 13 Storybook stories broken during Phases 2-7. Re-enable Chromatic CI on `sd/productionize`. | Medium |
| 8.11 | DDAU exception elimination. 8.11a-8.11e. Detail plan: `~/plans/uf-ddau-exception-elimination.md`. | ~3 sessions |
| 8.13 | **DONE** (2026-03-02). 5 commits, HEAD `de4594fb`. ESLint 9.32.0->10.0.2 (typescript-eslint 8.56.1, eslint-plugin-react-hooks 7.0.1, eslint-plugin-jest 29.15.0, eslint-plugin-unused-imports 4.4.1, eslint-plugin-storybook 10.2.14, removed dead eslint-plugin-vitest). Vite 6.4.1->7.3.1 + Vitest 3.1.4->4.0.18 + @vitejs/plugin-react 4.5.0->5.1.4 + @vitest/coverage-v8 3.1.4->4.0.18. ECharts 5.6.0->6.0.0, echarts-for-react 3.0.2->3.0.6. Storybook 9.0.18->10.2.14 (@storybook/nextjs->@storybook/nextjs-vite automigration, @chromatic-com/storybook 4->5). Tailwind CSS 3.4.17->4.2.1 (autoprefixer removed, @tailwindcss/postcss added). 180 specs, 2281 tests, 0 tsc errors, 0 ESLint warnings. | DONE |
| 8.14 | **DONE** (2026-03-02). nuqs filter migration. 7 commits (`3626cc5c..9c83cf58`). Infrastructure: url-params.ts (centralized parsers), NuqsAdapter in _app.tsx, global nuqs mock in vitest setup. 4 filter containers migrated (RealtimeFilters, InsightsFilters, OpportunitiesFilters, WorkstreamsFilters). MicroworkflowsContainer migrated from localStorage to InsightsContext as filter source. dashboard/utils/storage.ts DELETED. NEW_INSIGHTS_FILTERS_KEY removed from production code. 8 spec files updated. | DONE |
| 8.15 | **DONE** (2026-03-02). Cross-page navigation fix + cleanup. 2 commits (`d7f975bd`, `80a34701`). MicroworkflowsContainer passes filter state as URL query params on cross-page navigation. GLOBAL_TIMEZONE_STORAGE_KEY fully deleted. Storybook 10 story imports fixed. Tailwind 4 resolveConfig removal completed. HEAD `80a34701`. | DONE |
| 8.12 | SSR migration (if server auth bootstrap is unblocked). Dep chain: nuqs -> BFF 1.2 (auth cookie) -> SSR. | Large (deferred) |

**Audit gap items execution order**: 8.0a-8.0h all DONE. 8.0f and 8.0g are parallelizable
with agents. All audit gap pre-work completed before upgrades. Audit 3 gate passed.
See `~/plans/uf-audit-gap-addendum.md` for full analysis.

**Remaining Phase 8 items**: 8.9 (docs consolidation), 8.10 (Storybook stories), 8.11 (DDAU exception elimination). 8.7-8.8 SKIPPED (Firebase auth blocker). 8.12 deferred (SSR, needs BFF auth cookie).

**Security note**: All 4 production CVEs RESOLVED. 3 Next.js DoS vulns fixed in 8.1 (15.5.12).
1 preact VNode injection fixed in 8.4 (posthog-js 1.357.1). Zero known vulnerabilities.

**React 19 blockers (audit2)**: 3 identified -- next (needs 15+ for React 19 peerDep),
next-themes (needs 0.4+), react-flatpickr (peerDep <=19 in latest, marginal).
These are already covered by 8.1-8.3 but the blocker list is now explicit.

**BPO/Project duplication (audit2)**: BPO and Project settings blocks are 95% structurally
identical (containers, presentationals, column hooks, constants, specs). Strongest DRY
extraction candidate in the codebase. Added as backlog item (not blocking ship).

**Exit criteria**: `pnpm build` clean. `pnpm e2e:test:local` passes.
All shared features match production visually. PR ready for review.

---

## File Count Summary

Phases 1-2 are actuals (from commits). Phases 3-8 are estimates.

| Phase | Files created/ported | Files deleted | Files modified | Status |
|-------|---------------------|---------------|----------------|--------|
| 1 | ~133 (types 47, fixtures 19, skills 31, test-utils 13, hooks 5, UI 5, rest) | ~10 (dead root files + .ai/) | ~70 (config + reconciliation + schema derivation) | **DONE** |
| 2 | ~200 (105 hooks + 65 barrels + ~25 co-located mappers + 6 key files) | ~10 (factories, old hook files, react-hot-toast) | ~40 (rewire imports, strip providers) | **DONE** |
| 3 | 15 (co-located adapters) | ~25 (constants, adapters dir, refreshTeamsInFilters, globalUi) | ~55 (strip providers + rewire imports) | **DONE** |
| 4 | ~30 (containers) | ~5 (merged domains) | ~80 (convert to props-only) | **DONE** |
| 5 | 4 (3 icon sub-files + Table.types.ts) | 0 | 4 (Icons barrel, TableFilter, InsightsFilters, Sidebar) | **DONE** |
| 6 | ~5 (Zod schemas) | ~10 (dead code) | ~100 (type fixes) | PARTIAL (6.5) |
| 7 | ~60 (new/rewritten tests) | ~20 (deleted tests) | ~30 (refactored tests) | TODO |
| 8 | 0 | ~5 | ~50 (dep upgrades + bug fixes + story fixes) | TODO |

## Reference

- Archived plans: `~/plans/archive/` (22 files)
- NGA codebase: `~/github/next-gen-atlassian` branch `sd/productionize`
- NGA CLAUDE.md: the authoritative spec for all conventions
- NGA `.claude/skills/README.md`: full principles documentation
- UB (user-backend): `~/github/user-backend` -- the BFF that UF currently
  talks to. Will be ported into UF as `pages/api/` routes in a future project.
  Until then, `fetchApi` points to UB in production.
