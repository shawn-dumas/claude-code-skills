# Phase 5: God Component Decomposition -- Detail Plan

> Created: 2026-02-28. Updated: 2026-02-28 (Session 2: ALL COMPLETE).
> Repo: `~/github/user-frontend`, branch `sd/productionize`, HEAD `2934d8a8`.
> Baseline: 1893 tests pass, 0 tsc errors, 26 containers.
> Master plan: `~/plans/user-frontend-ddau-roadmap.md`.

## Executive Summary

Phase 4 container extraction eliminated all 5 original Phase 5 targets (5.1-5.5).
The remaining Phase 5 scope is significantly smaller than originally estimated:

- **1 file over 500 lines**: Icons.tsx (630L) -- SVG exports, not component logic
- **2 files over 300 lines**: TableFilter.tsx (457L), Table.tsx (358L)
- **3 files with JSX returns over 100 lines**: TableFilter (127L), InsightsFilters (124L), Sidebar (126L)
- **5 borderline files** with JSX returns 80-96 lines (monitor, no action needed)

Estimated total work: **1 session** of code changes (Session 2), plus this planning session.

## Roadmap Item Cross-Reference

| # | Original Target | Status | Rationale |
|---|-----------------|--------|-----------|
| 5.1 | Decompose SystemsBlock | **N/A** | Deleted in Phase 4 Session 6, replaced by SystemsContainer (155L) |
| 5.2 | Decompose ProductivityPage | **N/A** | Decomposed into ProductivityContainer + children during Phase 4 (largest: ProductivityByDateContainer 165L) |
| 5.3 | Decompose ProcessMiningView / ActivitiesTable | **N/A** | Restructured in 4.10. Largest: useActivityTimelineTableColumns (209L, column definitions -- not a component) |
| 5.4 | Decompose OpportunitiesV2Block | **N/A** | Renamed to opportunities/ in 4.10. Now OpportunityBlock.tsx at 120L |
| 5.5 | Decompose InsightsContext consumers (chat, explorer) | **N/A** | Chat: 28L container + 104L leaf. No "explorer" component exists. Both under all thresholds |
| 5.6 | Flatten all JSX returns over 100 lines | **APPLIES** | 3 files exceed: TableFilter (127L), InsightsFilters (124L), Sidebar (126L) |

## Inventory

### Files Over 500 Lines

| File | Lines | Type | JSX Lines | Sections | Strategy |
|------|-------|------|-----------|----------|----------|
| `src/ui/components/8flow/Icons.tsx` | 630 | SVG export collection (49 exports, 29 consumers) | N/A (no logic) | Nav, table, UI icon groups | Split into domain-grouped sub-files + barrel re-export |

### Files Over 300 Lines (Under 500)

| File | Lines | Type | JSX Lines | Sections | Strategy |
|------|-------|------|-----------|----------|----------|
| `src/ui/components/8flow/Table/TableFilter/TableFilter.tsx` | 457 | Leaf | ~127 | Filter list, action bar, error display | Flatten JSX: extract FilterRow sub-component |
| `src/ui/components/8flow/Table/Table.tsx` | 358 | Leaf | ~85 | Header area, table body, pagination | Extract ~80L of type definitions to Table.types.ts |

### JSX Returns Over 100 Lines (Any File Size)

| File | Lines | JSX Lines | Type | Strategy |
|------|-------|-----------|------|----------|
| `TableFilter.tsx` | 457 | ~127 | Leaf | `/flatten-jsx-template` -- extract FilterRow, action buttons |
| `InsightsFilters.tsx` | 265 | ~124 | Leaf | `/flatten-jsx-template` -- extract named variables for form field blocks |
| `Sidebar.tsx` | 173 | ~126 | Layout shell | `/flatten-jsx-template` -- deduplicate desktop/mobile close buttons, extract SidebarHeader |

### Borderline (80-99 Line JSX, Monitor Only)

| File | Lines | JSX Lines | Notes |
|------|-------|-----------|-------|
| `settings/Project/Project.tsx` | 157 | ~96 | Largest borderline; revisit in Phase 6 if needed |
| `users/UserPanel.tsx` | 199 | ~88 (nested in renderUserDetailsOrNull) | Render function pattern -- could extract to component |
| `workstream-analysis/filters/WorkstreamsFilters.tsx` | 166 | ~84 | Similar structure to InsightsFilters |
| `settings/Urls/ClassificationUrlsBlock.tsx` | 158 | ~80 | Acceptable |
| `components/8flow/charts/ProductivityChart/ProductivityChart.tsx` | 150 | ~80 | Acceptable |

No action needed for borderline files. All are under 200 total lines with JSX under 100 lines. The 100-line JSX threshold is the exit criterion; these pass.

## Work Items

### 5.A: Split Icons.tsx (630L -> barrel + sub-files)

**Goal**: Satisfy the 500-line exit criterion.

**Strategy**: Create sub-files grouped by usage domain. Icons.tsx becomes a barrel re-export so all 29 consumer import sites remain unchanged.

Proposed split:
- `icons/NavIcons.tsx` -- LogoIcon, LogoIconMedium, NavbarLogoLarge, DashboardSidebarIcon, DashboardUsersIcon, DashboardTeamsIcon, DashboardSettingsIcon, etc.
- `icons/TableIcons.tsx` -- SortAscIcon, SortDescIcon, FilterIcon, DownloadIcon, ExpandAllIcon, CollapseAllIcon, CardsIcon, ListIcon, etc.
- `icons/UIIcons.tsx` -- CloseIcon, CloseIconLg, CloseIconSm, UploadIcon, RedirectIcon, CheckIcon, SearchIcon, etc.
- `Icons.tsx` -> barrel: `export * from './icons/NavIcons'; export * from './icons/TableIcons'; export * from './icons/UIIcons';`

**Skill**: None (not a component refactor, just file organization).
**Commits**: 1 (split + barrel).
**Risk**: Low. No logic changes, no import site changes.

### 5.B: Flatten TableFilter.tsx JSX (127L -> under 100L)

**Goal**: Reduce JSX return from 127 lines to under 100 lines.

**Strategy**: Extract the per-filter row (lines 360-412, ~52 lines repeated per filter) into a `FilterRow` sub-component or named variable. The filter row contains: union/where selector, column select, rule select, value input, remove button.

**Skill**: `/flatten-jsx-template`
**Audit**: `/audit-react-feature` on `src/ui/components/8flow/Table/` before modifying.
**Commits**: 1.
**Risk**: Low. Pure presentational extraction, no logic changes.

### 5.C: Flatten InsightsFilters.tsx JSX (124L -> under 100L)

**Goal**: Reduce JSX return from 124 lines to under 100 lines.

**Strategy**: Extract the 7 conditional field blocks (teams, reportPeriod, reportLevel, daysPeriod, dateRange, timezone, shiftLength) into named intermediate variables above the return. Each block is 5-15 lines of `{enabledFields.x && <div>...</div>}`. Lifting them to named variables cuts the return to ~40 lines.

**Skill**: `/flatten-jsx-template`
**Audit**: `/audit-react-feature` on `src/ui/page_blocks/dashboard/ui/InsightsFilters/` before modifying.
**Commits**: 1.
**Risk**: Low. Pure template flattening, no logic changes.

### 5.D: Flatten Sidebar.tsx JSX (126L -> under 100L)

**Goal**: Reduce JSX return from 126 lines to under 100 lines.

**Strategy**: The desktop close button (lines 79-93) and mobile close button (lines 104-118) are near-identical ~15-line blocks. Extract to a `CloseButton` named variable or sub-component. Also extract `SidebarHeader` (desktop + mobile variants, lines 74-120) to a named variable. This should reduce the JSX by ~40 lines.

**Note**: Sidebar.tsx uses `useAuthState`, `usePosthogContext`, and `useLayout` directly. This is acceptable as a layout shell (same documented exception as DashboardLayout). Context usage is NOT in Phase 5 scope.

**Skill**: `/flatten-jsx-template`
**Audit**: `/audit-react-feature` on `src/ui/components/8flow/Sidebar/` before modifying.
**Commits**: 1.
**Risk**: Low. Pure template flattening, no logic changes.

### 5.E: Table.tsx Type Extraction (358L -> under 300L, optional)

**Goal**: Reduce file from 358 lines. JSX is already under 100 lines (85L).

**Strategy**: Extract ~80 lines of type definitions (BaseTableProps, ClickableRowProps, SelectionRowProps, ColumnsVisibilityProps, ExpandingProps, HeightProps, TableProps -- lines 41-121) to `Table.types.ts`. This brings the file under 300 lines.

**Skill**: None (mechanical move, not a component refactor).
**Commits**: 1.
**Risk**: Low. Type-only move with re-export.
**Priority**: Optional. The file is under 500L and JSX is under 100L. Only do this if we want tighter line-count discipline.

## Skill Protocol

| Work Item | Pre-Audit | Skill | Post-Verify |
|-----------|-----------|-------|-------------|
| 5.A Icons split | None needed | Manual | tsc + tests |
| 5.B TableFilter flatten | `/audit-react-feature` on Table/ | `/flatten-jsx-template` | tsc + tests + JSX line count |
| 5.C InsightsFilters flatten | `/audit-react-feature` on InsightsFilters/ | `/flatten-jsx-template` | tsc + tests + JSX line count |
| 5.D Sidebar flatten | `/audit-react-feature` on Sidebar/ | `/flatten-jsx-template` | tsc + tests + JSX line count |
| 5.E Table types (optional) | None needed | Manual | tsc + tests |

## Session Plan

### Session 1 (2026-02-28) -- INVENTORY + PLAN

**Deliverable**: This plan file.
**Code changes**: None. All work items deferred to Session 2.

### Session 2 (2026-02-28) -- ALL DECOMPOSITIONS -- COMPLETE

**Commits** (5 total):

1. `b9001d0d` -- 5.A: Icons.tsx split (630L -> 3L barrel + 3 sub-files: NavIcons 204L, TableIcons 143L, UIIcons 282L)
2. `a3ae729f` -- 5.B: TableFilter.tsx flatten (JSX 127L -> 51L, extracted filterRows + actionBar)
3. `001bbbfb` -- 5.C: InsightsFilters.tsx flatten (JSX 124L -> 27L, extracted 7 field variables + glossaryAndControls)
4. `5c46869e` -- 5.D: Sidebar.tsx flatten (JSX 127L -> 33L, deduplicated closeButton, extracted sidebarHeader + navLinks + expandCollapseButton)
5. `2934d8a8` -- 5.E: Table.tsx type extraction (358L -> 274L, types to Table.types.ts 96L)

**Verification** (all pass):
- `pnpm tsc --noEmit` -- 0 errors
- `pnpm vitest run` -- 1893 passed (matches baseline)
- `find src -name '*.tsx' ... | xargs wc -l | awk '$1 > 500'` -- 0 results (largest: TableFilter 461L)
- JSX check: TableFilter 51L, InsightsFilters 27L, Sidebar 33L (all under 100)

## Exit Criteria Verification

After Session 2:

```
find src -name '*.tsx' -not -name '*.spec.*' -not -name '*.stories.*' \
  | xargs wc -l | awk '$1 > 500' | sort -rn
# Expected: 0 results (Icons.tsx split below 500)

# JSX return check (manual for 3 files):
# TableFilter.tsx JSX < 100 lines
# InsightsFilters.tsx JSX < 100 lines
# Sidebar.tsx JSX < 100 lines
```

## Carry-Forward Items (NOT in Phase 5 scope)

1. SettingsNavigation.tsx retains `usePathname()` -- lift when settings/ gets containers
2. WorkstreamsFiltersContainer.tsx uses raw `localStorage.setItem` -- migrate to typedStorage
3. Sidebar.tsx uses `useAuthState`/`usePosthogContext`/`useLayout` directly -- documented layout shell exception (same as DashboardLayout)
4. UserPanel.tsx nested `renderUserDetailsOrNull()` (88L JSX) -- could extract to component in Phase 6
5. Project.tsx borderline JSX (96L) -- monitor in Phase 6

## NGA Reference (archived)

The original plan referenced NGA god component decompositions (ProductivityPage 5860->1284L,
ProcessMiningView 4655->1547L, SystemsBlock 1017->530L, OpportunitiesV2Block 2388->1273L).
Phase 4 container extraction in UF followed a different path but achieved the same structural
outcome: no god components remain. The NGA commit sequences are preserved in
`~/plans/user-frontend-ddau-roadmap.md` progress log and the archived version of this file
(git history).
