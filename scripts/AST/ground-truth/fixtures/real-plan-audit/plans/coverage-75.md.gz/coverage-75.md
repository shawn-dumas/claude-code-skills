# Backlog: Coverage to 75%

> Created: 2026-03-06
> Branch: sd/productionize
> Baseline: 68.66% stmts | 67.28% branch | 64.79% funcs | 68.86% lines
> Target: 75% across all four metrics
> Test files: 200 | Tests: 2,519

## Items

| # | Item | Type | Files | Effort | Prompt | Status |
|---|------|------|-------|--------|--------|--------|
| C1 | Exclude non-testable files from coverage (stories, CSS, SVGs, images, thin pages, mock handler, type-only barrel files) | config | 1 | small | 01 | done |
| C2 | Test service hook query wrappers (33 useXxxQuery.ts files at 0%) | test | ~33 | large | 02 | done |
| C3 | Test service hook mutation wrappers (19 mutation files, most at 0%) | test | ~19 | large | 03 | done |
| C4 | Test fixture builders and scenario.ts | test | ~10 | medium | 04 | done |
| C5 | Test 8flow components: CSVButton, Header, NavigationMenu, Sidebar, PageShells, PieChart, WorkstreamGanttChart, ProductivityChart | test | ~10 | large | 05 | done |
| C6 | Test shared/ui gaps: SortingSelect, FloatingGlossaryHelp, Spinner, MetricItemStandard + Storybook-adjacent components | test | ~8 | medium | 05 | done |
| C7 | Test providers: webExtension.tsx, Providers.tsx, auth utils/user.ts, useCountdown, usePosthogClient, useHydrated | test | ~8 | medium | 06 | done |
| C8 | Test page block gaps: dashboard layout, workstream-analysis (WorkstreamAnalysis.tsx, analyzerColumns, segmentsTable), users (Users.tsx, UserPanel, Assignments), settings/Urls deeper coverage | test | ~15 | large | 07 | done |
| C9 | Test shared/types schema files (runtime validation code), urls_registry.ts, query keys/insights.ts | test | ~10 | medium | 08 | done |
| C10 | Final validation: re-run coverage, identify and close remaining gaps | validation | 0 | small | 09 | done |

## Dependency Graph

```
Prompt 01 (coverage config -- independent, must run first)
     |
     v
Prompt 02 (query hooks -- independent of 03-08)
Prompt 03 (mutation hooks -- independent of 02, 04-08)
Prompt 04 (fixtures -- independent of 02-03, 05-08)
     |  (fixtures used by later prompts, run early)
     v
Prompt 05 (UI components -- independent)
Prompt 06 (providers -- independent)
Prompt 07 (page blocks -- may use fixtures from 04)
Prompt 08 (shared infrastructure -- independent)
     |
     v
Prompt 09 (final validation -- depends on all above)
```

Prompt 01 must run first because it changes the coverage denominator.
Prompts 02-08 are independent of each other and could run in any order,
but 04 (fixtures) should run before 07 (page blocks) since page block
tests may use fixture builders. Prompt 09 runs last to measure and close gaps.

## Prompt Sequence

| # | Prompt | Items | Prerequisite | Status |
|---|--------|-------|-------------|--------|
| 01 | coverage-config | C1 | none | done |
| 02 | service-hook-queries | C2 | 01 | done |
| 03 | service-hook-mutations | C3 | 01 | done |
| 04 | fixture-coverage | C4 | 01 | done |
| 05 | ui-components | C5, C6 | 01 | done |
| 06 | providers-hooks | C7 | 01 | done |
| 07 | page-blocks | C8 | 01, 04 | done |
| 08 | shared-infrastructure | C9 | 01 | done |
| 09 | final-validation | C10 | all | done |

## Coverage Gap Analysis

### Current vs Target (delta needed)

| Metric | Original | Post-C1 | Final | Target | Result |
|--------|----------|---------|-------|--------|--------|
| Statements | 68.66% | 74.37% | 90.39% | 75% | PASS (+21.73pp) |
| Branches | 67.28% | 70.79% | 80.06% | 75% | PASS (+12.78pp) |
| Functions | 64.79% | 69.3% | 88.29% | 75% | PASS (+23.50pp) |
| Lines | 68.86% | 74.83% | 90.99% | 75% | PASS (+22.13pp) |

Final test count: 312 spec files, 3,336 tests (up from 200 / 2,519)

## Cleanup

Cleanup prompt completed 2026-03-06. All 7 fixes applied across 5 commits.
Resolved: flatpickr warnings, urlsRegistryMocks type mismatch, shared
renderServiceHook utility (52 specs), PieChart formatter extraction,
webExtension sendMessage coverage, ActivityTimeline column edge cases.
See ~/plans/coverage-75-cleanup.md for item-level resolution status.

Functions is the hardest metric -- needs +10.21pp. This is because many
files (especially service hooks and fixture builders) export functions
that are never called in tests.

### Strategy: Two levers

1. **Shrink the denominator** (Prompt 01): Exclude files that should not
   be in the coverage denominator -- story files, CSS, SVGs, images, the
   dev-only mock API handler, thin page route wrappers. Estimated impact:
   +3-5pp across all metrics.

2. **Grow the numerator** (Prompts 02-08): Write tests for the largest
   uncovered areas. Priority order by coverage impact:
   - Service hooks (33 queries + 19 mutations = 52 files at ~0%)
   - Fixture builders (~10 files, many at 0-10%)
   - UI components (~18 files with significant gaps)
   - Providers and hooks (~8 files)
   - Page block gaps (~15 files)
   - Shared infrastructure (~10 files)
