# Audit Fixes: Playwright test gap closure

> Source: Three post-orchestration reports from pw-assertion-depth-fix:
>
> - ~/reports/pw-assertion-depth-fix-audit.md (test intent audit)
> - ~/reports/pw-assertion-depth-fix-gap-check.md (gap re-check)
> - ~/reports/pw-fixture-data-gap-analysis.md (fixture data gaps)
> - ~/plans/archive/pw-assertion-depth-fix-cleanup.md (7 open items)
>   Created: 2026-03-12
>   Branch: sd/productionize
>   Integration scope: per-prompt

## Findings Summary

| Severity | Count | Description                             |
| -------- | ----- | --------------------------------------- |
| P2       | 4     | Dead code, handler risk, triage items   |
| P3       | 24    | Missing tests, fixtures, infrastructure |
| Total    | 28    |                                         |

No P1 (security/trust boundary) findings.

## Findings Index

| #   | Sev | Domain            | File/Area                              | Finding                                                       | Prompt |
| --- | --- | ----------------- | -------------------------------------- | ------------------------------------------------------------- | ------ | --------------------------------------------------- |
| 1   | P2  | users             | integration/tests/users.spec.ts:101    | Dead page.route intercept for /users/update-role              | 00     |
| 2   | P2  | mock-handler      | src/pages/api/mock/users/groups/       | Mock create handlers may reuse pool IDs (audit needed)        | 00     |
| 3   | P2  | teams             | integration/tests/teams.spec.ts:82     | Flaky team creation test (intermittent 90s timeout)           | 09     | investigated -- server contention, not test bug     |
| 4   | P2  | systems           | integration/tests/systems.spec.ts      | Workstreams sub-table tab: missing feature or wrong test?     | 09     | investigated -- no test gap, original e2e was wrong |
| 5   | P3  | POM               | integration/pages/InsightsPage.ts      | Missing trySelectAllPageSize() helper                         | 00     |
| 6   | P3  | POM               | integration/pages/NavigationPage.ts    | Missing navigateToTabClientSide() method                      | 00     |
| 7   | P3  | fixtures          | integration/fixtures/systems.ts        | No \*Large fixture for systems pagination (need 30+ rows)     | 01     |
| 8   | P3  | fixtures          | integration/fixtures/microworkflows.ts | No \*Large fixture for MW pagination (need 30+ rows)          | 01     |
| 9   | P3  | fixtures          | integration/fixtures/user-prod.ts      | No \*Large fixture for UP pagination (need 30+ rows)          | 01     |
| 10  | P3  | fixtures          | integration/fixtures/favorites-relays  | No \*Large fixture for fav/relay pagination (need 30+ rows)   | 01     |
| 11  | P3  | systems           | integration/tests/systems.spec.ts      | Missing SOURCE PAGE sort test for Into activities             | 03     | addressed                                           |
| 12  | P3  | team-productivity | integration/tests/team-prod.spec.ts    | Missing PROJECTS column sort test for Combined table          | 05     | addressed                                           |
| 13  | P3  | user-productivity | integration/tests/user-prod.spec.ts    | Missing sub-table sorting (By Host, By Date, TTM -- 11 asrt)  | 04     | addressed                                           |
| 14  | P3  | microworkflows    | integration/tests/microworkflows.spec  | Missing empty-state test (no team selected)                   | 03     | addressed                                           |
| 15  | P3  | favorites         | integration/tests/favorites.spec.ts    | Missing empty-state test                                      | 04     | addressed                                           |
| 16  | P3  | operational-hours | integration/tests/op-hours.spec.ts     | Missing empty-state test (new coverage)                       | 07     | addressed                                           |
| 17  | P3  | users             | integration/tests/users.spec.ts        | Reduced multi-role setUserName (1/3 roles covered)            | 02     | addressed                                           |
| 18  | P3  | users             | integration/tests/users.spec.ts        | Missing user-page BPO/Project assignment flows (2 tests)      | 02     | addressed                                           |
| 19  | P3  | assignments       | integration/tests/assignments.spec.ts  | Missing single-user multi-assignment badge +N test            | 02     | addressed                                           |
| 20  | P3  | export            | integration/tests/export.spec.ts       | Missing sortColumn/sortMode in export test calls              | 06     | addressed                                           |
| 21  | P3  | export            | integration/tests/export.spec.ts       | Reduced UP export column list (5/17 verified)                 | 06     | addressed                                           |
| 22  | P3  | export            | integration/tests/export.spec.ts       | Missing TP sub-table exports (Per Team/Project/BPO, 3 tests)  | 06     | addressed                                           |
| 23  | P3  | export            | integration/tests/export.spec.ts       | Missing UP drill-down exports (3 flows)                       | 06     | addressed                                           |
| 24  | P3  | components        | integration/tests/components.spec.ts   | Weakened filter persistence assertion (needs client-side nav) | 05     | addressed                                           |
| 25  | P3  | components        | integration/tests/components.spec.ts   | No error-state test for any page                              | 07     | addressed                                           |
| 26  | P3  | components        | integration/tests/components.spec.ts   | No filter-param API verification                              | 07     | addressed                                           |
| 27  | P3  | scenario          | src/fixtures/scenario.ts               | Scenario team count too low (3, realistic: 10-15)             | 08     | addressed                                           |
| 28  | P3  | scenario          | src/fixtures/identity-pool.ts          | Scenario systems count too low (12, realistic: 30+)           | 08     | addressed                                           |

## Deferred Items (Low priority, not in this plan)

- Add Settings tab in filter persistence test (Low, audit #13)
- Add sequential deletion order verification in assignments (Low, audit #14)
- Mine Postgres dump for realistic distribution profiles (Low, fixture #8)
- Increase BPO/project counts to 10-15 (Low, fixture #9)
- StackedBar sort fragility observation (cleanup, monitor)
- Hidden TabPanel cell text leakage observation (cleanup, monitor)
- Team-productivity sort test slice indices fragility (cleanup, monitor)

## Prompt Sequence

11 prompts. P00-P01 are infrastructure (no Playwright). P02-P07 add tests
(per-prompt Playwright verification). P08 changes the scenario (full suite).
P09 is investigation. P10 is final validation.

| #   | Prompt                 | Domain                   | Findings              | Chunk Verification       | Status |
| --- | ---------------------- | ------------------------ | --------------------- | ------------------------ | ------ |
| 0   | pw-test-gap-closure-00 | POM + cleanup            | #1, #2, #5, #6        | none (infra)             | done   |
| 1   | pw-test-gap-closure-01 | fixtures                 | #7, #8, #9, #10       | none (infra)             | done   |
| 2   | pw-test-gap-closure-02 | users + assignments      | #17, #18, #19         | crud                     | done   |
| 3   | pw-test-gap-closure-03 | systems + microworkflows | #11, #14 + pagination | insights-a1, insights-a2 | done   |
| 4   | pw-test-gap-closure-04 | user-prod + favorites    | #13, #15 + pagination | insights-a3, insights-b1 | done   |
| 5   | pw-test-gap-closure-05 | team-prod + components   | #12, #24              | insights-c2              | done   |
| 6   | pw-test-gap-closure-06 | export                   | #20, #21, #22, #23    | insights-c2              | done   |
| 7   | pw-test-gap-closure-07 | new coverage             | #16, #25, #26         | insights-c2              | done   |
| 8   | pw-test-gap-closure-08 | scenario expansion       | #27, #28              | full suite               | done   |
| 9   | pw-test-gap-closure-09 | triage                   | #3, #4                | none (investigation)     | done   |
| 10  | pw-test-gap-closure-10 | validation               | --                    | full suite               | done   |

## Dependency Graph

```
P00 (POM helpers) ──┐
                    ├── P02 (CRUD) ──────────────┐
P01 (fixtures) ─────┤                            │
                    ├── P03 (systems + MW) ──────┤
                    │                            │
                    ├── P04 (UP + favorites) ────┤
                    │                            │
                    ├── P05 (TP + components) ───┤
                    │                            ├── P08 (scenario) ── P10 (validation)
                    ├── P06 (export) ────────────┤
                    │                            │
                    └── P07 (new coverage) ──────┘
                                                 │
P09 (triage) ────────────────────────────────────┘
```

- P00 and P01 have no dependencies and could conceptually run in parallel
  (but orchestration is sequential -- P00 first since it's simpler)
- P02-P07 depend on P00 (POM helpers) and P01 (large fixtures for
  pagination tests in P03, P04). Within P02-P07, no inter-dependencies.
- P05 depends on P00 specifically for navigateToTabClientSide (#6)
- P08 (scenario expansion) runs after all test-writing to avoid
  destabilizing tests mid-sequence. This is the highest-risk prompt.
- P09 (triage) is independent -- investigation only, no code changes.
  Positioned late because it has no downstream dependents.
- P10 runs after everything.

## Chunk Mapping

For Playwright verification:

| Chunk       | Specs Affected                        | Prompts |
| ----------- | ------------------------------------- | ------- |
| crud        | users, assignments                    | P02     |
| insights-a1 | systems                               | P03     |
| insights-a2 | microworkflows                        | P03     |
| insights-a3 | user-productivity                     | P04     |
| insights-b1 | favorites (relays unchanged)          | P04     |
| insights-c2 | team-prod, components, export, op-hrs | P05-P07 |
| full suite  | all                                   | P08, 10 |

## Verification Checklist

| #   | Agent Ran PW?       | Orchestrator Ran PW?    | Results Match?                                       | PASS/FAIL |
| --- | ------------------- | ----------------------- | ---------------------------------------------------- | --------- |
| 0   | N/A (infra)         | N/A (infra)             | N/A                                                  | PASS      |
| 1   | N/A (infra)         | N/A (infra)             | N/A                                                  | PASS      |
| 2   | Yes (crud)          | Yes (crud + spec)       | 2 pre-existing failures; new tests pass in isolation | PASS      |
| 3   | Yes (insights-a)    | Yes (insights-a)        | 3 pre-existing ENOENT failures; new tests pass       | PASS      |
| 4   | Yes (a+b)           | Yes (a+b)               | 0 failures; all new tests pass                       | PASS      |
| 5   | Yes (insights-c)    | Yes (insights-c)        | 0 failures, 1 pre-existing skip; new tests pass      | PASS      |
| 6   | Yes (insights-c)    | Yes (insights-c)        | 0 failures, 1 pre-existing skip; 10 active tests     | PASS      |
| 7   | Yes (insights-c)    | Yes (spec isolation)    | New tests pass; full chunk deferred (contention)     | PASS      |
| 8   | Yes (full suite)    | Yes (full suite)        | 4 pre-existing failures (route timing); 0 new        | PASS      |
| 9   | N/A (investigation) | N/A (investigation)     | N/A                                                  | PASS      |
| 10  | N/A (O-agent ran)   | Yes (full + insights-c) | All pre-existing; 0 new regressions                  | PASS      |

## Final Score

**Total Playwright tests: 290** (was 241 before plan, +49 net new)

New tests added by this plan: ~49 (across P02-P07)

### Full suite results (P10 validation)

| Chunk       | Tests | Passed | Failed | Skipped | Time  | Notes                                        |
| ----------- | ----- | ------ | ------ | ------- | ----- | -------------------------------------------- |
| CRUD        | 54    | 33     | 3      | 18      | 10.7m | Pre-existing ENOENT cascade after ~8m        |
| Insights-A1 | 49    | 49     | 0      | 0       | 5.0m  | Clean                                        |
| Insights-A2 | 36    | 33     | 3      | 0       | 2.6m  | Pre-existing ENOENT mid-chunk                |
| Insights-A3 | 32    | 32     | 0      | 0       | 2.6m  | Clean                                        |
| Insights-B1 | 27    | 27     | 0      | 0       | 2.9m  | Clean                                        |
| Insights-B2 | 15    | 10     | 5      | 0       | 2.0m  | Pre-existing ENOENT/route timing races       |
| Insights-C1 | 23    | 23     | 0      | 0       | 2.2m  | Clean                                        |
| Insights-C2 | 40    | 35     | 4      | 1       | 2.3m  | Pre-existing ENOENT + 1 pre-existing skip    |
| **Total**   | 276\* | 242    | 15     | 19      | ~31m  | \*14 tests did not run due to serial cascade |

\*Note: 290 total listed tests; 276 attempted due to CRUD serial cascade skipping 18.
All 15 failures are pre-existing ENOENT/server-contention/route-timing patterns.
Zero new regressions from this plan.

### Standard verification

- tsc: 0 errors
- Unit tests: 317 files, 3410 passed
- Build: clean
- ESLint: 0 errors, 1 pre-existing warning (DashboardLayout.spec.tsx, commit 11e83e37 from March 6)

## Execution Notes

### Risk assessment

- **P08 (scenario expansion) is the highest-risk prompt.** Changing team
  count from 3 to 10-15 and systems from 12 to 30+ affects the base
  scenario served by all mock handler routes. Every existing Playwright
  test that references team names, team counts, or filter dropdown
  selections may need adjustment. The prompt must include a full suite
  run and detailed analysis of any failures.

- **P06 (export expansion) is the highest-effort prompt.** Porting 6
  sub-table export flows (3 TP, 3 UP) requires understanding the
  drill-down navigation, sub-table exposure, and CSV column mapping.
  Recommend manual execution.

- **P03-P04 (pagination tests) depend on P01 fixtures.** If P01 fixture
  shapes are wrong, pagination tests will fail. P01 verification is
  tsc-only, so the first real test is P03.

### Auto vs manual recommendations

| Prompt | Recommendation | Rationale                                              |
| ------ | -------------- | ------------------------------------------------------ |
| P00    | Auto           | Mechanical: POM helpers + dead code removal            |
| P01    | Auto           | Mechanical: fixture builder calls with count overrides |
| P02    | Auto           | Well-scoped: 5 tests in 2 spec files                   |
| P03    | Auto           | Well-scoped: 1 sort test + 1 empty state + pagination  |
| P04    | Auto           | Well-scoped: sub-table sort + empty state + pagination |
| P05    | Auto           | Small: 1 sort test + 1 filter persistence upgrade      |
| P06    | Manual         | Complex: 6 new export flows, drill-down navigation     |
| P07    | Auto           | Medium: error state + filter-param + empty state       |
| P08    | Manual         | High risk: scenario changes affect all tests           |
| P09    | Auto           | Investigation only, no code changes expected           |
| P10    | Auto           | Verification only                                      |
