# Audit Fix Plan

> Created: 2026-03-10
> Branch: sd/productionize
> Source audit: ~/audits/26-03-10-15-40--user-frontend--complete-audit.md
> Status: COMPLETE (all 12 prompts executed and verified; P-10 and P-12 partial -- deferred items in cleanup)
> Integration scope: none
> Cleanup file: ~/plans/audit-fix-26-03-10-15-40-cleanup.md

## Overview

Fix prompts generated from Audit 8 (26-03-10-15-40) Findings Index. 12 prompts covering 4 categories (Bug, Architecture, Dead Code, Test Gap) at 3 concern levels (High, Medium, Low). Total estimated effort: ~20 hours across all prompts.

## Dependencies

Most prompts are independent within a tier. Known ordering constraints:

- P-06 (Architecture/Medium) should run before P-07 (Dead Code/Medium) -- both touch shared/lib files
- P-10 (Architecture/Low) should run before P-11 (Dead Code/Low) -- both touch feature component files
- P-01 (Bug/High) touches shared types; P-09 (Bug/Low) also touches Filters type -- run P-01 first

Within each row, prompts are otherwise independent.

## Prompt Sequence

| # | File | Category | Concern | Fixes | Est. Commits |
|---|------|----------|---------|-------|-------------|
| P-01 | audit-fix-26-03-10-15-40-P01-bug-high.md | Bug | High | 3 | 2-3 |
| P-02 | audit-fix-26-03-10-15-40-P02-architecture-high.md | Architecture | High | 2 | 2 |
| P-03 | audit-fix-26-03-10-15-40-P03-deadcode-high.md | Dead Code | High | 1 | 1 |
| P-04 | audit-fix-26-03-10-15-40-P04-testgap-high.md | Test Gap | High | 3 | 3 |
| P-05 | audit-fix-26-03-10-15-40-P05-bug-medium.md | Bug | Medium | 7 | 3-4 |
| P-06 | audit-fix-26-03-10-15-40-P06-architecture-medium.md | Architecture | Medium | 9 | 4-5 |
| P-07 | audit-fix-26-03-10-15-40-P07-deadcode-medium.md | Dead Code | Medium | 6 | 2 |
| P-08 | audit-fix-26-03-10-15-40-P08-testgap-medium.md | Test Gap | Medium | 8 | 2-3 |
| P-09 | audit-fix-26-03-10-15-40-P09-bug-low.md | Bug | Low | 9 | 2-3 |
| P-10 | audit-fix-26-03-10-15-40-P10-architecture-low.md | Architecture | Low | 15 | 3-4 |
| P-11 | audit-fix-26-03-10-15-40-P11-deadcode-low.md | Dead Code | Low | 14 | 2 |
| P-12 | audit-fix-26-03-10-15-40-P12-testgap-low.md | Test Gap | Low | 6 | 6+ |

## Verification Commands

```bash
git log --oneline -10
pnpm tsc --noEmit
pnpm test --run 2>&1 | tail -5
pnpm build 2>&1 | tail -5
npx eslint . --max-warnings 0 2>&1 | tail -3
```

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| P-01 | N/A (scope: none) | N/A | N/A | PASS |
| P-02 | N/A (scope: none) | N/A | N/A | PASS |
| P-03 | N/A (scope: none) | N/A | N/A | PASS |
| P-04 | N/A (scope: none) | N/A | N/A | PASS |
| P-05 | N/A (scope: none) | N/A | N/A | PASS |
| P-06 | N/A (scope: none) | N/A | N/A | PASS |
| P-07 | N/A (scope: none) | N/A | N/A | PASS |
| P-08 | N/A (scope: none) | N/A | N/A | PASS |
| P-09 | N/A (scope: none) | N/A | N/A | PASS |
| P-10 | N/A (scope: none) | N/A | N/A | PASS |
| P-11 | N/A (scope: none) | N/A | N/A | PASS |
| P-12 | N/A (scope: none) | N/A | N/A | PASS |

## Progress

| # | Status | HEAD | Notes |
|---|--------|------|-------|
| P-01 | PASS | 52635d47 | 3 commits (ee8021bd..52635d47). tryParseJson schema overload, firebase-admin Zod parse, calculatePeriodEnds length guard |
| P-02 | PASS | ba41f992 | 2 commits (5618a93e..ba41f992). Nuqs race fix: shared useOpportunitiesUrlParams, isHours into useQueryStates |
| P-03 | PASS | 41bfff0e | 1 commit. pg removed from package.json |
| P-04 | PASS | a694896c | 3 commits (273fa17f..a694896c). 3 specs rewritten, 0 as-any in all 3, 3413 tests passing |
| P-05 | PASS | eacb747c | 4 commits (184ae7ac..eacb747c). 7 isNaN replaced, OrganizationId(0) removed, z.enum in 3 schemas, lastSignInTime guarded, mock handlers fixed. 2 out-of-scope isNaN added to cleanup |
| P-06 | PASS | 7420b923 | 4 commits (9e1dc972..7420b923). 5 complexity reductions, sendMessage loop, 2 useEffects eliminated. buildStandardScenario deviation noted |
| P-07 | PASS | 7a9dc65e | 1 commit. 4 dead deps removed, 2 barrels deleted, LoginType dual path eliminated, ChatMessage alias removed |
| P-08 | PASS | a3a893d6 | 1 commit. 5 afterEach blocks added, 3 non-deterministic dates fixed. 3 fixes skipped (already handled by P-04 rewrite or global setup) |
| P-09 | PASS | d546fa81 | 3 commits (3127fdf3..d546fa81). dateRange optional (6 casts removed), ghost state fix, tableStorage Partial return type, tuple guards, mock STUB comments |
| P-10 | PASS | 22d7c7a0 | 3 commits (b80de3be..22d7c7a0). 7/15 fixes applied (mock consolidation, type org, barrel exports, lookup maps). 8 skipped with rationale (CLAUDE.md exceptions, G3 threshold, migration risk). 6 items added to cleanup |
| P-11 | PASS | a1fe6bfd | 1 commit. 11 dead exports removed, 4 dead typeof guards removed, 15 stale tests cleaned up. 2 exports kept (active consumers found). Tests 3414->3399 |
| P-12 | PASS (partial) | fce78c17 | 2 commits (9f37414d..fce78c17). 14 as-any casts removed, 2 own-component mocks removed. Fixes 1,2,3,6 deferred to cleanup (8+ hours of test rewrites/creation) |
