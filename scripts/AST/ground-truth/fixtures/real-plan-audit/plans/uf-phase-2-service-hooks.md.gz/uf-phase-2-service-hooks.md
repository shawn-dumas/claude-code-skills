# Phase 2: Service Hook Extraction

> Extract all data-fetching logic from components and providers into
> dedicated service hooks. Establish `src/ui/services/hooks/` as the
> sole owner of all useQuery/useMutation calls.

## Prerequisites

- Phase 1 complete (types, fetchApi, fixtures, mock handler all working)

## Exit Criteria

- `src/ui/services/hooks/` has ~67 files across queries/, mutations/, keys/
- No component or provider imports `useQuery`/`useMutation` directly
- `companyData.ts` deleted (if it exists in UF)
- `createQueryFactory`/`createMutationFactory` and `context/utils/api/` deleted
- `usersContext/` provider deleted (logic moved to service hooks)
- `urlClassification/` provider deleted (logic moved to service hooks)
- `react-hot-toast` replaced with `sonner`
- All toast calls live in containers or event handlers, never in service hooks
- `pnpm tsc --noEmit` clean, `pnpm test` -- no new failures

## Target Directory Structure

```
src/ui/services/hooks/
  queries/
    bpo-projects/        useGetAllGroupsQuery.ts, ...
    company-data/        useCompanyEventsQuery.ts, useCompanySpansQuery.ts, ...  (11 files)
    company/             useCompanyStatusQuery.ts, ...
    insights/            useGetHostTimeQuery.ts, useGetOperationalAnalysisQuery.ts, ...  (10 files)
    teams/               useTeamsQuery.ts, useTeamUsersQuery.ts, ...
    url-classification/  useClassificationUrlsQuery.ts, ...
    users/               useUsersQuery.ts, useAssignableUsersQuery.ts, ...
  mutations/
    bpo-projects/        useCreateGroupMutation.ts, useDeleteGroupMutation.ts, ...
    company/             useClearDatasetMutation.ts, ...
    teams/               useCreateTeamMutation.ts, useUpdateTeamMutation.ts, ...
    url-classification/  useUpdateClassificationMutation.ts, ...
    users/               useUpdateUserRoleMutation.ts, ...
  keys/
    bpo-projects.ts
    company-data.ts
    insights.ts
    teams.ts
    url-classification.ts
    users.ts
  useFilterStore.ts + spec
  useSelectedWorkstreams.ts + spec
```

## Skill Protocol

All build and refactor work uses `.claude/skills/`. Do not do this work manually.

- **Before any write skill**: run `/audit-react-feature` on the target directory
- `/build-react-service-hook` for each new query and mutation hook (steps 2.4, 2.5)
- `/refactor-react-service-hook` if adapting an existing hook rather than creating new
- `/replace-npm-package` for the react-hot-toast -> sonner swap (step 2.7)
- Exception: directory scaffolding, key file creation, and file deletion are manual

## Execution Order

### 2.1: Inventory (audit, no code changes)

Find every `useQuery` and `useMutation` call in UF's `src/ui/`:
```bash
grep -rn "useQuery\|useMutation" src/ui/ --include="*.ts" --include="*.tsx" \
  | grep -v node_modules | grep -v ".spec." | grep -v ".test."
```

Categorize each by:
- **Domain**: which data entity does it fetch/mutate?
- **Location**: is it in a component, provider, or already standalone?
- **Pattern**: does it use createQueryFactory or raw useQuery?

### 2.2: Scaffold directory structure

```bash
mkdir -p src/ui/services/hooks/{queries/{bpo-projects,company-data,company,insights,teams,url-classification,users},mutations/{bpo-projects,company,teams,url-classification,users},keys}
```

### 2.3: Create query key modules (6 files)

Each domain gets a key file with typed factory functions:
```ts
// keys/teams.ts
export const teamsKeys = {
  all: ['teams'] as const,
  lists: () => [...teamsKeys.all, 'list'] as const,
  list: (orgId: string) => [...teamsKeys.lists(), orgId] as const,
  details: () => [...teamsKeys.all, 'detail'] as const,
  detail: (teamId: number) => [...teamsKeys.details(), teamId] as const,
};
```

### 2.4: Extract query hooks (~35 hooks)

**Use `/build-react-service-hook`** for each new hook. Do not write by hand.

For each useQuery currently embedded in a provider or component:

1. Run `/audit-react-feature` on the provider directory containing the hook
2. Run `/build-react-service-hook` to generate the new hook file
3. The hook calls `useFetchApi` (not raw fetch)
4. The hook accepts only the parameters it needs (no ambient context reads)
5. The hook returns the TanStack Query result (data, isLoading, error)
6. No toasts, no navigation, no storage access in the hook
7. Wire the Zod schema from `src/shared/types/*.schema.ts`

**Domain extraction order** (from NGA experience):
1. **Teams** (simplest, fewest hooks) -- useTeamsQuery, useTeamUsersQuery
2. **Users** -- useUsersQuery, useAssignableUsersQuery
3. **BPO/Projects** -- useGetAllGroupsQuery
4. **URL Classification** -- useClassificationUrlsQuery
5. **Company** -- useCompanyStatusQuery
6. **Company Data** (largest, 11 hooks) -- events, spans, kpis, microworkflows, etc.
7. **Insights** (largest, 10 hooks) -- getHostTime, getOperationalAnalysis, etc.

### 2.5: Extract mutation hooks (~15 hooks)

**Use `/build-react-service-hook`** for each new mutation hook.

Same pattern as queries but for mutations:
- Each mutation hook calls `useFetchApi` for the POST/PUT/DELETE
- Uses `useMutation` with `onSuccess` for query invalidation only
- No toasts in the hook (toast in the container's onSuccess callback)
- Fire-and-forget mutations use `schema: z.unknown()`

### 2.6: Wire through useFetchApi + Zod schemas

Every extracted hook must:
- Import its schema from `@/shared/types/*.schema.ts`
- Pass the schema to `useFetchApi` (required, not optional)
- Never use `as T` casts on response data

### 2.7: Replace react-hot-toast with sonner

**Use `/replace-npm-package`** to automate this swap.

```bash
pnpm remove react-hot-toast
pnpm add sonner
```

Find all `toast()` calls:
```bash
grep -rn "toast\." src/ui/ --include="*.ts" --include="*.tsx"
```

Replace `import toast from 'react-hot-toast'` with `import { toast } from 'sonner'`.
Move all toast calls to containers or event handlers. Service hooks must not toast.

Update the toast provider in `_app.tsx` or `Providers.tsx`:
- Remove `<Toaster />` from react-hot-toast
- Add `<Toaster />` from sonner

### 2.8: Delete createQueryFactory/createMutationFactory

After all hooks are extracted:
```bash
rm -rf src/ui/providers/context/utils/api/
```

This deletes: `createQueryFactory/`, `createMutationFactory/`, and ~8 files.

### 2.9: Delete companyData.ts and parallel fetch paths

If UF has a `companyData.ts` or equivalent that provides a second fetch path
alongside fetchApi, delete it. All fetching goes through `useFetchApi`.

### 2.10: Delete usersContext/ provider

Run `/audit-react-feature` on `src/ui/providers/context/usersContext/` first.
Move all data-fetching logic to service hooks (queries/users/, mutations/users/).
Delete:
```
src/ui/providers/context/usersContext/  (8 files)
```

### 2.11: Delete urlClassification/ provider

Run `/audit-react-feature` on `src/ui/providers/context/urlClassification/` first.
Move all data-fetching logic to service hooks.
Delete:
```
src/ui/providers/context/urlClassification/  (7 files)
```

## NGA Commit History Reference

These NGA commits document the same work in the other codebase:
- `ab28cfa1`: Strip InsightsContextProvider, replace with useFilterStore + standalone hooks
- `366c7237`: Remove useInsightsContext from 6 containers, extract useSelectedWorkstreams
- `9838c366`: nuqs URL-first migration for InsightsContext consumers
- `2fae9dca`: Replace manual fetch useEffect with TanStack Query (relay-usage)
- `006126a6`: Eliminate all raw localStorage/sessionStorage access (typedStorage)
- `860603cd`: Extract inline useQuery from OpportunitiesV2Block

## Also Do During This Phase

- **nuqs URL-first migration**: Move filter state from localStorage/sessionStorage
  to URL params using nuqs. This was a major win in NGA -- deep linking, back-button
  navigation, no stale-state bugs.
- **typedStorage enforcement**: Replace all raw `localStorage.getItem`/`setItem`
  calls with `readStorage`/`writeStorage` from typedStorage.
- **selectedUser to URL**: Move user selection state to URL params.
