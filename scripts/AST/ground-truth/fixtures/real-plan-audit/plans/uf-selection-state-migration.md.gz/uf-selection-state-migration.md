# Selection State Migration Master Plan

> Eliminate all selection-related context state in user-frontend. Move flyout
> coordination, InsightsContext selection, and InsightsContext filters to either
> container-local state or URL params (nuqs). Delete InsightsContext entirely.
>
> Created: 2026-03-03.
> Prerequisite: 8.11 complete. All non-flyout/selection exceptions eliminated.

---

## Goal

Delete these contexts entirely:
- `FlyoutContext` (flyoutOpen boolean)
- `UsersContext` (selectedUser: User)
- `UrlsClassificationContext` (selectedHost: ClassificationUrlItem)
- `InsightsContext` (18 fields: 11 selection + 7 filter/UI)

After this work, zero shared context holds selection or filter state.
Containers own their own state, backed by URL params via nuqs.

---

## Prompt Sequence (9 prompts, run sequentially)

| # | Prompt | What It Does | Effort |
|---|--------|-------------|--------|
| 1 | Flyout Coordination Elimination | **DONE** (2026-03-03). 3 commits. FlyoutContext, UsersContext, UrlsClassificationContext deleted. | 1 session |
| 2 | InsightsContext Selection Extraction | **DONE** (2026-03-03). 1 commit. 19 files changed. InsightsContext reduced to 7 fields. | 1 session |
| 3 | Systems Domain URL Migration | **DONE** (2026-03-03). 1 commit. usePagesStateReducer deleted. 4 URL params (sys, pg, sysUser, sysView). | 1 session |
| 4 | Productivity selectedUser URL Migration | **DONE** (2026-03-03). 1 commit. useState -> useQueryState(prodUser). useMaintainSelection removed. | 1 session |
| 5 | Workstream Analysis selectedWorkstreams URL Migration | **DONE** (2026-03-03). 1 commit. useState -> useQueryState(selWs, parseAsArrayOf). Data-driven reset. | 1 session |
| 6 | Opportunities Domain URL Migration | **DONE** (2026-03-03). 1 commit. useState -> useQueryState(mwf, mwfUser). azWs added for Prompt 7. Cascade mwf->mwfUser. | 1 session |
| 7 | Analyzer Domain URL Migration | **DONE** (2026-03-03). 1 commit. useState -> useQueryState(azWs). Auto-select adapted to nuqs. workstream_value as key. | 1 session |
| 8 | InsightsContext Filter Elimination | **DONE** (2026-03-03). 1 commit. 40 files changed. InsightsContext emptied to `{}`. All 10 data containers + 4 filter containers switched to nuqs. startTime/endTime computed by filter containers. isHours + chromeFiltered added to URL params. | 1 session |
| 9 | Cleanup + InsightsContext Deletion | **DONE** (2026-03-03). 3 commits (`1a769839`..`e45c69d2`). InsightsContext deleted. Utilities relocated to shared/. Mock infrastructure removed from 23 spec files. Dead code deleted. CLAUDE.md updated. | 1 session |
| | **Total** | | **~13-18 sessions** |

---

## Cleanup Accumulation Protocol

Each prompt instructs the agent to:

1. Append discovered issues to `~/plans/selection-migration-cleanup.md`
2. Format: `## Prompt N: [title]\n- [ ] item description\n`
3. If an issue BLOCKS the next prompt, the agent updates the next prompt
   file and notes what changed at the top
4. If an issue is non-blocking, it goes in the cleanup file for Prompt 9

The cleanup file is created empty by Prompt 1. Each subsequent prompt
appends to it. Prompt 9 reads the full file and addresses everything.

---

## Dependency Graph

```
Prompt 1 (flyout)          Prompt 2 (selection extraction)
    |                           |
    v                           v
 [FlyoutContext gone]      [Selection in container useState]
 [UsersContext gone]            |
 [UrlsClassificationCtx gone]  +---> Prompts 3-7 (URL migration per domain)
                                |         |
                                |         v
                                |    [Selection in nuqs URL params]
                                |
                                +---> Prompt 8 (filter elimination)
                                          |
                                          v
                                     [Filters read from nuqs directly]
                                          |
                                          v
                                     Prompt 9 (cleanup + delete InsightsContext)
```

Prompts 1 and 2 are independent (can run in either order).
Prompts 3-7 require Prompt 2 complete. They are independent of each other.
Prompt 8 requires Prompt 2 complete. Independent of 3-7.
Prompt 9 requires all of 1-8 complete.

Recommended order: 1, 2, 3, 4, 5, 6, 7, 8, 9 (sequential as listed).

---

## Key Architectural Decisions

1. **No nuqs for flyout state (Prompt 1).** Flyout open/close is transient
   modal state. It stays as container-local useState. Flyout coordination
   is eliminated by lifting state to containers, not by URL-backing.

2. **Container-local useState first, then nuqs (Prompts 2, then 3-7).**
   Selection state moves from InsightsContext to container useState in
   Prompt 2. Then each domain prompt (3-7) converts that useState to
   useQueryState (nuqs). Two-step migration reduces risk.

3. **Data containers switch read source (Prompt 8).** Currently data
   containers read `InsightsContext.filters` (shadow copy). After Prompt 8
   they read nuqs URL params directly via `useQueryStates`. Filter
   containers stop writing to InsightsContext.

4. **isHours and isOutOfChromeFiltered move to URL params (Prompt 8).**
   These are display toggles that benefit from URL persistence (user
   expects their hours/days preference to survive refresh). Small addition
   to url-params.ts.

5. **InsightsContext deleted entirely (Prompt 9).** No filter state, no
   selection state, no UI toggles. The provider is removed from
   Providers.tsx. All consumers read from nuqs or own their state locally.

6. **Selection param names are short but readable.** Convention: `sys`,
   `pg`, `sysUser`, `prodUser`, `selWs`, `mwf`, `mwfUser`, `azWs`.
   Consistent with existing flat naming (no domain prefix).

---

## Orchestrator Protocol

This migration is managed by an **orchestrator agent** that runs in a
long-lived conversation with the user. The orchestrator does NOT write
code. It coordinates work agents, verifies their output, and maintains
the prompt sequence.

### Orchestrator Role

The orchestrator:
1. Presents the next prompt to the user
2. Receives the work agent's reconciliation output (pasted by the user)
3. Runs its own verification in the repo (always -- never trusts reported output)
4. Reviews the cleanup file for new items
5. Updates subsequent prompts if the work agent flagged blocking changes
6. Presents the next prompt or reports issues

### Orchestrator Startup

When starting the orchestrator conversation, use this prompt:

```
You are the orchestrator for the user-frontend selection state migration.

Read these files before doing anything:
- ~/plans/uf-selection-state-migration.md (this file -- the master plan)
- ~/plans/selection-migration-cleanup.md (accumulated cleanup items)
- ~/github/user-frontend/CLAUDE.md

Your job:
1. Track which prompt we are on (check git log + cleanup file to determine)
2. When I say "ready", give me the contents of the next prompt file to
   run with a work agent
3. When I paste a work agent's reconciliation output, ALWAYS run these
   verification commands yourself in ~/github/user-frontend:

   git log --oneline -10
   pnpm tsc --noEmit
   pnpm test --run 2>&1 | tail -5
   pnpm build 2>&1 | tail -5
   npx eslint . --max-warnings 0 2>&1 | tail -3

   Plus the prompt-specific context elimination greps.

4. Compare your verification results against the work agent's reported results
5. Read ~/plans/selection-migration-cleanup.md for new items from the work agent
6. If the work agent flagged changes to subsequent prompts, read those
   prompt files and verify the changes make sense
7. Report: PASS (give me the next prompt) or FAIL (list discrepancies)
8. If PASS, update ~/plans/uf-selection-state-migration.md with the
   completed prompt status, HEAD, and any notes
9. Give me the next prompt to run

Never write production code. Only read files, run verification commands,
and update plan/prompt files.
```

### Orchestrator Loop (per prompt)

```
Step 1: User says "ready"
Step 2: Orchestrator reads the next prompt file, gives it to user
Step 3: User runs prompt with a work agent in a separate conversation
Step 4: User pastes the work agent's reconciliation output back
Step 5: Orchestrator runs verification commands (ALWAYS, no exceptions)
Step 6: Orchestrator reads cleanup file for new items
Step 7: Orchestrator checks if work agent modified any subsequent prompts
Step 8: If verification passes:
          - Update master plan with prompt status + HEAD
          - Tell user "Prompt N PASS. Ready for Prompt N+1."
        If verification fails:
          - List all discrepancies
          - Recommend: re-run work agent with fixes, or manual fix
Step 9: Repeat from Step 1
```

### What the Orchestrator Checks (per prompt)

| Check | How |
|-------|-----|
| tsc clean | `pnpm tsc --noEmit` returns 0 |
| Tests pass | `pnpm test --run` shows same or higher count, 0 failures |
| Build passes | `pnpm build` exits 0 |
| ESLint clean | `npx eslint . --max-warnings 0` exits 0 |
| Context elimination | Prompt-specific grep commands return expected counts |
| Cleanup file updated | Work agent appended to `selection-migration-cleanup.md` |
| Plan files updated | Work agent updated MEMORY.md, CLAUDE.md as needed |
| No regressions | Test count >= previous prompt's count |
| Commits match | git log shows expected commits from the prompt |

### Work Agent Reconciliation Format

Each work prompt instructs the agent to return a standardized block:

```
=== RECONCILIATION: Prompt N ===
HEAD: <sha>
Commits: <count> (<sha>..<sha>)
tsc: <0 errors | N errors>
Tests: <N specs, M passed, K todo>
Build: <clean | failed>
ESLint: <clean | N errors, M warnings>

Context Elimination:
  useFlyoutContext: <N non-spec refs>
  useUsers: <N non-spec refs>
  useUrlsClassification: <N non-spec refs>
  useInsightsContext: <N non-spec refs>

Cleanup Items Added: <N items>
Subsequent Prompts Modified: <none | list>
Deviations: <none | list>
Work Left Undone: <none | list>
=== END RECONCILIATION ===
```

---

## NOT in Scope

- BPO/Project structural duplication (backlog)
- 8.7-8.8 browser bug bash (blocked on Firebase emulator, PR blocker)
- Phase 7 Sessions 7-9 (spec rewrites, coverage gaps)
- Production bugs (mapAvgLatencyByHost, mapOperationalHours)
- Any work outside the selection/filter state migration
