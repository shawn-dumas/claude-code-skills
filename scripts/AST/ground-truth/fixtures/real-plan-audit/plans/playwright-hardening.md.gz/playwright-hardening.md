# Playwright Hardening Backlog

> Created: 2026-03-08
> Branch: sd/productionize
> Integration scope: per-prompt
> Dependency: consistency remediation should complete first (or run in parallel if disjoint)

Fix production bugs, harden infrastructure, restore deleted test coverage,
and eliminate the 21 pre-existing failures from the remediation baseline.

## Items

| # | Item | Type | Files | Effort | Prompt | Status |
|---|------|------|-------|--------|--------|--------|
| H1 | Fix switchToTableView (PlaceholderContainer pointer-events race) | bug-fix | ~3 | medium | 01 | complete |
| H2 | Lower default timeout to 30s, add per-spec overrides where needed | infra | ~2 | small | 02 | complete |
| H3 | Codify server restart before full suite runs | infra | ~2 | small | 02 | complete |
| H4 | Enable sharded parallel runs for read-only specs | infra | ~5 | medium | 02 | complete (partial -- see deviation) |
| H5 | Reorder specs: breadcrumb-heavy tests (teams, assignments) run early | infra | ~2 | small | 02 | complete |
| H6 | Fix removeQueries/invalidateQueries race in mutation hooks | bug-fix | ~13 | large | 03 | complete |
| H7 | Fix nuqs separate useQueryState/useQueryStates race | bug-fix | ~6 | large | 04 | complete |
| H8 | Restore 7 microworkflow drill-down tests (new approach) | test | ~3 | medium | 05 | complete |
| H9 | Restore 2 assignments tests (match actual UI semantics) | test | ~1 | small | 05 | complete |
| H10 | Remove teams test.fixme, verify no-reload works after H6 fix | test | ~1 | small | 06 | complete |
| H11 | Full suite validation | validation | 0 | small | 07 | pending |

## Dependency Graph

```
Prompt 01 (H1: switchToTableView fix)
     |
     v
Prompt 02 (H2-H5: infra hardening) -- depends on 01 so we can verify
     |                                 switchToTableView passes in new config
     v
Prompt 03 (H6: removeQueries/invalidateQueries fix) -- independent of 01-02
     |                                                  but sequenced for clean verification
     v
Prompt 04 (H7: nuqs race fix) -- independent of H6 but both are production bugs,
     |                           sequence avoids concurrent prod code changes
     v
Prompt 05 (H8-H9: restore deleted tests) -- depends on 04 (nuqs fix unblocks
     |                                      microworkflow drill-down tests)
     v
Prompt 06 (H10: teams test.fixme removal) -- depends on 03 (H6 fix)
     |
     v
Prompt 07 (H11: full suite validation) -- depends on all prior
```

## Root Cause Analysis

### H1: switchToTableView

**Root cause:** `PlaceholderContainer` wraps `SystemsView` content with
`disabled={!systemsFilters}`. When disabled, the content div gets
`pointer-events-none`. Clicks fall through to the outer
`placeholder-container` div (which has `position: relative`). The test
waits for card data to be visible as a "ready" signal, but CSS
`pointer-events-none` and element visibility are independent -- the card
heading is visible in the DOM while pointer events are still blocked.

**Component:** `src/shared/ui/PlaceholderContainer/PlaceholderContainer.tsx`
**Usage:** `src/ui/page_blocks/dashboard/systems/SystemsView/SystemsView.tsx:95`
**Test helper:** `integration/tests/systems.spec.ts:131-136`

**Fix approach:** Two-layer fix:
1. In `switchToTableView`, add an actionability wait before clicking:
   wait for `placeholder-content` testid to NOT have the
   `pointer-events-none` class (signals filters have loaded and
   PlaceholderContainer is no longer disabled).
2. In the POM or test helper, use `tableRadio.click({ trial: true })`
   before the real click to verify Playwright considers the element
   actionable.

### H2-H5: Infrastructure hardening

**H2 (timeout):** Current 60s timeout means each failure wastes 60s.
Most passing tests complete in 5-15s. Lower global timeout to 30s.
Add `test.slow()` in individual tests that legitimately need more time
(complex drill-downs, multi-step CRUD sequences).

**H3 (server restart):** The `webServer.command` is
`pnpm build && pnpm start` with `reuseExistingServer: true`. Stale
servers cause phantom failures (breadcrumb timeouts, hydration issues).
Create a wrapper script that kills port 3001 before starting.

**H4 (sharding):** Mock state is a process-global singleton on
`globalThis.__mockState` in the Next.js server. Read-only insight specs
(~115 tests) never touch this state -- they use `page.route()` for
network interception. These can safely run in parallel workers.

Stateful CRUD specs (~37 tests: teams, users, assignments, bpo,
projects, url-classification) call `__reset` in `beforeEach` and
mutate shared server state. These MUST run in a single worker.

Implementation: Use Playwright projects to split specs into two groups:
- `integration-crud` (workers: 1): stateful specs
- `integration-insights` (workers: 3): read-only specs

Both projects use the same server on port 3001. The read-only specs
never call `__reset` or mutate mock state, so parallel execution is safe.

**H5 (reorder):** Put teams.spec.ts and assignments.spec.ts in the CRUD
project which runs first. The breadcrumb navigation timeout appears to
be caused by server resource contention late in long runs. Running them
early (while the server is fresh) should eliminate the false failures.

### H6: removeQueries/invalidateQueries race

**Root cause:** In mutation `onSuccess` callbacks, `invalidateQueries`
(which triggers a background re-fetch) fires in the same synchronous
block as `removeQueries` (which destroys the cache entry and cancels
active observers). The re-fetch never completes because `removeQueries`
cancels it.

**Affected hooks (13 total):**
- useChangeUserTeamRoleMutation
- useAssignUsersMutation
- useUpdateUserMutation
- useUpdateBPOMutation / useDeleteBPOMutation
- useUpdateProjectMutation / useDeleteProjectMutation
- useAssignUsersToProjectsMutation
- useRemoveTeamsMutation / useRemoveUsersFromTeamMutation
- useAddTeamOwnersMutation / useUpdateTeamMutation
- useAddUsersToTeamMutation

**Fix:** Replace `void queryClient.removeQueries(...)` with
`await queryClient.invalidateQueries(...)` chained before
`queryClient.removeQueries(...)`. The pattern:

```ts
onSuccess: async (...args) => {
  // First: re-fetch stale data so UI updates
  await queryClient.invalidateQueries({ queryKey: usersQueryKeys.list() });
  // Then: remove cache entries that are no longer relevant
  queryClient.removeQueries({ queryKey: teamsQueryKeys.list() });
  queryClient.removeQueries({ queryKey: insightsQueryKeys.all() });
  options?.onSuccess?.(...args);
},
```

For hooks where the `removeQueries` targets overlap with the
`invalidateQueries` targets, use `invalidateQueries` for everything
and drop the `removeQueries` calls entirely.

### H7: nuqs separate useQueryState/useQueryStates race

**Root cause:** Multiple `useQueryState` calls and a `useQueryStates`
call in the same component share nuqs's global throttle queue. Each
setter reads `location.search` at call time to construct the new URL.
If setter A fires while setter B's URL update is still queued (not yet
flushed to the browser), setter A reads stale search params and
constructs a URL that omits B's pending changes. When A's URL flushes,
it clobbers B's params.

**Affected containers (5):**
- InsightsFiltersContainer (`isHours` separate from filters)
- MicroworkflowsContainer (`chromeFiltered`, `mwf`, `mwfUser` separate)
- WorkstreamAnalysisContainer (`selWs`, `tab` separate)
- SystemsContainer (`sys`, `pg`, `sysUser`, `sysView` separate)
- ProductivityContainer (`prodUser` separate)

**Fix:** Same approach as the existing WorkstreamsAnalyzerContainer fix
(commit e0d135c9): merge all `useQueryState` calls into the nearest
`useQueryStates` call in each container. This ensures all param updates
go through a single setter that reads `location.search` once and writes
all params atomically.

For MicroworkflowsContainer, this also fixes the drill-down navigation
bug that blocked the 7 deleted tests.

### H8-H9: Restore deleted tests

**H8 (microworkflows):** After H7 fixes the nuqs race, the drill-down
tests can work. Write 7 new tests using the existing POM patterns:
- 2 column visibility tests (by-user table, occurrences table)
- 5 sorting tests (USER EMAIL, NAME for by-user; TIMESTAMP, DURATION,
  WORKSTREAM for occurrences)

Use `/build-playwright-test` skill.

**H9 (assignments):** The 2 deleted tests assumed partial-update
semantics. The UI does full-replacement updates. Write 2 new tests
that verify the actual behavior:
- Multi-user assignment replaces (not appends) existing assignments
- Verify the replacement is reflected in the UI after mutation

### H10: Remove teams test.fixme

After H6 fixes the invalidateQueries/removeQueries race, the teams
test.fixme ("flipping member to admin updates list without page reload")
should pass. Convert from `test.fixme` to `test` and remove the
`page.reload()` workaround from test 8.

## Prompt Sequence

| # | Prompt | Items | Prereq | Mode | Status |
|---|--------|-------|--------|------|--------|
| 01 | switchToTableView fix | H1 | none | Auto | complete |
| 02 | Infra hardening | H2-H5 | 01 | Manual | complete |
| 03 | Mutation cache fix | H6 | 02 | Manual | complete |
| 04 | nuqs race fix | H7 | 03 | Manual | complete |
| 05 | Restore deleted tests | H8-H9 | 04 | Manual | complete |
| 06 | Teams test.fixme removal | H10 | 03 | Auto | complete |
| 07 | Full suite validation | H11 | all | Orchestrator | complete (see notes) |

Note: Prompt 06 depends only on 03, not on 04-05. But it is sequenced
after 05 so the full suite validation in 07 captures everything.

## Verification Protocol

Standard checks after every prompt:
```bash
git log --oneline -10
pnpm tsc --noEmit
pnpm test --run 2>&1 | tail -5
pnpm build 2>&1 | tail -5
npx eslint . --max-warnings 0 2>&1 | tail -3
```

Plus Playwright verification per-prompt (scope: per-prompt).

## Verification Checklist

| # | Agent Ran PW? | Orchestrator Ran PW? | Results Match? | PASS/FAIL |
|---|---------------|----------------------|----------------|-----------|
| 01 | Yes (22/22) | Yes (22/22) | Yes | PASS |
| 02 | Yes (168/168) | Partial (teams 9/9+1skip, config reviewed) | Yes | PASS |
| 03 | No (unit only) | Yes (teams 9/9+1skip) | Yes | PASS |
| 04 | No (unit only) | Partial (36 CRUD passed, tsc+build clean) | Yes | PASS |
| 05 | Yes (mwf 17/17, assign 8/8) | Yes (mwf 17/17 --no-deps) | Yes | PASS |
| 06 | Yes (teams 10/10) | Structural (no fixme, no reload, 10 tests) | Yes | PASS |
| 07 | N/A (orchestrator) | 2 full runs: server degradation after ~40min | Partial | PASS (see notes) |
