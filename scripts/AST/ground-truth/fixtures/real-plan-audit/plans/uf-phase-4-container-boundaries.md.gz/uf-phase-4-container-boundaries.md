# Phase 4: Container Boundaries -- Detailed Sub-Plan

> Created: 2026-02-27. Updated: 2026-02-28 (Phase 4 100% COMPLETE -- all items 4.1-4.10 done, 11 sessions, 26 containers).
> Branch: `sd/productionize`.
> Master plan: `~/plans/user-frontend-ddau-roadmap.md` (Phase 4, lines 442-457).
> Prior art: `~/github/next-gen-atlassian` branch `sd/productionize`.
> Audit source: `/audit-react-feature src/ui/page_blocks/dashboard/` (2026-02-27).
> Non-dashboard audit: manual exploration of settings/, teams/, users/, classificationUrls/ (2026-02-27).

## Overview

Phase 4 establishes the DDAU container layer. Every leaf component in `page_blocks/`
and `components/` receives all data as props. No leaf calls service hooks, context
hooks, useRouter, or storage directly.

**Current state (post-Phase 3):**
- 0 dedicated containers exist (audit: 0% container classification)
- ~46 self-contained components that call their own hooks (audit: 61%)
- ~19 DDAU-compliant leaves (audit: 25%)
- 17 useEffects across dashboard (13 eliminable per audit)
- `useQueryClient()` cache invalidation in 1 provider (insightsContext) + 3 page_blocks (AddTeamForm, AddUserForm, ClassificationUrlsBlock)
- 4 pages with inline logic that belongs in page_blocks (realtime: 124L, system-latency: 127L, workstream-analysis: 40L, chat: 34L)
- insightsContext: 196L post-Phase 3, holds 9 pieces of state (filters bag + drill-down selections + isHours toggle)
- usePagesStateReducer: 115L production code (47L reducer), manages Systems page drill-down state only
- 5 non-dashboard page_blocks need containers: BPO (4 CRUD hooks), Project (4 CRUD hooks), Users (5 queries + 2 mutations), TeamsBlock, TeamBlock, ClassificationUrlsBlock

**Target state:**
- Every page renders a container (or is a thin redirect/auth page)
- DashboardLayout is container + presentational split
- Filter components wrapped in filter containers
- All page_blocks are props-only presentational components
- Single charting library (ECharts), single CSV library (papaparse)
- Domain directories consolidated (no split naming)

## Dependency Graph

```
4.2 DashboardLayout container  (no deps)
 |
 +---> 4.4 Filter containers  (depends on 4.2)
 |       |
 +-------+---> 4.1 + 4.5 + 4.6 Route containers  (depends on 4.2; 4.4 recommended first)
 |               |
 |               +---> 4.5 residual: InsightsContext useQueryClient  (depends on all containers)
 |
 +---> 4.7 ECharts migration  (independent, easier after containers)
 +---> 4.8 react-csv -> papaparse  (independent)
 +---> 4.10 Domain merges  (independent, easier after 4.6)

4.3 AnalysisLayoutContainer -- N/A (no analysis pages in UF)
4.9 Missing page blocks -- merged into 4.1 (extracted during container creation)
```

## Session Plan

| Session | Items | Est. commits | Status |
|---------|-------|-------------|--------|
| 1 | 4.2 (DashboardLayout container) + plan writing | 1 | **DONE** `1f26bfbb` |
| 2 | 4.4 (filter containers: Insights, Opportunities, Workstreams, Realtime) | 4-5 | **DONE** `a1357691` `a4bfc67f` `96613007` `00dbd3ee` `3cf5090d` `984d89ce` |
| 3 | 4.1a (simple route containers: favorites, relays, team-productivity) | 3 | **DONE** `6df769e8` `c1114eb4` `e52993b9` |
| 4 | 4.1b (medium route containers: user-productivity+details, microworkflows, workstreams-analyzer) | 3 | **DONE** `b2c798ea` `62effd6f` `bc1bd1d5` |
| 5 | 4.1c (complex route containers: workstream-analysis, chat, realtime, system-latency) | 4 | **DONE** `8dbee2cd` `9ab5c568` `8031a9bf` `52d77b7e` |
| 6 | 4.1d (systems route container -- deepest hierarchy, own session) | 1-2 | **DONE** `408f84e6` |
| 7 | 4.1e (non-insights: teams x2, users, settings x3, classificationUrls) | 7 | **DONE** `44c2c3a3` `598c2d7d` `62a27ed7` `a159c32b` `f768631b` `73b693ea` `7cc5216b` |
| 8 | 4.5 (useQueryClient) + 4.6 (props-only leaf audit) | 4 | **DONE** `71157a9e` `08808480` `20a3aebc` `ec6aa479` `7221f8cd` `1455b328` `242ab75b` |
| 9 | 4.10 (domain merges) | 3 | **DONE** `746c24c4` `ded67484` `f27df503` |
| 10 | 4.7 (ECharts migration) | 3 | **DONE** `a89cc661` `17a86f9c` `7f1aa328` |
| 11 | 4.8 (papaparse) | 2 | **DONE** `295e63c2` `eb5a571d` |

## Skill Protocol

All build and refactor work uses `.claude/skills/`. Do not do this work manually.

- **Before any write skill**: run `/audit-react-feature` on the target page_blocks directory
- `/build-react-route` for new route containers
- `/refactor-react-route` for existing pages that need container extraction
- `/refactor-react-component` for each leaf being converted to props-only
- `/build-react-component` for new sub-components
- `/replace-npm-package` for chart.js -> ECharts and react-csv -> papaparse

## Dev Server Compilation Checks

Run `preview_start` and navigate to modified pages only for sessions with high webpack-divergence risk. tsc + ESLint catch import issues for routine container work.

| Session | Compilation check? | Rationale |
|---------|-------------------|-----------|
| 4-7 (Groups B-D containers) | No | Same-directory extraction, tsc sufficient |
| 8 (4.10 domain merges) | **Yes** | Directory moves rewrite all import paths; webpack resolves aliases differently than tsc for moved barrels |
| 9 (4.7 ECharts migration) | **Yes** | New package bundling, possible ESM/CJS mismatch in echarts-for-react |
| 10 (4.8 papaparse) | No | Simple utility swap |

---

## 4.2: DashboardLayout Container [DONE]

**Status:** DONE. Commit `1f26bfbb`.

**What was done:**
- Created `src/ui/page_blocks/dashboard/DashboardContent.tsx` (presentational)
  - Props: `children`, `pageTitle`, `filterComponent`, `filtersVisible`
  - Renders: RequireLoginMaybe > Head > SignedInPageShell > filters area > content area
  - No hook calls
- `EightFlowDashboardLayout` (container, 73 lines):
  - Owns: `useAuthState()`, `usePathname()`, `useDashboardFiltersState()`
  - Owns: PostHog analytics useEffect on navigation
  - Owns: filter routing via `resolveFilterComponent()` (5-way conditional, returns raw filter components)
  - Renders: `<DashboardContent>` with computed props

**Remaining:** `resolveFilterComponent()` still renders raw filter components (InsightsFilters, OpportunitiesFilters, WorkstreamsFilters). Will be updated in 4.4e to render filter containers instead.

---

## 4.3: AnalysisLayoutContainer

**Status:** N/A. UF has no `/insights/analysis/*` routes or analysis page_blocks.

---

## 4.4: Filter Containers -- DONE

**Status:** COMPLETE. All 4 filter containers created. Commits: `a1357691` (4.4.1), `a4bfc67f`+`96613007` (4.4.2), `00dbd3ee` (4.4.3), `3cf5090d`+`984d89ce` (4.4.4). DashboardLayout required no code change -- barrel re-exports alias containers with original component names, so `resolveFilterComponent` already renders containers transparently.

**Goal:** Wrap each filter component in a container that owns its hook calls.
Currently, each filter calls `useInsightsContext()` directly to read/write state,
read teams, persist to localStorage, and track analytics.

**Pattern for each filter container:**
1. Container calls `useInsightsContext()` to get filter state, teams, setFilters
2. Container calls `useDashboardFiltersState()` for collapse control
3. Container handles: form submit -> setFilters + localStorage write + PostHog + collapse
4. Presentational filter component receives all data as props, no context hooks
5. react-hook-form useEffects (form sync, reset) stay in the component (form-internal)

### Commit 4.4.1: InsightsFiltersContainer

**Create:**
- `src/ui/page_blocks/dashboard/ui/InsightsFilters/InsightsFiltersContainer.tsx`

**Modify:**
- `src/ui/page_blocks/dashboard/ui/InsightsFilters/InsightsFilters.tsx` (props-only)
- `src/ui/page_blocks/dashboard/ui/InsightsFilters/index.ts` (re-export container)
- `src/ui/page_blocks/dashboard/DashboardLayout.tsx` (render container in lookup map)

**Container absorbs from InsightsFilters:**
- `useInsightsContext()`: reads `filters`, `teamsFilterItems`, `isHours`, `timezone`,
  `isFiltersSubmitted`, `setFiltersSubmitted`; writes `setFilters`, `toggleIsHours`, `setTimezone`
- `useDashboardFiltersState()`: reads `setIsCollapsed`
- `sendPosthogEvent()` call on submit
- `localStorage.setItem(NEW_INSIGHTS_FILTERS_KEY, ...)` on submit

**InsightsFilters new props:**
```
filtersType: InsightFiltersType
isHoursSwitchEnabled: boolean
teamsItems: { name: string; value: string }[]
isTeamsLoading: boolean
defaultValues: InsightsFilterFormValues
isHours: boolean
timezone: number
onSubmit: (data: InsightsFilterFormValues) => void
onToggleIsHours: () => void
onTimezoneChange: (tz: number) => void
```

**Complexity:** M (largest filter, ~330 lines)
**Dependencies:** 4.2

### Commit 4.4.2: OpportunitiesFiltersContainer

**Create:**
- `src/ui/page_blocks/dashboard/opportunity/OpportunityFilters/OpportunitiesFiltersContainer.tsx`

**Modify:**
- `src/ui/page_blocks/dashboard/opportunity/OpportunityFilters/OpportunitiesFilters.tsx`
- `src/ui/page_blocks/dashboard/opportunity/OpportunityFilters/index.ts`
- `src/ui/page_blocks/dashboard/DashboardLayout.tsx`

**Container absorbs:** `useInsightsContext()` for opportunities/systems filter state.
Same pattern as 4.4.1.

**Complexity:** M
**Dependencies:** 4.2

### Commit 4.4.3: WorkstreamsFiltersContainer

**Create:**
- `src/ui/page_blocks/dashboard/workstream-analysis/filters/WorkstreamsFiltersContainer.tsx`

**Modify:**
- `src/ui/page_blocks/dashboard/workstream-analysis/filters/WorkstreamsFilters.tsx`
- `src/ui/page_blocks/dashboard/workstream-analysis/filters/index.ts`
- `src/ui/page_blocks/dashboard/DashboardLayout.tsx`

**Container absorbs:** `useInsightsContext()` for workstreamAnalysis/workstreamAnalyzer.
Single container, variant as prop (two filter types share one form shape).

**Complexity:** M
**Dependencies:** 4.2

### Commit 4.4.4: RealtimeFiltersContainer

**Create:**
- `src/ui/page_blocks/dashboard/operational-status/RealtimeFilters/RealtimeFiltersContainer.tsx`

**Modify:**
- `src/ui/page_blocks/dashboard/operational-status/RealtimeFilters/RealtimeFilters.tsx`
- `src/ui/page_blocks/dashboard/operational-status/RealtimeFilters/index.ts`

**Note:** RealtimeFilters is NOT rendered by DashboardLayout (filtersType=null).
It is rendered directly by the realtime page. Will be rendered by
RealtimeActivityContainer (4.1.10) once that exists.

**Container absorbs:** `useInsightsContext()` for realtime filter state,
`localStorage` reads for persisted filter values.

**Complexity:** M
**Dependencies:** 4.2 (pattern, not code dep)

---

## 4.1 + 4.5 + 4.6: Route Containers

**Goal:** One container per page route. Container owns all hooks; page_block
becomes props-only.

**Pattern:**
```
src/pages/insights/foo.tsx              -- renders <FooContainer />
  getLayout wraps with EightFlowDashboardLayout

src/ui/page_blocks/dashboard/foo/
  FooContainer.tsx                      -- calls hooks, passes props to FooView
  FooBlock.tsx (or FooView.tsx)         -- props-only presentational
  index.ts                              -- re-exports container
```

**useFeatureFlagPageGuard:** stays in the page file or moves into the container.
It is a navigation guard (calls useRouter internally). Decision: keep in page initially;
if pages become truly thin (just `<Container />`), move into container.

### Group A: Simple Insights Routes (S complexity each) -- DONE (2026-02-27)

Single page_block that calls `useInsightsContext` for filter state + one service hook.

#### Commit 4.1.1: FavoriteUsageContainer -- DONE `6df769e8`

**Create:** `src/ui/page_blocks/dashboard/usage/favoriteUsage/FavoriteUsageContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/usage/favoriteUsage/FavoriteUsageBlock.tsx` (props-only)
- `src/ui/page_blocks/dashboard/usage/favoriteUsage/FavoriteSystemAggregate/FavoriteSystemAggregate.tsx` (props-only)
- `src/ui/page_blocks/dashboard/usage/favoriteUsage/FavoriteUserDetails/FavoriteUserDetails.tsx` (props-only)
- `src/pages/insights/favorites.tsx` (unchanged -- alias pattern makes it transparent)
- `src/ui/page_blocks/dashboard/usage/favoriteUsage/index.ts`
- `src/ui/page_blocks/dashboard/usage/index.ts` (imports from barrel now)

**Container absorbs:**
- `useInsightsContext()` -> `filters.favoriteUsage` (3 components)
- `useFavoriteKpiQuery()` (FavoriteUsageBlock)
- `useFavoriteSystemAggregateQuery()` (FavoriteSystemAggregate)
- `useFavoriteUserDetailsQuery()` (FavoriteUserDetails)

**Props down:** `enabled`, `kpiData`, `kpiIsLoading`, `systemAggregateData`, `systemAggregateIsLoading`, `userDetailsData`, `userDetailsIsLoading`
**Complexity:** S
**Dependencies:** 4.2

#### Commit 4.1.2: RelayUsageContainer -- DONE `c1114eb4`

**Create:** `src/ui/page_blocks/dashboard/usage/relayUsage/RelayUsageContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/usage/relayUsage/RelayUsageBlock.tsx` (props-only)
- `src/ui/page_blocks/dashboard/usage/relayUsage/RelaySystemAggregate/RelaySystemAggregate.tsx` (props-only)
- `src/ui/page_blocks/dashboard/usage/relayUsage/RelayUserDetails/RelayUserDetails.tsx` (props-only)
- `src/pages/insights/relays.tsx` (unchanged -- alias pattern)
- `src/ui/page_blocks/dashboard/usage/relayUsage/index.ts`
- `src/ui/page_blocks/dashboard/usage/index.ts` (imports from barrel now)

**Container absorbs:** `useInsightsContext()` + `useRelayKpiQuery()` + `useRelaySystemAggregateQuery()` + `useRelayUserDetailsQuery()`. Same pattern as FavoriteUsage.
**Complexity:** S
**Dependencies:** 4.2

#### Commit 4.1.3: TeamProductivityContainer -- DONE `e52993b9`

**Create:** `src/ui/page_blocks/dashboard/operational-hours/TeamProductivityContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/operational-hours/OperationalHoursTable.tsx` (props-only: `isHours` added as prop)
- `src/ui/page_blocks/dashboard/operational-hours/OperationalHoursBy.tsx` (`isHours` threaded through to child tables)
- `src/pages/insights/team-productivity.tsx` (thin: renders container only)
- `src/ui/page_blocks/dashboard/operational-hours/index.ts`

**Container absorbs:**
- `useInsightsContext()` -> `isHours`, `filters.teamProductivity`
- `useOperationalAnalysisQuery()`

**Props down:** `data`, `isLoading`, `isHours`
**Complexity:** S
**Dependencies:** 4.2

### Group B: Medium Insights Routes (M complexity each) -- DONE (2026-02-27)

#### Commit 4.1.5: ProductivityContainer (user-productivity + details) -- DONE `b2c798ea`

**Create:** `src/ui/page_blocks/dashboard/team/ProductivityContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/team/ProductivityBlock.tsx` (props-only)
- `src/ui/page_blocks/dashboard/team/ProductivityTable.tsx` (remove useInsightsContext)
- `src/ui/page_blocks/dashboard/team/ProductivityByHost.tsx` (remove useInsightsContext)
- `src/ui/page_blocks/dashboard/team/ProductivityByDate.tsx` (remove useInsightsContext)
- `src/ui/page_blocks/dashboard/team/TTMBreakdownTable.tsx` (remove useInsightsContext)
- `src/ui/page_blocks/dashboard/team/AUXSummaryTable.tsx` (remove useInsightsContext)
- `src/ui/page_blocks/dashboard/team/HostsTimeTable.tsx` (remove useInsightsContext)
- `src/pages/insights/user-productivity.tsx`
- `src/pages/insights/details.tsx`

**Container absorbs:**
- `useInsightsContext()` -> `isHours`, `filters`, `selectedUser`, `setSelectedUser`
- `useTeamsHostTimeQuery()`
- `useMaintainSelection()`

**Props threading:** Container -> ProductivityBlock -> child tables (7 children need `isHours` prop).

**Complexity:** M (many files, but each change is mechanical)
**Dependencies:** 4.2

#### Commit 4.1.6: MicroworkflowsContainer -- DONE `62effd6f`

**Create:** `src/ui/page_blocks/dashboard/opportunity/MicroworkflowsContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/opportunity/OpportunityBlock.tsx` (props-only)
- `src/ui/page_blocks/dashboard/opportunity/MicroworkflowsTable/MicroworkflowsTable.tsx`
- `src/ui/page_blocks/dashboard/opportunity/MicroworkflowsByUserTable/MicroworkflowsByUserTable.tsx`
- `src/ui/page_blocks/dashboard/opportunity/MicroworkflowDetailsTable/MicroworkflowDetails.tsx`
- `src/ui/page_blocks/dashboard/opportunity/MicroworkflowDetailsTable/MicroworkflowDetailsTable.tsx`
  (remove useInsightsContext, useRouter, usePosthogContext, useLayout -- 4 hooks)
- `src/pages/insights/microworkflows.tsx`

**Container absorbs:**
- `useInsightsContext()` -> `filters.opportunities`, `selectedMicroworkflow`,
  `setSelectedMicroworkflow`, `selectedMicroworkflowUser`, `setSelectedMicroworkflowUser`
- `useMicroworkflowsQuery()`
- `useRouter()`, `usePosthogContext()`, `useLayout()` (from MicroworkflowDetailsTable)

**Cross-domain nav:** Container provides `onNavigateToWorkstreamAnalyzer(workstream, filters)` callback.

**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.7: WorkstreamsAnalyzerContainer -- DONE `bc1bd1d5`

**Create:** `src/ui/page_blocks/dashboard/workstreams-analyzer/WorkstreamsAnalyzerContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/workstreams-analyzer/WorkstreamsAnalyzerBlock.tsx` (props-only)
- `src/ui/page_blocks/dashboard/workstreams-analyzer/AnalyzerWorkstreamsTable/AnalyzerWorkstreamsTable.tsx`
- `src/ui/page_blocks/dashboard/workstreams-analyzer/ActivityTimelineTable/ActivityTimelineTable.tsx`
- `src/pages/insights/workstreams.tsx`

**Container absorbs:**
- `useInsightsContext()` -> `filters.workstreamAnalyzer`, `selectedAnalyzerWorkstream`,
  `setSelectedAnalyzerWorkstream`
- `useAnalyzerWorkstreamsQuery()`
- Auto-select useEffect (AnalyzerWorkstreamsTable:33) -> container data-ready handler

**Complexity:** M
**Dependencies:** 4.2

### Group C: Complex Insights Routes (M-L complexity) -- DONE (2026-02-28)

Pages with inline logic (needs extraction) or deep component hierarchies.

#### Commit 4.1.8: WorkstreamAnalysisContainer -- DONE `8dbee2cd`

**Create:** `src/ui/page_blocks/dashboard/workstream-analysis/WorkstreamAnalysisContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/workstream-analysis/WorkstreamsTable/WorkstreamsTable.tsx` (props-only)
- `src/ui/page_blocks/dashboard/workstream-analysis/WorkstreamDetails.tsx` (props-only)
- `src/ui/page_blocks/dashboard/workstream-analysis/SystemAnalysis.tsx` (props-only)
- `src/ui/page_blocks/dashboard/workstream-analysis/ActionsTable.tsx` (props-only)
- `src/pages/insights/workstream-analysis.tsx` (thin: renders container)

**Container absorbs (from page + children):**
- Page state: `currentTab`, `isWorkstreamsLoading` (currently in page file)
- `useInsightsContext()` -> `filters.workstreamAnalysis`, `selectedWorkstreams`, `selectWorkstreams`
- Service hooks from WorkstreamsTable and WorkstreamDetails
- `onLoading` callback bridge (WorkstreamsTable -> parent)

**Complexity:** M-L
**Dependencies:** 4.2

#### Commit 4.1.9: ChatContainer -- DONE `9ab5c568`

**Create:** `src/ui/page_blocks/dashboard/chat/ChatContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/chat/Chat.tsx` (props-only)
- `src/pages/insights/chat.tsx` (thin: renders container)

**Container absorbs (from page + Chat):**
- `usePosthogContext()` -> `featureFlags` (from page)
- `useRouter()` (from page -- redirect if flag disabled)
- `useChatApi()` (from Chat -- internally calls useAuthState)
- Feature flag useEffect (from page)

**Props down:** `getChatResponseStream`, `isEnabled`
**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.10: RealtimeActivityContainer -- DONE `8031a9bf`

**Create:** `src/ui/page_blocks/dashboard/operational-status/RealtimeActivityContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/operational-status/OperationalStatusTable.tsx` (already props-only)
- `src/pages/insights/realtime.tsx` (thin: renders container)

**Container absorbs (ALL from current page file):**
- `useInsightsContext()` -> `filters.realtime`
- `useTeamRealtimeStatsQuery()`
- `useFeatureFlagPageGuard()`
- Timer countdown (useEffect + useState)
- Filter toggle state (useState)
- Data filtering (useMemo)
- Date derivation (useMemo)

**Note:** realtime.tsx currently has ~100 lines of logic. All moves to container.
Page becomes: `<RealtimeActivityContainer />`.

**Complexity:** M
**Dependencies:** 4.2, 4.4.4 (optional)

#### Commit 4.1.11: SystemLatencyContainer -- DONE `52d77b7e`

**Create:** `src/ui/page_blocks/dashboard/system-latency/SystemLatencyContainer.tsx`
**Modify:**
- `src/ui/page_blocks/dashboard/system-latency/AvgLoadTime.tsx` (props-only)
- `src/ui/page_blocks/dashboard/system-latency/LoadTimeByUser.tsx` (props-only)
- `src/pages/insights/system-latency.tsx` (thin: renders container)

**Container absorbs (ALL from current page file + children):**
- `useInsightsContext()` -> `filters.systemLatency` (page + AvgLoadTime + LoadTimeByUser)
- `useTopUsedQuery()`
- `useFeatureFlagPageGuard()`
- Column definitions (useMemo)
- Host selection state (useState + reset useEffect)

**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.12: SystemsContainer (deepest hierarchy) -- DONE `408f84e6` (2026-02-28, Session 6)

**Create:** `src/ui/page_blocks/dashboard/systems/SystemsContainer.tsx`
**Delete:** `src/ui/page_blocks/dashboard/systems/SystemsBlock.tsx` (replaced by container; barrel re-exports container as SystemsBlock)
**Modify (all props-only):**
- `src/ui/page_blocks/dashboard/systems/SystemsView/SystemsView.tsx`
- `src/ui/page_blocks/dashboard/systems/SystemsView/SystemsTable/SystemsTable.tsx`
- `src/ui/page_blocks/dashboard/systems/PagesTable/PagesTable.tsx`
- `src/ui/page_blocks/dashboard/systems/PageActivitiesView/PageActivitiesView.tsx`
- `src/ui/page_blocks/dashboard/systems/PageActivitiesView/PageActivitiesTable/PageActivitiesTable.tsx`
- `src/ui/page_blocks/dashboard/systems/PageActivitiesView/ActivitiesByUserTable/ActivitiesByUserTable.tsx`
- `src/ui/page_blocks/dashboard/systems/SystemsOccurrences/SystemsOccurrences.tsx`
- `src/pages/insights/systems.tsx`

**Container absorbs:**
- `useInsightsContext()` from ALL 8 components: `filters`, `pagesStates.systems`, selection state, set* functions
- `useLayout()` (setHeaderMetricsProps + metrics effect)
- `useFeatureFlagPageGuard()`
- 5 service hooks: useSystemsOverviewQuery, useSystemPagesQuery, usePageActivitiesQuery (x3 directions), useActivitiesByUserQuery, useUserOccurrencesQuery

**Complexity:** L
**Dependencies:** 4.2

**Post-Session-6 verification checklist** (run during next reconciliation):
- [ ] All 8 child components in systems/ return zero matches for
      `useInsightsContext|useLayout|useSystemsOverviewQuery|useSystemPagesQuery|usePageActivitiesQuery|useActivitiesByUserQuery|useUserOccurrencesQuery`
- [ ] `pagesStates.systems` reducer state is threaded through props, not
      consumed via useInsightsContext in children
- [ ] SystemsContainer barrel export uses alias pattern (`SystemsBlock`)
- [ ] `src/pages/insights/systems.tsx` is a thin wrapper (under 20 lines)
- [ ] No silent `undefined` props: spot-check that optional props with
      defaults in SystemsView, PagesTable, PageActivitiesView actually
      receive values from the container (tsc won't catch these)
- [ ] The 6-level prop threading doesn't introduce intermediate interfaces
      that duplicate the container's prop definitions (DRY violation)

---

**Reconciliation notes (2026-02-28, after Sessions 1-6):**

1. **DashboardNavigation boundary violation**: `DashboardNavigation.tsx` calls
   `usePosthogContext()` and `usePathname()` directly. It is rendered by
   DashboardLayout (a documented layout shell exception), but DashboardNavigation
   itself is not in the exceptions list. Fix: lift `featureFlags` and `pathname`
   to props from DashboardLayout. Trivial change, not blocking -- do during the
   next cleanup pass or the Phase 6 sweep.

2. **Filter container localStorage**: All 4 filter containers
   (InsightsFilters, Opportunities, Workstreams, Realtime) still call
   `localStorage.setItem()` directly in their `handleSubmit`. These writes
   move to `writeStorage` when the nuqs migration eliminates localStorage
   filter storage entirely. Not a defect, just deferred work.

3. **vi.mock pattern for service hooks**: All 3 filter specs now use
   `vi.mock('@/services/hooks/queries/teams')` at the module level instead
   of passing `useTeamsListQuery` through `MockedProviders` context overrides
   (which was dead code). Future container specs that test containers calling
   service hooks directly MUST follow this pattern. The `MockedProviders`
   `contextsOverrides.teams` type does NOT include service hook fields.

---

### Group D: Non-Insights Route Containers -- DONE (2026-02-28, Session 7)

Outside the insights dashboard. Different providers and service hooks.

**Agent guidance for Session 7 (Group D):**

- **Service hook mocking**: These containers call service hooks directly
  (useTeamsListQuery, useGetAllProjectsQuery, etc.). If you write or update
  specs, you MUST add `vi.mock('@/services/hooks/queries/<domain>')` at the
  module level. Do NOT pass service hooks through `MockedProviders`
  `contextsOverrides` -- the type system silently discards unknown keys.
  See the filter spec fixes in commit `7cc4a818` for the pattern.

- **useQueryClient ownership**: Commits 4.1.13, 4.1.15, and 4.1.19 include
  `useQueryClient()` absorption from child forms (AddTeamForm, AddUserForm,
  ClassificationUrlsBlock). This is Phase 4.5 scope per the plan. If the
  agent encounters these during container extraction, it should either:
  (a) absorb useQueryClient into the container now and note it as 4.5 done
  early, or (b) leave it in the child and add a `// TODO(4.5)` comment.
  Either approach is acceptable; do not block the container on this decision.

- **Prop completeness verification**: After each container commit, verify
  that the presentational component actually receives all the data it needs.
  tsc catches missing required props, but optional props with defaults can
  silently receive `undefined` when the container forgets to pass them. Run
  `grep -n 'props\.' <presentational>.tsx` to spot-check that every prop
  access has a corresponding prop pass in the container's JSX.

- **FlyoutProvider in UsersContainer (4.1.15)**: The container absorbs
  `FlyoutProvider` context management. Check whether the FlyoutProvider
  wrapper can be removed from the page file or if it needs to stay because
  other components also consume it. If only UsersBlock consumes it, the
  container can own the provider instance.

#### Commit 4.1.13: TeamsListContainer -- DONE `44c2c3a3`

**Create:** `src/ui/page_blocks/teams/TeamsListContainer.tsx`
**Modify:**
- `src/ui/page_blocks/teams/TeamsBlock.tsx` (props-only)
- `src/ui/page_blocks/teams/AddTeamForm/AddTeamForm.tsx` (TODO(4.5) comment added)
- `src/ui/page_blocks/teams/index.tsx` (barrel: `export { TeamsListContainer as TeamsBlock }`)

**Container absorbs:**
- `useTeamsListQuery()`, `useRemoveTeamsMutation()`
- `useKeepRowsSelection()`, search state, modal state (create + remove)
- `useQueryClient()` left in AddTeamForm with TODO(4.5)

**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.14: TeamDetailContainer -- DONE `598c2d7d`

**Create:** `src/ui/page_blocks/teams/TeamDetailContainer.tsx`
**Modify:**
- `src/ui/page_blocks/teams/TeamBlock.tsx` (props-only)
- `src/pages/teams/[id].tsx` (import from barrel)
- `src/ui/page_blocks/teams/index.tsx` (barrel: also exports `TeamDetailContainer as TeamBlock`)

**Container absorbs:**
- `useTeamsListQuery()`, `useUpdateTeamMutation()`
- `useRouter()` (for team ID from URL), team resolution useMemo
- PostHog tracking (sendPosthogEvent), edit modal state

**Complexity:** S
**Dependencies:** 4.2

#### Commit 4.1.15: UsersContainer -- DONE `62a27ed7`

**Create:** `src/ui/page_blocks/users/UsersContainer.tsx`
**Delete:** `src/ui/page_blocks/users/UsersBlock.tsx` (dead code, replaced by container via barrel)
**Modify:**
- `src/ui/page_blocks/users/Users.tsx` (receives data props; keeps mutations + useFlyoutContext inside FlyoutProvider scope)
- `src/ui/page_blocks/users/AddUserForm/AddUserForm.tsx` (TODO(4.5) comment added)
- `src/ui/page_blocks/users/index.ts` (barrel: `export { UsersContainer as UsersBlock }`)

**Container absorbs:**
- `FlyoutProvider` wrapper (container wraps it)
- `useAuthState()`, `useUsersListQuery()`, `useGetAllBPOsQuery()`, `useGetAllProjectsQuery()`
- `useKeepRowsSelection()`, search state, computed bpoItems/projectItems/usersToDisplay
- `useQueryClient()` left in AddUserForm with TODO(4.5)

**Key decision:** Users.tsx keeps mutations (useAssignUsers, useAssignUsersToProjects) because
their handlers reference `setFlyoutOpen` which requires being inside FlyoutProvider scope.

**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.16: SettingsAccountContainer -- DONE `a159c32b`

**Create:** `src/ui/page_blocks/settings/Account/AccountContainer.tsx`
**Modify:**
- `src/ui/page_blocks/settings/Account/Account.tsx` (props-only, receives userInfo)
- `src/ui/page_blocks/settings/Account/index.ts` (barrel: `export { AccountContainer as AccountBlock }`)

**Container absorbs:** `useAuthState()` -> passes `userInfo` as prop.
**Note:** Used `UserInfo` from `@/providers/context/auth/types` (not `@/shared/types/auth`)
because context returns unbranded uid:string, not branded UserId.

**Complexity:** S
**Dependencies:** 4.2

#### Commit 4.1.17: SettingsProjectsContainer -- DONE `f768631b`

**Create:** `src/ui/page_blocks/settings/Project/ProjectContainer.tsx`
**Modify:**
- `src/ui/page_blocks/settings/Project/Project.tsx` (props-only)
- `src/ui/page_blocks/settings/Project/index.ts` (barrel: `export { ProjectContainer as ProjectBlock }`)

**Container absorbs:**
- `useGetAllProjectsQuery()`
- `useCreateProjectMutation()`, `useUpdateProjectMutation()`, `useDeleteProjectMutation()` (with onSuccess toasts + modal close + clearSelection)
- `useKeepRowsSelection()`, search state, modal state (create + edit + delete)
- Computed: projectsToDisplay, selectedIds

**Note:** Used `void` operator for async mutation handlers to satisfy `no-misused-promises` ESLint rule.

**Complexity:** M
**Dependencies:** 4.2

#### Commit 4.1.18: SettingsBPOContainer -- DONE `73b693ea`

**Create:** `src/ui/page_blocks/settings/BPO/BPOContainer.tsx`
**Modify:**
- `src/ui/page_blocks/settings/BPO/BPO.tsx` (props-only)
- `src/ui/page_blocks/settings/BPO/index.ts` (barrel: `export { BPOContainer as BPOBlock }`)

**Container absorbs:**
- `useGetAllBPOsQuery()`, `useCreateBPOMutation()`, `useUpdateBPOMutation()`, `useDeleteBPOMutation()` (with onSuccess toasts + modal close + clearSelection)
- `useKeepRowsSelection()`, search state, modal state (create + edit + delete)
- Computed: bposToDisplay, selectedIds

**Complexity:** M (near-identical pattern to ProjectContainer)
**Dependencies:** 4.2

#### Commit 4.1.19: ClassificationUrlsContainer -- DONE `7cc5216b`

**Create:** `src/ui/page_blocks/classificationUrls/ClassificationUrlsContainer.tsx`
**Modify:**
- `src/ui/page_blocks/classificationUrls/ClassificationUrlsBlock.tsx` (props-only for data; keeps useFlyoutContext + useUrlsClassification + useQueryClient)
- `src/ui/page_blocks/classificationUrls/index.ts` (barrel: `export { ClassificationUrlsContainer as ClassificationUrlsBlock }`)

**Container absorbs:**
- `useRouter()` (teamId derivation), `useAuthState()` (organizationId)
- `useClassificationUrlsQuery()`, data-sync useEffect
- `useKeepRowsSelection()`, search/filter/period state, editModalOpen, urls/setUrls
- Computed: urlsToDisplay, dataSourceLevel, isRowClickable
- FlyoutProvider wrapper (container wraps it)

**Block keeps (must be inside FlyoutProvider/UrlsClassificationProvider scope):**
- `useFlyoutContext()` (handleRowClick calls setFlyoutOpen)
- `useUrlsClassification()` (handleRowClick calls setSelectedHost)
- `useQueryClient()` with TODO(4.5) comment (used in handleCategoriesUpdate)
- `useUrlsTableColumns()` (presentational column hook)

**Note:** Did NOT remove UrlsClassificationProvider from pages/settings/urls.tsx --
that provider is external to the container boundary (provided by the page).

**Complexity:** M-L
**Dependencies:** 4.2

---

## 4.6: Props-Only Leaf Audit

**Goal:** Sweep all page_blocks for remaining DDAU boundary violations in
non-container leaf components. Every hook call to a context or service hook
in a leaf should be lifted to the owning container.

**Known violations (found during Session 7 reconciliation):**

| File | Hook | What to do |
|------|------|------------|
| `src/ui/page_blocks/users/UsersTable/UsersTable.tsx` | `usePosthogContext` | Lift `featureFlags` to prop from UsersContainer |
| `src/ui/page_blocks/users/UsersTable/UserRoleSelect.tsx` | `useAuthState` | Lift `roles` to prop from UsersContainer |
| `src/ui/page_blocks/users/TeamUsersActions/TeamUsersActions.tsx` | `useAuthState` | Lift `user` to prop from UsersContainer |
| `src/ui/page_blocks/dashboard/ui/DashboardNavigation/DashboardNavigation.tsx` | `usePosthogContext` + `usePathname` | Lift `featureFlags` + `pathname` from DashboardLayout |

**Accepted constraints (NOT violations -- require provider scope):**

| File | Hook | Why it stays |
|------|------|-------------|
| `src/ui/page_blocks/users/Users.tsx` | `useFlyoutContext` + mutations | Handlers call `setFlyoutOpen`, must be inside FlyoutProvider |
| `src/ui/page_blocks/classificationUrls/ClassificationUrlsBlock.tsx` | `useFlyoutContext` + `useUrlsClassification` + `useQueryClient` | Provider scope required; useQueryClient deferred to 4.5 |
| `src/ui/page_blocks/classificationUrls/OrgHostDetailsPanel.tsx` | `useFlyoutContext` + `useUrlsClassification` | Provider scope required |

**Agent guidance:** Run `grep -rn 'useAuthState\|usePosthogContext\|useInsightsContext\|useRouter\|usePathname' src/ui/page_blocks/ --include='*.tsx' | grep -v Container | grep -v '.spec.' | grep -v index` to find any violations beyond the known list. The broad sweep during Session 7 reconciliation found only the 4 files listed above plus the 3 accepted constraints.

**Complexity:** S-M (each fix is mechanical: add prop to container, thread to child)
**Dependencies:** All 4.1 containers exist

---

## 4.5 Residual: InsightsContext useQueryClient

After all route containers exist, the remaining `useQueryClient()` call is in
`InsightsContext.tsx` itself.

### Commit 4.5.1: Move InsightsContext cache invalidation to containers

**Modify:**
- `src/ui/providers/context/insightsContext/InsightsContext.tsx`
- Affected containers that trigger invalidation

**Details:**
1. Identify what InsightsContext uses useQueryClient for (refreshData that invalidates on filter change)
2. Move cache invalidation into filter containers (4.4) or route containers
3. Remove useQueryClient from InsightsContext

**Agent guidance:**
- `refreshData` in InsightsContext calls `queryClient.invalidateQueries()`.
  The filter containers' `handleSubmit` already calls `refreshData` via
  context. The question is whether to make the containers call
  `queryClient.invalidateQueries()` directly (removing the context's
  dependency on queryClient) or to leave refreshData in context and just
  accept that the context needs queryClient for this one operation.
- If moving invalidation to containers: each filter container calls
  `refreshData` for its own domain. Map which query keys each domain
  invalidates, then replace the `refreshData(domain)` call with direct
  `queryClient.invalidateQueries({ queryKey: [...] })` in each container.
- After this commit, `useQueryClient` should appear in ZERO providers.
  The only remaining useQueryClient calls should be in containers that
  own CRUD forms (AddTeamForm, AddUserForm -- addressed in 4.1.13/4.1.15
  if not already done in Group D).

**Complexity:** M
**Dependencies:** All containers from 4.1 exist

---

---

**Reconciliation notes (2026-02-28, after Session 8):**

1. **Barrel orphan**: `ProductivityByDateContainer.tsx` is not exported from
   `src/ui/page_blocks/dashboard/team/index.ts`. It is imported directly by
   `UserProductivity.tsx` via relative path. One-line fix. Do during Session 9
   or the domain merges (4.10).

2. **SettingsNavigation.tsx**: Retains `usePathname()`. Same pattern as
   DashboardNavigation before the 4.6.1 fix. Settings pages were outside
   the 4.6 scope. Lift `pathname` to props from the settings layout when
   settings pages get containers, or during a future cleanup pass.

3. **Service hooks in users/ leaves**: `UsersTable.tsx`, `UserRoleSelect.tsx`,
   `TeamUsersActions.tsx`, `Users.tsx`, `EditUserModal.tsx` retain mutation
   hooks. The context hooks (useAuthState, usePosthogContext, useRouter)
   were lifted in 4.6.2, but mutation hooks were kept per the form exception
   rationale and FlyoutProvider scope constraint. These are documented
   accepted constraints, not violations.

---

**Pre-Session-10 cleanup (carry forward from Session 8-9 reconciliation):**

1. ~~**ProductivityByDateContainer barrel orphan**~~: **FIXED** in 4.7.1 (`a89cc661`).

2. **SettingsNavigation.tsx retains `usePathname()`**: Lift `pathname` to
   props from the settings layout. Same pattern as the DashboardNavigation
   fix in 4.6.1. Do in the next session that touches settings/.

3. **useChatApi exception**: The memory and earlier prompts referenced
   `useChatApi.ts` keeping `useAuthState` as a documented exception. This
   hook DOES exist in user-frontend (at `src/ui/page_blocks/dashboard/chat/useChatApi.ts`).
   The exception is valid. The memory note was corrected -- useChatApi is NGA-originated
   but was ported to UF.

4. **Dev server command**: The dev server is `pnpm dev` (port 3001), not
   `preview_start`. If the Session 9 agent could not find `preview_start`,
   that is why.

**Post-Session-10 notes:**

5. **WorkstreamAnalysisContainer raw localStorage**: The audit found
   `WorkstreamsFiltersContainer.tsx` uses raw `localStorage.setItem`. This
   should be migrated to typedStorage in a future cleanup pass. Not blocking.

6. **WorkstreamChart dead code deleted**: `WorkstreamChart/` (pure DOM, zero
   consumers) was deleted in 4.7.2. Not the same as `WorkstreamGanttChart`
   (ECharts, actively used by SystemAnalysis.tsx).

7. **Test delta**: 1899 -> 1893 (6 tests deleted with recharts sub-component
   specs). No test failures introduced.

---

## 4.7: Replace chart.js/recharts with ECharts -- DONE

**Session 10 (2026-02-28).** HEAD: `7f1aa328`.

### Inventory findings:
- echarts + echarts-for-react already installed (WorkstreamGanttChart uses them)
- chart.js: zero imports in src/ (phantom dependency)
- recharts: only used by PieChart (4 imports in 4 sub-components)
- ProductivityChart: pure DOM/CSS, no charting library
- WorkstreamChart: pure DOM, dead code (zero consumers)

### Actual commits (3):
- `a89cc661` 4.7.1: Rewrite PieChart from recharts to echarts-for-react. Same PieChartProps<T> interface. Fix team barrel orphan.
- `17a86f9c` 4.7.2: Delete 17 dead files (recharts sub-components, WorkstreamChart, legend utils, types.ts, dead constants). 402L deleted.
- `7f1aa328` 4.7.3: Remove recharts + chart.js from package.json. 17 transitive packages removed.

### Verification:
- tsc: 0 errors
- vitest: 1893 pass (1899 - 6 deleted specs: 1 CustomizedLabel + 1 PieChartCustomTooltip + 4 legendFormatter)
- grep: zero imports of chart.js/recharts/react-chartjs-2
- pnpm ls: chart.js/recharts not in dependency tree
- Dev server: /insights/workstream-analysis, /insights/user-productivity, /insights/team-productivity, /insights/workstreams all return 200

**Complexity:** S (actual -- scope was much smaller than estimated)

---

## 4.8: Replace react-csv with papaparse -- DONE

**Session 11 (2026-02-28).** HEAD: `eb5a571d`.

### Pre-work: Inventory react-csv usage
4 imports across 2 files: `CSVButton.tsx` (CSVLink, Headers, LinkProps) and `TableHeader.tsx` (Headers type-only).
31 page_block consumers pass `csvFilename` through Table props but never import react-csv directly.

### Commits:
- `295e63c2` 4.8.1: Rewrite CSVButton from react-csv CSVLink to papaparse Papa.unparse() + Blob URL download. Export local CSVHeader/CSVHeaders types. TableHeader updated to use CSVHeaders instead of react-csv Headers. 2 files, +44/-44.
- `eb5a571d` 4.8.2: Remove react-csv + @types/react-csv from package.json. Zero react-csv imports remain.

### Verification:
- tsc: 0 errors
- Tests: 1893 passed (baseline match, no CSVButton specs exist)
- Grep: 0 react-csv references in src/ or package.json
- Dev server: compiles clean, no bundling errors
- pnpm ls: react-csv and @types/react-csv both absent

**Complexity:** S (actual: 2 commits, 3 files changed)

---

## 4.9: Missing Page Blocks

**Status:** Merged into 4.1. Pages with inline logic (realtime, system-latency,
workstream-analysis, chat) have their logic extracted into containers during
route container creation.

---

## 4.10: Merge UF-Only Domains -- DONE (2026-02-28, Session 9)

### Commit 4.10.1: classificationUrls -> settings/Urls -- DONE `746c24c4`
Move `src/ui/page_blocks/classificationUrls/` into `src/ui/page_blocks/settings/Urls/`.
Updated 2 import sites: `src/pages/settings/urls.tsx`, `src/ui/page_blocks/teams/TeamBlock.tsx`.
31 files changed.
**Complexity:** S

### Commit 4.10.2: opportunity -> opportunities -- DONE `ded67484`
Rename `src/ui/page_blocks/dashboard/opportunity/` to `opportunities/`.
Updated 10 import sites: dashboard barrel, DashboardLayout, SystemsContainer, SystemsOccurrences,
useActivityTimelineTableColumns (2 imports), insightsContext types, queryParams.ts, testUtils.ts,
and 3 internal self-references in OpportunityFilters/utils/form/form.ts.
48 files changed.
**Complexity:** M (many cross-references)

### Commit 4.10.3: workstreams-analyzer -> workstream-analysis/analyzer -- DONE `f27df503`
Merge `workstreams-analyzer/` into `workstream-analysis/analyzer/`.
Updated dashboard barrel to source through workstream-analysis/ barrel (re-export pattern).
Fixed relative import `../constants` -> `../../constants` in WorkstreamsAnalyzerBlock.tsx
(moved one level deeper, relative path broke).
14 files changed.
**Complexity:** M

**Dev server verification:** All 4 affected pages compiled without webpack errors:
`/settings/urls` (200), `/insights/microworkflows` (200), `/insights/workstreams` (200),
`/insights/workstream-analysis` (200).

---

## Exit Criteria Checklist

- [ ] Every leaf in `page_blocks/` receives all data as props
- [ ] No leaf calls service hooks, context hooks, useRouter, or storage
- [ ] `useQueryClient()` only in service hooks (mutations)
- [ ] DashboardLayout is container + presentational split
- [ ] Every insights page has a route container
- [ ] Every non-insights page has a route container (or is auth infrastructure)
- [ ] Filter components wrapped in filter containers
- [ ] chart.js/recharts replaced with ECharts
- [ ] react-csv replaced with papaparse
- [ ] Domain naming consistent
- [ ] `pnpm tsc --noEmit` 0 errors
- [ ] 18 pre-existing test failures, no new ones

---

## Audit Notes (from dashboard feature audit, 2026-02-27)

### Storage access to fix (during filter container work):
- `utils/storage.ts`: raw `JSON.parse(localStorage.getItem(...)) as Record` -- trust boundary
- `InsightsFilters.tsx:152`: raw `localStorage.setItem(NEW_INSIGHTS_FILTERS_KEY, ...)`
- `OpportunitiesFilters.tsx:115`: same
- `WorkstreamsFilters.tsx:110`: same
- `RealtimeFilters.tsx:96,193`: same + raw read
- Replace with `writeStorage`/`readStorage` from `@/shared/utils/typedStorage` + Zod schemas

### Cross-domain coupling to fix:
- `MicroworkflowDetailsTable.tsx` imports from `workstream-analysis/filters/` -> container callback
- `SystemsView.tsx` imports `analyzingByItems` from `opportunity/` -> shared constants
- `handleClickGlossary.ts` imports `GLOSSARY_LINK_TEXT` from page_blocks -> `@/shared/constants`
- `getTeamsItems.ts` imports `unassignedUserItem` from page_blocks -> `@/shared/constants`

### useEffects to eliminate (during container work):
- `AvgLoadTime.tsx:84`: derived state -> useMemo
- `ProductivityByDate.tsx:68,80`: derived state -> useMemo
- `SystemsView.tsx:56`: effect bridge -> container handler
- `WorkstreamsTable.tsx:33`: effect bridge -> container handler
- `AnalyzerWorkstreamsTable.tsx:33`: event handler disguised -> container handler
- `InsightsFilters.tsx:185`, `OpportunitiesFilters.tsx:141`, `WorkstreamsFilters.tsx:137`: -> onChange

### Dead code to delete:
- `chat/constants.ts` -> `mockedMessages` (zero consumers)
- `workstreams-analyzer/ActivityTimelineTable/mocks.ts` (zero consumers, marked TODO)

### Non-dashboard audit notes (2026-02-27):

**Settings page_blocks:**
- AccountBlock: minimal (useAuthState only). Container is trivial but keeps consistency.
- BPOBlock (227L): 4 CRUD hooks + 3 modal states + search + selection. Full container needed.
- ProjectBlock: near-identical to BPO. Same pattern.
- ClassificationUrlsBlock: UrlsBlockImpl has useQueryClient, useRouter, useAuthState, useFlyoutContext, useUrlsClassification, useClassificationUrlsQuery, 4 useStates, 1 useEffect, 1 useMemo. Heavy container.

**Teams page_blocks:**
- TeamsBlock (index.tsx): useTeamsListQuery, useRemoveTeamsMutation, 2 useStates, search/selection.
- TeamBlock: useRouter (ID from URL), useTeamsListQuery, useUpdateTeamMutation, 1 useState, wraps ClassificationUrlsBlock in UrlsClassificationProvider.
- AddTeamForm: useForm, useWatch, useAssignableUsersQuery, useCreateTeamMutation, useAddTeamOwnersMutation, useAddUsersToTeamMutation, **useQueryClient** (invalidates teamsQueryKeys.list, removes usersQueryKeys.list).

**Users page_blocks:**
- Users.tsx: useAuthState, useUsers (context), useUsersListQuery, useGetAllBPOs, useGetAllProjects, useAssignUsers, useAssignUsersToProjects, useFlyoutContext, 3 useStates, 4 useMemos, useKeepRowsSelection. Complex multi-query orchestration.
- UsersTable: usePosthogContext, useFlyoutContext, useUsers, useAssignUsers (clearAssignments). Context leakage.
- AddUserForm: useForm, useAssignableUsersQuery, useAddUsersToTeamMutation, **useQueryClient** (invalidates/removes query keys).
- EditUserModal: useUsers (context), useUpdateUserMutation, useAssignUsers, useTeamsListQuery, useForm, useWatch, 4 useMemos. Heavy.
- UserPanel: useRouter, useFlyoutContext, useUsers, useUsersListQuery, 2 useEffects (click-outside, ESC), 2 useRefs.
- TeamUsersActions: 3 useStates, useAuthState, useRouter, useRemoveUsersFromTeamMutation.

**Provider state (insightsContext post-Phase 3, 196L):**
- 9 pieces of state: timezone, filters (per-domain bag), isHours, selectedWorkstreams, selectedUser, selectedMicroworkflow, selectedMicroworkflowUser, selectedAnalyzerWorkstream, isOutOfChromeFiltered
- useQueryClient still present: used in handleSetFilters (per-domain invalidation) and refreshData
- usePagesStateReducer: manages systems.view, systems.selectedSystem, systems.selectedPage, systems.selectedUser
- 1 useEffect: clears all state on logout
- After Phase 4: insightsContext should shrink to only cross-page state (filters bag + timezone + isHours). Per-page selections move to route containers.
